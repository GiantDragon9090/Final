import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

// Redux
import { useSelector } from "react-redux";
import {notification} from 'antd';
// Web3
import Web3 from "web3";

// Firebase
import { addDoc, collection, getDocs, query, where } from "firebase/firestore";
import database from "../config/firebase";

// Components
import Authenticator from "../components/Authenticator";

// Contracts Data
import { placeholderContractABI } from "../data/smart-contracts";

const ImportCollection = () => {
  // States
  const navigate = useNavigate();

  const wallet = useSelector((state) => state.wallet);
  const authenticated = useSelector((state) => state.authenticated);

  const [collectionInfo, setCollectionInfo] = useState({
    type: "imported",
    contractAddress: "",
    ownerUserID: wallet.id,
    ownerWalletAddress: wallet.address,
    logoImage: "default",
    bannerImage: "default",
    title: "",
    url: "",
    description: "",
    websiteLink: "",
    discordLink: "",
    twitterLink: "",
    instagramLink: "",
    mintAble: false,
    verified: false,
    createdOn: Date.now(),
  });

  const [logoImage, setLogoImage] = useState("default");
  const [logoImageFile, setLogoImageFile] = useState(null);
  const [saving, setSaving] = useState(false);

  const [bannerImage, setBannerImage] = useState("default");
  const [bannerImageFile, setBannerImageFile] = useState(null);

  // Functions
  const submit = async (e) => {
    e.preventDefault();
    setSaving(true);
    const collectionsCollectionRef = collection(database, "collections");
    const collectionsCollectionQueryRef = query(
      collectionsCollectionRef,
      where("url", "==", collectionInfo.url)
    );

    getDocs(collectionsCollectionQueryRef).then(async (snapshot) => {
      let collections = [];

      snapshot.docs.forEach((doc) => {
        collections.push({ ...doc.data(), id: doc.id });
      });
      if(collections.length == 0){
        
        // Checking Owner
        const web3 = new Web3(Web3.givenProvider);
        await Web3.givenProvider.enable();
    
        const contract = new web3.eth.Contract(
          placeholderContractABI,
          collectionInfo.contractAddress
        );
    
        contract.methods
          .owner()
          .call()
          .then((res) => {
            if (res === collectionInfo.ownerWalletAddress) {
              const collectionsCollectionRef = collection(database, "collections");
              const collectionsCollectionQueryRef = query(
                collectionsCollectionRef,
                where("contractAddress", "==", collectionInfo.contractAddress)
              );
    
              getDocs(collectionsCollectionQueryRef).then(async (snapshot) => {
                let collections = [];
    
                snapshot.docs.forEach((doc) => {
                  collections.push({ ...doc.data(), id: doc.id });
                });
    
                if (collections.length > 0) {
                  alert("This collection is already imported");
                  return;
                } else {
                  const logoImageData = new FormData();
    
                  logoImageData.append("file", logoImageFile);
                  logoImageData.append("upload_preset", "images");
    
                  const logoImageRes = await fetch(
                    "https://api.cloudinary.com/v1_1/mtv-art/image/upload",
                    {
                      method: "post",
                      body: logoImageData,
                    }
                  );
    
                  const logoImageResFile = await logoImageRes.json();
    
                  const bannerImageData = new FormData();
    
                  bannerImageData.append("file", bannerImageFile);
                  bannerImageData.append("upload_preset", "images");
    
                  const bannerImageRes = await fetch(
                    "https://api.cloudinary.com/v1_1/mtv-art/image/upload",
                    {
                      method: "post",
                      body: bannerImageData,
                    }
                  );
    
                  const bannerImageResFile = await bannerImageRes.json();
    
                  let newCollectionInfo = {
                    ...collectionInfo,
                    logoImage: logoImageResFile.secure_url,
                    bannerImage: bannerImageResFile.secure_url,
                  };
    
                  addDoc(collectionsCollectionRef, newCollectionInfo).then(() => {
                    navigate("/profile", { replace: true });
                  });
                }
              });
            } 
            else {
              alert("Only the owner can import this collection");
            }
          }
          )
          .catch("Invalid contract address");
      } else{
        notification.error({
          message : "Input Error",
          description : "Collection Name is duplicate!!!"
        })
        setSaving(false)
      }
    });
  };

  const updateLogoImage = (e) => {
    const files = e.target.files;
    setLogoImageFile(files[0]);

    const objectUrl = URL.createObjectURL(files[0]);

    setLogoImage(objectUrl);
  };

  const updateBannerImage = (e) => {
    const files = e.target.files;
    setBannerImageFile(files[0]);

    const objectUrl = URL.createObjectURL(files[0]);

    setBannerImage(objectUrl);
  };

  return (
    <React.Fragment>
      <Authenticator />

      {authenticated ? (
        <main className="import-create-collection-page">
          <section className="collection">
            <div className="container">
              <h1>Import collection</h1>
              <p className="sub-title">
                You can set preferred display name, url and manage <br />
                other personal settings
              </p>

              <form onSubmit={submit}>
                <div className="input-group logo-image-input-group">
                  <label>Logo image</label>

                  <input type="file" onChange={updateLogoImage} required />
                  <div className="logo-image-placeholder">
                    <img
                      src={logoImage !== "default" ? logoImage : null}
                      alt=""
                      className={logoImage !== "default" ? null : "disabled"}
                    />
                  </div>
                </div>

                <div className="input-group banner-image-input-group">
                  <label>Banner image</label>

                  <input type="file" onChange={updateBannerImage} required />
                  <div className="banner-image-placeholder">
                    <img
                      src={bannerImage !== "default" ? bannerImage : null}
                      alt=""
                      className={bannerImage !== "default" ? null : "disabled"}
                    />
                  </div>
                </div>

                <div className="input-group">
                  <label>Contract address</label>
                  <input
                    type="text"
                    value={collectionInfo.contractAddress.trim()}
                    onChange={(e) => {
                      
                      setCollectionInfo({
                        ...collectionInfo,
                        contractAddress: e.target.value.trim(),
                      });
                    }}
                    required
                  />
                </div>

                <div className="input-group">
                  <label>Title</label>
                  <input
                    type="text"
                    value={collectionInfo.title}
                    onChange={(e) => {
                      setCollectionInfo({
                        ...collectionInfo,
                        title: e.target.value,
                      });
                    }}
                    required
                  />
                </div>

                <div className="input-group">
                  <label>Collection Name</label>
                  <input
                    type="text"
                    value={collectionInfo.url}
                    onChange={(e) => {
                      setCollectionInfo({
                        ...collectionInfo,
                        url: e.target.value.split(" ").join("_"),
                      });
                    }}
                    required
                  />
                </div>

                <div className="input-group">
                  <label>Description</label>
                  <textarea
                    type="text"
                    onChange={(e) => {
                      setCollectionInfo({
                        ...collectionInfo,
                        description: e.target.value,
                      });
                    }}
                    defaultValue={collectionInfo.description}
                    required
                  ></textarea>
                </div>

                <div className="input-group">
                  <label>Website</label>
                  <input
                    type="text"
                    value={collectionInfo.websiteLink}
                    onChange={(e) => {
                      setCollectionInfo({
                        ...collectionInfo,
                        websiteLink: e.target.value,
                      });
                    }}
                  />
                </div>

                <div className="input-group" >
                  <label>Royalty(%, minimum 1, maximum 25)</label>
                  <input
                    type="number"
                    min = {1} max ={25} 
                    value={collectionInfo.royalty}
                    onChange={(e) => {
                      setCollectionInfo({
                        ...collectionInfo,
                        royalty: e.target.value,
                      });
                    }}
                  />
                </div>

                <div className="input-group">
                  <label>Discord</label>
                  <input
                    type="text"
                    value={collectionInfo.discordLink}
                    onChange={(e) => {
                      setCollectionInfo({
                        ...collectionInfo,
                        discordLink: e.target.value,
                      });
                    }}
                  />
                </div>

                <div className="input-group">
                  <label>Twitter</label>
                  <input
                    type="text"
                    value={collectionInfo.twitterLink}
                    onChange={(e) => {
                      setCollectionInfo({
                        ...collectionInfo,
                        twitterLink: e.target.value,
                      });
                    }}
                  />
                </div>

                <div className="input-group">
                  <label>Instagram</label>
                  <input
                    type="text"
                    value={collectionInfo.instagramLink}
                    onChange={(e) => {
                      setCollectionInfo({
                        ...collectionInfo,
                        instagramLink: e.target.value,
                      });
                    }}
                  />
                </div>

                <button className={saving ? "disabled":""}>
                  <span>Import collection</span>
                </button>
              </form>
            </div>
          </section>
        </main>
      ) : (
        <p className="loader">Loading...</p>
      )}
    </React.Fragment>
  );
};

export default ImportCollection;
