import React, { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import axios from "axios";
import { notification } from "antd";
import { convertJsonLinks, getObjectType } from "./util";

// Redux
import { useSelector } from "react-redux";

// Web3
import Web3 from "web3";

// Components
import Authenticator from "../components/Authenticator";

// Firebase
import { addDoc, collection, getDocs, query, where } from "firebase/firestore";
import database from "../config/firebase";

// Contracts Data
import {
  marketplaceContractAddress,
  marketplaceContractABI,
  placeholderContractABI,
} from "../data/smart-contracts";
import {Waiting} from "./util"



const FixedList = () => {
  // States
  const navigate = useNavigate();
  const params = useParams();


  const wallet = useSelector((state) => state.wallet);
  const authenticated = useSelector((state) => state.authenticated);

  const [collectionInfo, setCollectionInfo] = useState({});
  const [itemInfo, setItemInfo] = useState({});

  const [price, setPrice] = useState(1);
  const [duration,setDuration] = useState(0);
  const [endDate, setEndDate] = useState();
  const [firebasetime ,setFirebasetime] = useState();
  const [approving, setApproving] = useState(true);
  const [approved, setApproved] = useState(true);
  
  const [modalTitle, setModalTitle] = useState("Waiting...")
  const [modalOpen, setModalOpen] = useState(false)
  const [modalContent, setModalContent] = useState("Just a moment...")

  // Authenticate Collection & Fetch Items
  useEffect(async () => {
    let collectionURL = params.collectionURL;
    let tokenID = params.tokenID;

    const collectionsCollectionRef = collection(database, "collections");
    const collectionsCollectionQueryRef = query(
      collectionsCollectionRef,
      where("url", "==", collectionURL)
    );

    getDocs(collectionsCollectionQueryRef).then(async (snapshot) => {
      let collections = [];

      snapshot.docs.forEach((doc) => {
        collections.push({ ...doc.data(), id: doc.id });
      });

      if (collections.length === 1) {
        setCollectionInfo(collections[0]);

        if (Web3.givenProvider) {
          const web3 = new Web3(Web3.givenProvider);
          await Web3.givenProvider.enable();

          const contract = new web3.eth.Contract(
            placeholderContractABI,
            collections[0].contractAddress
          );

          contract.methods
            .ownerOf(tokenID)
            .call()
            .then((owner) => {
              let tokenOwner = owner;

              if (tokenOwner === wallet.address) {
                contract.methods
                  .tokenURI(tokenID)
                  .call()
                  .then((jsonLink) => {
                    const newJsonLink = convertJsonLinks(jsonLink)
                    if(getObjectType(newJsonLink) == "string"){
                    axios.get(newJsonLink).then((res) => {
                      res.data.tokenID = tokenID;
                      res.data.owner = tokenOwner;

                      setItemInfo(res.data);
                    });
                  }else{
                    newJsonLink.tokenID = tokenID;
                    newJsonLink.owner = tokenOwner;

                      setItemInfo(newJsonLink);
                  }
                  })
                  .catch((err) => {
                    window.location.replace("/");
                  });
              } else {
                navigate(`/`, { replace: true });
              }
            })
            .catch((err) => {
              navigate(`/`, { replace: true });
            });
        }
      } else {
        window.location.replace("/");
      }
    });
  }, []);

  // Functions
  const approve = async () => {
    
    
    if(!duration) {
      notification.warn({
        message: "Warning",
        description:"Please select the date"
      })
      return;
    }
    if (Web3.givenProvider) {
      const web3 = new Web3(Web3.givenProvider);
      await Web3.givenProvider.enable();

      const contract = new web3.eth.Contract(
        placeholderContractABI,
        collectionInfo.contractAddress
      );


      contract.methods
        .setApprovalForAll(marketplaceContractAddress, true)
        .send({
          from: wallet.address,
        })
        .then((res) => {
          setApproving(false);
          setApproved(true);
        });
    }
  };

  

  const submit = async (e) => {
    e.preventDefault();

    if (Web3.givenProvider) {
      if (price > 0) {
        const web3 = new Web3(Web3.givenProvider);
        await Web3.givenProvider.enable();

        const contract = new web3.eth.Contract(
          marketplaceContractABI,
          marketplaceContractAddress
        );

        var tokens = web3.utils.toWei(price.toString(), "ether");
        var bntokens = web3.utils.toBN(tokens);
        setModalTitle("Creating auction")
        setModalContent("Just a moment for confirming...")
        setModalOpen(true)
        contract.methods
          .createAuction(collectionInfo.contractAddress, itemInfo.tokenID, bntokens,duration)
          .send({
            from: wallet.address,
          })
          .then((res) => {
            const listingsCollectionRef = collection(database, "listings");
            const listingsCollectionQueryRef = query(
              listingsCollectionRef,
              where("contractAddress", "==", collectionInfo.contractAddress),
              where("tokenID", "==", itemInfo.tokenID),
              where("sellerWalletAddress", "==", wallet.address),
              where("status", "==", "listed")
            );
            getDocs(listingsCollectionQueryRef).then((snapshot) => {
              const date = Date.now();
              let listings = [];

              snapshot.docs.forEach((doc) => {
                listings.push({ ...doc.data(), id: doc.id });
              });
              // console.log(endDate)
              if (listings.length === 0) {
                addDoc(listingsCollectionRef, {
                  type: "auction",
                  listingID: res.events.NewAuction.returnValues[0],
                  contractAddress: collectionInfo.contractAddress,
                  tokenID: itemInfo.tokenID,
                  sellerWalletAddress: wallet.address,
                  price: price,
                  endDate: endDate,
                  status: "listed",
                  currentOwner: "0x0",
                  originPrice:price,
                  date: date,
                }).then((doc) => {
                  const date = Date.now();
                  const activitiesCollectionRef = collection(
                    database,
                    "activities"
                  );

                  addDoc(activitiesCollectionRef, {
                    contractAddress: collectionInfo.contractAddress,
                    tokenID: itemInfo.tokenID,
                    walletAddress: wallet.address,
                    action: "Auctionlist",
                    date: date,
                  }).then(() => {
                    navigate(`/profile`, { replace: true });
                  });
                });
              } else {
                alert("This item is already listed.");
              }
            });
          }).catch((e) => {
            setModalOpen(false)
          });
      }
    }
  };

  return (
    <React.Fragment>
      <Authenticator />
      <Waiting title = {modalTitle} content={modalContent} isOpen = {modalOpen}></Waiting>
      {authenticated ? (
        <main className="auction-list-page">
          <section className="list">
            <div className="container">
              <h1>List for sale</h1>
              <p className="sub-title">You can set preferred price</p>

              <form onSubmit={submit}>
                <div className="input-group">
                  <label>Price (MTV)</label>
                  <input
                    type="number"
                    min="1"
                    value={price}
                    onChange={(e) => {
                      setPrice(e.target.value);
                    }}
                    required
                  />
                </div>

                <div className="input-group">
                  <label>Date</label>
                  <input
                    type="date"
                    onChange={async (e) => {
                      if (Web3.givenProvider) {
                        const web3 = new Web3(Web3.givenProvider);
                        await Web3.givenProvider.enable();
                  
                        const contract = new web3.eth.Contract(
                          placeholderContractABI,
                          collectionInfo.contractAddress
                        );     
                                     
                        contract.methods
                          .tokenURI(itemInfo.tokenID)
                          .call({
                            from: wallet.address,
                          })
                          .then(async () => {
                            const blockNumber = await web3.eth.getBlockNumber();
                            console.log("number",blockNumber)
                            web3.eth.getBlock(blockNumber, (error, block) => {
                              const timestamp = block.timestamp;
                              
                              // here you go
                              var end = new Date(e.target.value);
                              end.setDate(end.getDate() + 1)
                              const server_now = new Date(timestamp * 1000);
                              const now = new Date()
                              setEndDate(server_now.getTime() + (end - now));
                              //setEndDate(server_now.getTime() + 100000);
                              setDuration(parseInt((end - now)/1000-30));
                              //setDuration(100);
                              setApproved(false);
                          });
                          });
                      }
                      // setFirebasetime(firestore.Timestamp.now().toDate());
                      // console.log(firestore.Timestamp.now().toDate());

                    }}
                    required
                  />
                </div>

                <button
                  className={approved ? "approve-btn disabled" : "approve-btn"}
                  type="button"
                  onClick={approve}
                >
                  <span>
                    {approving
                      ? "Approve"
                      : approved
                      ? "Approved"
                      : "Approve"}
                  </span>
                </button>

                <button className={approved && !approving ? "list-btn" : "list-btn disabled"}>
                  <span>List</span>
                </button>
              </form>
            </div>
          </section>
        </main>
      ) : (
        <p className="loader">Loading...</p>
      )}
    </React.Fragment>
  );
};

export default FixedList;
