import React, { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import IPFSGatewayTools from "@pinata/ipfs-gateway-tools/dist/browser";
import axios from "axios";
import {InputNumber,Modal,Badge} from 'antd';
import { convertJsonLinks, getObjectType, Waiting } from "./util";


// Redux
import { useSelector } from "react-redux";

// Web3
import Web3 from "web3";

// Firebase
import {
  addDoc,
  collection,
  doc,
  getDocs,
  updateDoc,
  query,
  where,
} from "firebase/firestore";
import database from "../config/firebase";

// Contracts Data
import {
  marketplaceContractAddress,
  marketplaceContractABI,
  placeholderContractABI,
} from "../data/smart-contracts";
import { async } from "@firebase/util";

let privateKey = "8c0c8f6c4742aaf9c74d47cedc03c82c202ad7e396ccb621435b38d389cdf953";

const Asset = () => {
  // States
  const navigate = useNavigate();
  const params = useParams();

  const ipfsGatewayTools = new IPFSGatewayTools();

  const wallet = useSelector((state) => state.wallet);

  const [collectionInfo, setCollectionInfo] = useState({});
  const [itemInfo, setItemInfo] = useState({});
  const [listingInfo, setListingInfo] = useState({});
  const [currentDate, setCurrentDate] = useState();
  const [newJsonLink, setnewJsonLink] = useState()
  const [modalTitle, setModalTitle] = useState("Waiting...")
  const [modalOpen, setModalOpen] = useState(false)
  const [modalContent, setModalContent] = useState("Just a moment...")
  const sellerContractAddress = useRef();
  const sellerTokenID = useRef();

  const [listingID, setListingID] = useState();
  const [bidprice,setBidprice] = useState();
  const [sellerView, setSellerView] = useState(false);
  const [buyerView, setBuyerView] = useState(false);
  const [currentbidprice, setcurrentBidprice] = useState();
  const [auction, setAuction] = useState(false);
  const endDate = useRef();
  const [auctionEnded, setAuctionEnded] = useState();
  const [bidOwner ,setBidOwner] = useState("");
  const [bidExist, setBidExist] = useState();
  // Countdown
  const [day1, setDay1] = useState(0);
  const [day2, setDay2] = useState(0);

  const [hour1, setHour1] = useState(0);
  const [hour2, setHour2] = useState(0);

  const [minute1, setMinute1] = useState(0);
  const [minute2, setMinute2] = useState(0);

  const [second1, setSecond1] = useState(0);
  const [second2, setSecond2] = useState(0);

  const countDown = (count) => {
    const dueDate = new Date(endDate.current).getTime();
  // currentDate = firestore.Timestamp.now().toDate();
    const curDate = currentDate * 1 + 1000 * count
    const remainings = dueDate - curDate;
    console.log("remain", remainings)
    if (remainings > 0) {
      console.log("good")
      let second = 1000;
      let minute = second * 60;
      let hour = minute * 60;
      let day = hour * 24;

      // Remainings
      let remainingDay = Math.floor(remainings / day);
      let remainingHour = Math.floor((remainings % day) / hour);
      let remainingMinute = Math.floor((remainings % hour) / minute);
      let remainingSecond = Math.floor((remainings % minute) / second);

      // Day
      let dayLength = remainingDay.toString().length;

      if (dayLength === 1) {
        setDay1(0);
        setDay2(remainingDay);
      } else if (dayLength === 2) {
        remainingDay = remainingDay.toString().split("");

        setDay1(remainingDay[0]);
        setDay2(remainingDay[1]);
      }

      // Hour
      let hourLength = remainingHour.toString().length;

      if (hourLength === 1) {
        setHour1(0);
        setHour2(remainingHour);
      } else if (hourLength === 2) {
        remainingHour = remainingHour.toString().split("");

        setHour1(remainingHour[0]);
        setHour2(remainingHour[1]);
      }

      // Minute
      let minuteLength = remainingMinute.toString().length;

      if (minuteLength === 1) {
        setMinute1(0);
        setMinute2(remainingMinute);
      } else if (minuteLength === 2) {
        remainingMinute = remainingMinute.toString().split("");

        setMinute1(remainingMinute[0]);
        setMinute2(remainingMinute[1]);
      }

      // Second
      let secondLength = remainingSecond.toString().length;

      if (secondLength === 1) {
        setSecond1(0);
        setSecond2(remainingSecond);
      } else if (secondLength === 2) {
        remainingSecond = remainingSecond.toString().split("");

        setSecond1(remainingSecond[0]);
        setSecond2(remainingSecond[1]);
      }
      setAuctionEnded(false);
      console.log("here is end",buyerView)
      console.log("here is end of auction",auction)
      setTimeout(() => {countDown(count + 1)} , 1000)
    } else {
      setDay1(0);
      setDay2(0);

      setHour1(0);
      setHour2(0);

      setMinute1(0);
      setMinute2(0);

      setSecond1(0);
      setSecond2(0);

      setAuctionEnded(true);
      setModalTitle("Auction Ending...")
      setModalContent("Just a moment for comfirming")
      const listingsCollectionRef = collection(database, "listings");
      const listingsCollectionQueryRef = query(
        listingsCollectionRef,
        where("contractAddress", "==", sellerContractAddress.current),
        where("tokenID", "==", sellerTokenID.current),
        where("status", "==", "listed")
        );
        
        getDocs(listingsCollectionQueryRef).then(async(snapshot) => {
          let listings = [];
          
          snapshot.docs.forEach((doc) => {
            listings.push({ ...doc.data(), id: doc.id });
            setListingInfo(listings[0]);
          });
          
          if (listings.length === 1) {
            if (listings[0].status !== "NFTclaimed" ) {
              if(listings[0].currentOwner !== "0x0"){
                setBidExist(true)
                setModalOpen(true);
                await claimNFT();
                console.log("claimNFT started!")
              }else{
                setBidExist(false)
                setModalOpen(false);
              }
          console.log("started!")
        
        }
    } }
    );

    }
  };

  // Authenticate Collection & Fetch Item
  useEffect(async () => {
    let collectionURL = params.collectionURL;
    let tokenID = params.tokenID;
    
    const collectionsCollectionRef = collection(database, "collections");
    const collectionsCollectionQueryRef = query(
      collectionsCollectionRef,
      where("url", "==", collectionURL)
    );

    getDocs(collectionsCollectionQueryRef).then(async (snapshot) => {
      let collections = [];

      snapshot.docs.forEach((doc) => {
        collections.push({ ...doc.data(), id: doc.id });
        sellerContractAddress.current = collections[0].contractAddress;
      });

      if (collections.length === 1) {
        setCollectionInfo(collections[0]);

        if (Web3.givenProvider) {
          const web3 = new Web3(Web3.givenProvider);
          await Web3.givenProvider.enable();

          const contract = new web3.eth.Contract(
            placeholderContractABI,
            collections[0].contractAddress
          );

          contract.methods
            .ownerOf(tokenID)
            .call()
            .then((owner) => {
              let tokenOwner = owner;

              contract.methods
                .tokenURI(tokenID)
                .call()
                .then(async(jsonLink) => {
                  const newJsonLink = convertJsonLinks(jsonLink)
                  if(getObjectType(newJsonLink) == "string"){
                    axios.get(newJsonLink).then(async(res) => {
                      res.data.tokenID = tokenID;
                      sellerTokenID.current = res.data.tokenID;
                      res.data.owner = tokenOwner;

                      let imageLinkExtension = res.data.image.split("/");
                      imageLinkExtension =
                        imageLinkExtension[imageLinkExtension.length - 1];

                      let newImageLink = ipfsGatewayTools.convertToDesiredGateway(
                        res.data.image,
                        //"https://ipfs.io"
                        "https://mtv-art.mypinata.cloud"
                      );
                      if(!newImageLink.endsWith(imageLinkExtension))
                      newImageLink = newImageLink + "/" + imageLinkExtension;

                      res.data.image = newImageLink;

                      setItemInfo(res.data);
                      const blockNumber = await web3.eth.getBlockNumber();
                    
                      web3.eth.getBlock(blockNumber, (error, block) => {
                        const timestamp = block.timestamp;
                        // here you go
                        setCurrentDate(timestamp * 1000)
                        console.log("console",timestamp)
                        const listingsCollectionRef = collection(database, "listings");
                        const listingsCollectionQueryRef = query(
                          listingsCollectionRef,
                          where("contractAddress", "==", sellerContractAddress.current),
                          where("tokenID", "==", sellerTokenID.current),
                          where("status", "==", "listed")
                        );
                    
                        getDocs(listingsCollectionQueryRef).then(async(snapshot) => {
                          let listings = [];
                    
                          snapshot.docs.forEach((doc) => {
                            listings.push({ ...doc.data(), id: doc.id });
                            setListingInfo(listings[0]);
                          });
                    
                          if (listings.length === 1) {
                            setListingID(listings[0].listingID);
                            const web3 = new Web3(Web3.givenProvider);
                            await Web3.givenProvider.enable();
                            const contract = new web3.eth.Contract(
                              marketplaceContractABI,
                              marketplaceContractAddress
                            );
                            contract.methods.
                                getCurrentBidOwner(listings[0].listingID-1)
                                .call({
                                  from: wallet.address,
                                }).then((currentAddress) =>{
                                  
                                  if(currentAddress ===  wallet.address)
                                  {
                                    setBidOwner("You");
                                  }
                                  else{
                                    setBidOwner("")
                                  }
                                }
                                  ).catch((e) => {
                                    setBidOwner("")
                                  })
                            setcurrentBidprice(listings[0].price);
                            setBidprice(listings[0].price)
                            if (listings[0].type === "auction") {
                              setAuction(true);
                              if(currentDate){
                                console.log("count starts")
                                countDown(0);
                              }
                              console.log("this is setauction",auction)
                              endDate.current = listings[0].endDate;
                              //setInterval(countDown, 1000);
                            }
                    
                    
                            if (listings[0].sellerWalletAddress === wallet.address) {
                              setSellerView(true);
                            } else {
                              setBuyerView(true);
                              console.log("this is buyerview",buyerView)
                            }
                          }
                        });
                      });
                    });
                  }else{
                    newJsonLink.tokenID = tokenID;
                      sellerTokenID.current = newJsonLink.tokenID;
                      newJsonLink.owner = tokenOwner;

                      let imageLinkExtension = newJsonLink.image.split("/");
                      imageLinkExtension =
                        imageLinkExtension[imageLinkExtension.length - 1];

                      let newImageLink = ipfsGatewayTools.convertToDesiredGateway(
                        newJsonLink.image,
                        //"https://ipfs.io"
                        "https://mtv-art.mypinata.cloud"
                      );
                      if(!newImageLink.endsWith(imageLinkExtension))
                      newImageLink = newImageLink + "/" + imageLinkExtension;

                      newJsonLink.image = newImageLink;

                      setItemInfo(newJsonLink);
                      const blockNumber = await web3.eth.getBlockNumber();
                    
                      web3.eth.getBlock(blockNumber, (error, block) => {
                        const timestamp = block.timestamp;
                        // here you go
                        setCurrentDate(timestamp * 1000)
                        console.log("console",timestamp)
                        const listingsCollectionRef = collection(database, "listings");
                        const listingsCollectionQueryRef = query(
                          listingsCollectionRef,
                          where("contractAddress", "==", sellerContractAddress.current),
                          where("tokenID", "==", sellerTokenID.current),
                          where("status", "==", "listed")
                        );
                    
                        getDocs(listingsCollectionQueryRef).then(async(snapshot) => {
                          let listings = [];
                    
                          snapshot.docs.forEach((doc) => {
                            listings.push({ ...doc.data(), id: doc.id });
                            setListingInfo(listings[0]);
                          });
                    
                          if (listings.length === 1) {
                            setListingID(listings[0].listingID);
                            const web3 = new Web3(Web3.givenProvider);
                            await Web3.givenProvider.enable();
                            const contract = new web3.eth.Contract(
                              marketplaceContractABI,
                              marketplaceContractAddress
                            );
                            contract.methods.
                                getCurrentBidOwner(listings[0].listingID-1)
                                .call({
                                  from: wallet.address,
                                }).then((currentAddress) =>{
                                  
                                  if(currentAddress ===  wallet.address)
                                  {
                                    setBidOwner("You");
                                  }
                                  else{
                                    setBidOwner("")
                                  }
                                }
                                  )
                            setcurrentBidprice(listings[0].price);
                            setBidprice(listings[0].price)
                            if (listings[0].type === "auction") {
                              setAuction(true);
                              if(currentDate){
                                console.log("count starts")
                                countDown(0);
                              }
                              console.log("this is setauction",auction)
                              endDate.current = listings[0].endDate;
                              //setInterval(countDown, 1000);
                            }
                    
                    
                            if (listings[0].sellerWalletAddress === wallet.address) {
                              setSellerView(true);
                            } else {
                              setBuyerView(true);
                              console.log("this is buyerview",buyerView)
                            }
                          }
                        });
                      });
                  }
                })
                .catch((err) => {
                  navigate(`/assets/${collectionURL}`, { replace: true });
                });
            });
        }
      } else {
        navigate("/", { replace: true });
      }
    });
  }, [listingID]);

  // Functions
  const authenticateView = () => {
    const listingsCollectionRef = collection(database, "listings");
    const listingsCollectionQueryRef = query(
      listingsCollectionRef,
      where("contractAddress", "==", sellerContractAddress.current),
      where("tokenID", "==", sellerTokenID.current),
      where("status", "==", "listed")
    );

    getDocs(listingsCollectionQueryRef).then(async(snapshot) => {
      let listings = [];

      snapshot.docs.forEach((doc) => {
        listings.push({ ...doc.data(), id: doc.id });
        setListingInfo(listings[0]);
      });

      if (listings.length === 1) {
        setListingID(listings[0].listingID);
        const web3 = new Web3(Web3.givenProvider);
        await Web3.givenProvider.enable();
        const contract = new web3.eth.Contract(
          marketplaceContractABI,
          marketplaceContractAddress
        );
        contract.methods.
            getCurrentBidOwner(listings[0].listingID-1)
            .call({
              from: wallet.address,
            }).then((currentAddress) =>{
              
              if(currentAddress ===  wallet.address)
              {
                setBidOwner("You");
              }
              else{
                setBidOwner("")
              }
            }
              )
        setcurrentBidprice(listings[0].price);
        setBidprice(listings[0].price)
        if (listings[0].type === "auction") {
          setAuction(true);
          console.log("this is setauction",auction)
          endDate.current = listings[0].endDate;
          //setInterval(countDown, 1000);
        }


        if (listings[0].sellerWalletAddress === wallet.address) {
          setSellerView(true);
        } else {
          setBuyerView(true);
          console.log("this is buyerview",buyerView)
        }
      }
    });
  };

  
  const bid = async () => {
    if (Web3.givenProvider) {
      const web3 = new Web3(Web3.givenProvider);
      await Web3.givenProvider.enable();

      const contract = new web3.eth.Contract(
        marketplaceContractABI,
        marketplaceContractAddress
      );
      var tokens = web3.utils.toWei(bidprice.toString(), "ether");
      var bntokens = web3.utils.toBN(tokens);

      setModalTitle("Waiting...")
      setModalContent("Just a moment for comfirming...")
      setModalOpen(true);
      contract.methods
        .bid(listingID-1,bntokens)
        .send({
          from: wallet.address,
          value: bntokens,
        })
        .then((res) => {
          const listingsCollectionRef = doc(
            database,
            "listings",
            listingInfo.id
          );

          updateDoc(listingsCollectionRef, {
            price: bidprice,
            currentOwner: wallet.address,
          }).then(() => {
            setcurrentBidprice(bidprice)
            setBidprice(bidprice)
            setModalOpen(false)
            contract.methods.
            getCurrentBidOwner(listingID-1)
            .call({
              from: wallet.address,
            }).then((currentAddress) =>{
              
              if(currentAddress ===  wallet.address)
              {
                setBidOwner("You");
              }
              else{
                setBidOwner("")
              }
            }
              )
              const date = Date.now();
              const activitiesCollectionRef = collection(
                database,
                "activities"
              );

              addDoc(activitiesCollectionRef, {
                contractAddress: collectionInfo.contractAddress,
                tokenID: itemInfo.tokenID,
                walletAddress: wallet.address,
                action: "Auction Bid",
                date: date,
              }).then(() => {
               
              });
            
          });
        }).catch((e)=>{
          setModalOpen(false)
        });
    }
  };

  const claimNFT = async () => {
 try{
      const web3 = new Web3("https://rpc.mtv.ac")
      let account = web3.eth.accounts.privateKeyToAccount(privateKey);

  
      const contract1 = new web3.eth.Contract(
        placeholderContractABI,
        collectionInfo.contractAddress,
      )
      try {

        const owners = await contract1.methods
        .owner()
        .call({from: wallet.address})

        
      const contract = new web3.eth.Contract(
        marketplaceContractABI,
        marketplaceContractAddress
      );
      console.log("owner claimed");

      var tokens = web3.utils.toWei(listingInfo.price.toString(), "ether");
      var bntokens = web3.utils.toBN(tokens);

      const transaction = contract.methods.claimNFT(listingID-1, parseInt(100/collectionInfo.royalty));
      let estimatedGas = await transaction.estimateGas({ from: account.address });

      const options = {
        to: transaction._parent._address,
        gas: estimatedGas * 2, //sometimes estimate is wrong and we don't care if more gas is needed
        data: transaction.encodeABI(),
      };

      const signed = await web3.eth.accounts.signTransaction(options, privateKey);
      const receipt = await web3.eth.sendSignedTransaction(signed.rawTransaction);
      console.log("owner is",owners);


      const listingsCollectionRef = doc(
        database,
        "listings",
        listingInfo.id
      );

      updateDoc(listingsCollectionRef, {
        status: "NFTclaimed",
      })
      const date = Date.now();
      const salesCollectionRef = collection(database, "sales");

      addDoc(salesCollectionRef, {
        listingID: listingInfo.id,
        contractAddress: collectionInfo.contractAddress,
        tokenID: itemInfo.tokenID,
        sellerWalletAddress: listingInfo.sellerWalletAddress,
        buyerWalletAddress: wallet.address,
        price: listingInfo.price,
        date: date,
      }).then(() => {
        const date = Date.now();
        const activitiesCollectionRef = collection(
          database,
          "activities"
        );

        addDoc(activitiesCollectionRef, {
          contractAddress: collectionInfo.contractAddress,
          tokenID: itemInfo.tokenID,
          walletAddress: wallet.address,
          action: "Auction Buy",
          date: date,
        }).then(() => {
          navigate(`/profile`, { replace: true });
        });
      }); }catch(e) {
        if(e.toString().search("still open") != -1) throw e;
        
      const contract = new web3.eth.Contract(
        marketplaceContractABI,
        marketplaceContractAddress
      );

      var tokens = web3.utils.toWei(listingInfo.price.toString(), "ether");
      var bntokens = web3.utils.toBN(tokens);

      const transaction = contract.methods.claimNFT_none(listingID-1);
      let estimatedGas = await transaction.estimateGas({ from: account.address });

      const options = {
        to: transaction._parent._address,
        gas: estimatedGas * 2, //sometimes estimate is wrong and we don't care if more gas is needed
        data: transaction.encodeABI(),
      };

      const signed = await web3.eth.accounts.signTransaction(options, privateKey);
      const receipt = await web3.eth.sendSignedTransaction(signed.rawTransaction);
    
      const listingsCollectionRef = doc(
        database,
        "listings",
        listingInfo.id
      );

      updateDoc(listingsCollectionRef, {
        status: "NFTclaimed",
      })
      const date = Date.now();
      const salesCollectionRef = collection(database, "sales");

      addDoc(salesCollectionRef, {
        listingID: listingInfo.id,
        contractAddress: collectionInfo.contractAddress,
        tokenID: itemInfo.tokenID,
        sellerWalletAddress: listingInfo.sellerWalletAddress,
        buyerWalletAddress: wallet.address,
        price: listingInfo.price,
        date: date,
      }).then(() => {
        const date = Date.now();
        const activitiesCollectionRef = collection(
          database,
          "activities"
        );

        addDoc(activitiesCollectionRef, {
          contractAddress: collectionInfo.contractAddress,
          tokenID: itemInfo.tokenID,
          walletAddress: wallet.address,
          action: "Auction Buy",
          date: date,
        }).then(() => {
          console.log("catch................")

          navigate(`/profile`, { replace: true });
        });
      });
      }
    }catch(e)  {
      if(e.toString().search("still open") != -1)
        setTimeout(() => {
          claimNFT()
        }, 5000);
      else{
        const listingsCollectionRef = doc(
          database,
          "listings",
          listingInfo.id
        );
          console.log("catch(e) else")
        updateDoc(listingsCollectionRef, {
          status: "NFTclaimed",
        })
        const date = Date.now();
        const salesCollectionRef = collection(database, "sales");
  
        addDoc(salesCollectionRef, {
          listingID: listingInfo.id,
          contractAddress: collectionInfo.contractAddress,
          tokenID: itemInfo.tokenID,
          sellerWalletAddress: listingInfo.sellerWalletAddress,
          buyerWalletAddress: wallet.address,
          price: listingInfo.price,
          date: date,
        }).then(() => {
          const date = Date.now();
          const activitiesCollectionRef = collection(
            database,
            "activities"
          );
  
          addDoc(activitiesCollectionRef, {
            contractAddress: collectionInfo.contractAddress,
            tokenID: itemInfo.tokenID,
            walletAddress: wallet.address,
            action: "Auction Buy",
            date: date,
          }).then(() => {
            navigate(`/profile`, { replace: true });
          });
        });
      }

    }

      
   
  };



  const buy = async () => {
    if (Web3.givenProvider) {
      const web3 = new Web3(Web3.givenProvider);
      await Web3.givenProvider.enable();


      const contract1 = new web3.eth.Contract(
        placeholderContractABI,
        collectionInfo.contractAddress,
      )
      try {

        const owners = await contract1.methods
        .owner()
        .call({from: wallet.address})
        
        const contract = new web3.eth.Contract(
          marketplaceContractABI,
          marketplaceContractAddress
          );
          
          var tokens = web3.utils.toWei(listingInfo.price.toString(), "ether");
          var bntokens = web3.utils.toBN(tokens);
          console.log("buy method is ",listingID);
          
          setModalTitle("Buying...")
          setModalContent("Just a moment for comfirming...")
          setModalOpen(true);
          contract.methods
          .buy(listingID,parseInt(100 / collectionInfo.royalty))
          .send({
            from: wallet.address,
            value:bntokens,
          })
          .then((res) => {
            const listingsCollectionRef = doc(
              database,
              "listings",
            listingInfo.id
          );

          updateDoc(listingsCollectionRef, {
            status: "sold",
          }).then(() => {
            const date = Date.now();
            const salesCollectionRef = collection(database, "sales");

            addDoc(salesCollectionRef, {
              listingID: listingInfo.id,
              contractAddress: collectionInfo.contractAddress,
              tokenID: itemInfo.tokenID,
              sellerWalletAddress: listingInfo.sellerWalletAddress,
              buyerWalletAddress: wallet.address,
              price: listingInfo.price,
              date: date,
            }).then(() => {
              const date = Date.now();
              const activitiesCollectionRef = collection(
                database,
                "activities"
              );

              addDoc(activitiesCollectionRef, {
                contractAddress: collectionInfo.contractAddress,
                tokenID: itemInfo.tokenID,
                walletAddress: wallet.address,
                action: "Buy",
                date: date,
              }).then(() => {
                navigate(`/profile`, { replace: true });
              });
            });
          });
        }).catch((e) => {
          setModalOpen(false);
        });
      } catch{
        const contract = new web3.eth.Contract(
          marketplaceContractABI,
          marketplaceContractAddress
          );
          
          var tokens = web3.utils.toWei(listingInfo.price.toString(), "ether");
          var bntokens = web3.utils.toBN(tokens);
          console.log("buy method is ",listingID);
          setModalTitle("Buying")
          setModalContent("Just a moment for confirming...")
          setModalOpen(true)
          contract.methods
          .buy_none(listingID)
          .send({
            from: wallet.address,
            value:bntokens,
          })
          .then((res) => {
            const listingsCollectionRef = doc(
              database,
              "listings",
            listingInfo.id
          );

          updateDoc(listingsCollectionRef, {
            status: "sold",
          }).then(() => {
            const date = Date.now();
            const salesCollectionRef = collection(database, "sales");

            addDoc(salesCollectionRef, {
              listingID: listingInfo.id,
              contractAddress: collectionInfo.contractAddress,
              tokenID: itemInfo.tokenID,
              sellerWalletAddress: listingInfo.sellerWalletAddress,
              buyerWalletAddress: wallet.address,
              price: listingInfo.price,
              date: date,
            }).then(() => {
              const date = Date.now();
              const activitiesCollectionRef = collection(
                database,
                "activities"
              );

              addDoc(activitiesCollectionRef, {
                contractAddress: collectionInfo.contractAddress,
                tokenID: itemInfo.tokenID,
                walletAddress: wallet.address,
                action: "Buy",
                date: date,
              }).then(() => {
                navigate(`/profile`, { replace: true });
              });
            });
          });
        }).catch((e) => {
          setModalOpen(false)
        });
      }
      }
    };
    
  const delist = async () => {
    if (Web3.givenProvider) {
      console.log("dog")
      const web3 = new Web3(Web3.givenProvider);
      await Web3.givenProvider.enable();

      const contract = new web3.eth.Contract(
        marketplaceContractABI,
        marketplaceContractAddress
      );

      setModalTitle("Delisting...")
      setModalContent("Just a moment for comfirming...")
      setModalOpen(true);
      contract.methods
        .delist(listingID)
        .send({
          from: wallet.address,
        })
        .then(() => {
          console.log("good dog")
          const listingsCollectionRef = doc(
            database,
            "listings",
            listingInfo.id
          );

          updateDoc(listingsCollectionRef, {
            status: "delisted",
          }).then(() => {
            const date = Date.now();
            const activitiesCollectionRef = collection(database, "activities");

            addDoc(activitiesCollectionRef, {
              contractAddress: collectionInfo.contractAddress,
              tokenID: itemInfo.tokenID,
              walletAddress: wallet.address,
              action: "delist",
              date: date,
            }).then(() => {
              console.log("bad dog")
             navigate(`/profile`, { replace: true });
            });
          });
        }).catch((e)=>{
          setModalOpen(false)
        });
    }
  };
  const claim = async () => {
    if (Web3.givenProvider) {
      const web3 = new Web3(Web3.givenProvider);
      await Web3.givenProvider.enable();

      const contract = new web3.eth.Contract(
        marketplaceContractABI,
        marketplaceContractAddress
      );
      
      setModalTitle("Claiming...")
      setModalContent("Just a moment for comfirming...")
      setModalOpen(true);
      contract.methods
        .refund(listingID-1)
        .send({
          from: wallet.address,
        })
        .then(() => {
          const listingsCollectionRef = doc(
            database,
            "listings",
            listingInfo.id
          );

          updateDoc(listingsCollectionRef, {
            status: "delisted",
          }).then(() => {
            const date = Date.now();
            const activitiesCollectionRef = collection(database, "activities");

            addDoc(activitiesCollectionRef, {
              contractAddress: collectionInfo.contractAddress,
              tokenID: itemInfo.tokenID,
              walletAddress: wallet.address,
              action: "refund",
              date: date,
            }).then(() => {
              navigate(`/profile`, { replace: true });
            });
          });
        }).catch((e) => {
          setModalOpen(false)
        });
    }
  };
 
  return (
    <React.Fragment>
      <Waiting title = {modalTitle} isOpen ={modalOpen} content = {modalContent}/>
      <main className="asset-page">
        <section className="asset">
          <div className="container">
            <div className="asset-left">
              <img src={itemInfo.image ? itemInfo.image : null} alt="" />
            </div>

            <div className="asset-right">
              <h1>{itemInfo.name ? itemInfo.name : null}</h1>

              <div className="owner-and-collection">
                <Link to={`/assets/${collectionInfo.url}`}>
                  <div className="collection">
                    <span>Collection</span>

                    <div className="collection-info">
                      <div className="logo-image-placeholder">
                        <img
                          src={
                            collectionInfo.logoImage !== "default"
                              ? collectionInfo.logoImage
                              : null
                          }
                          alt=""
                          className={
                            collectionInfo.logoImage !== "default"
                              ? null
                              : "disabled"
                          }
                        />
                      </div>
                      <p>{collectionInfo.title}</p>
                    </div>
                  </div>
                </Link>
              </div>

              <p className="description">
                {itemInfo.description ? itemInfo.description : null}
              </p>

              <div className="properties">
                <span>Properties</span>

                <div className="properties-wrapper">
                  {itemInfo.attributes && itemInfo.attributes.length != 0 && itemInfo.attributes != "[]"
                    ? itemInfo.attributes.map((attribute, index) => {
                        return (
                          <div className="property" key={index}>
                            <h6>{attribute.trait_type}</h6>
                            <h5>{attribute.value}</h5>
                          </div>
                        );
                      })
                    : null}
                </div>
              </div>

              {auction ? (
                !auctionEnded ? (
                  <div className="countdown">
                    <p>
                      {day1}
                      {day2} Days
                    </p>
                    <span>:</span>
                    <p>
                      {hour1}
                      {hour2} Hours
                    </p>
                    <span>:</span>
                    <p>
                      {minute1}
                      {minute2} Minutes
                    </p>
                    <span>:</span>
                    <p>
                      {second1}
                      {second2} Seconds
                    </p>
                  </div>
                ) : (
                  <p className="auction-ended-text">Time is up!</p>
                )
              ) : null}

              {itemInfo.owner === wallet.address ? (
                <div className="btns">
                  <Link
                    to={`/assets/${collectionInfo.url}/${itemInfo.tokenID}/list`}
                  >
                    <button className="primary-btn">
                      <span>List for sale</span>
                    </button>
                  </Link>
                </div>
              ) : null}

              {currentbidprice ? (
                <div className="listing-price">
                  <img src="/images/pages/asset/mtv-icon.png" alt="" />
                  <p>
                  {bidOwner == "" ? (<>
                  {currentbidprice} MTV{" "} <br/>
                    <span>${currentbidprice * 0.006067}</span>
                  </>
                    ) 
                    : (<Badge.Ribbon text = {bidOwner} color ="cyan" className="text-white">
                    {currentbidprice} MTV{" "} <br/>
                    <span>${currentbidprice * 0.006067}</span>
                  </Badge.Ribbon>)}
                  </p>
                  {auction?
                  <p> 
                    OriginPrice:{listingInfo.originPrice} MTV
                  </p>
                  :<></>
                }
                </div>
              ) : null}
             

              {sellerView ? (
                auction? (
                  !auctionEnded? (
                <div className="btns">
                  <button disabled className="primary-btn disable" onClick={claim}>
                    <span>Delist</span>
                  </button>
                </div>
                  ) :(
                    <div className="btns">
                  <button className="primary-btn" onClick={claim}>
                    <span>Claim</span>
                  </button>
                </div>
                  )
              ) : (
                <div className="btns">
                  <button className="primary-btn" onClick={delist}>
                    <span>Delist</span>
                  </button>
                </div>
                  )
               ) : null}
              
              {buyerView ? (
                auction ? (
                  auctionEnded ? (null) : (
                    <div className="btns">
                      <button className="primary-btn" onClick={bid}>
                        <span>Bid now</span>
                      </button>
                      <InputNumber type="number" min ={currentbidprice} defaultValue={currentbidprice} className="bidinput" onChange={(value)=>{setBidprice(value)}}></InputNumber>
                    </div>
                  )
                ) : (
                  <div className="btns">
                    <button className="primary-btn" onClick={buy}>
                      <span>Buy now</span>
                    </button>
                  </div>
                )
              ) : null}
           



            </div>
          </div>
        </section>
      </main>
    </React.Fragment>
  );
};

export default Asset;
