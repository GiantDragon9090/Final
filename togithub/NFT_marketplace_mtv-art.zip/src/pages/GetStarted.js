import React from "react";
import { Link } from "react-router-dom";

// Redux
import { useSelector } from "react-redux";

// Components
import Authenticator from "../components/Authenticator";

import { notification } from "antd";

const GetStarted = () => {
  // States
  const authenticated = useSelector((state) => state.authenticated);
  const createCollection = () => {
    notification.info({
      message: "Coming soon!",
      description:""
    })
  }
  return (
    <React.Fragment>
      <Authenticator />

      {authenticated ? (
        <main className="get-started-page">
          <section className="boxes">
            <div className="container">
              <h1>Get started</h1>
              <p className="sub-title">
                Choose the most suitable option for your needs. You need to sign
                in for creation
              </p>

              <div className="boxes-wrapper">
                <div className="box">
                  <i className="bi bi-cloud-arrow-down-fill"></i>

                  <h3>Import collection</h3>
                  <Link to="/import-collection">
                    <button>
                      <span>Continue</span>
                    </button>
                  </Link>
                </div>

                <div className="box">
                  <i className="bi bi-plus-circle-fill"></i>

                  <h3>Create collection</h3>
                
                    <button onClick={createCollection}>
                      <span>Continue</span>
                    </button>
                 
                </div>
              </div>
            </div>
          </section>
        </main>
      ) : (
        <p className="loader">Loading...</p>
      )}
    </React.Fragment>
  );
};

export default GetStarted;
