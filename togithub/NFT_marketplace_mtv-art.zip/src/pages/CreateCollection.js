import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

// Redux
import { useSelector } from "react-redux";

// Web3
import Web3 from "web3";
import Web3Modal from "web3modal";

// Firebase
import { addDoc, collection, getDocs, query, where } from "firebase/firestore";
import database from "../config/firebase";

// Components
import Authenticator from "../components/Authenticator";

const CreateCollection = () => {
  // States
  const navigate = useNavigate();

  const wallet = useSelector((state) => state.wallet);
  const authenticated = useSelector((state) => state.authenticated);

  const [collectionInfo, setCollectionInfo] = useState({
    type: "created",
    contractAddress: "",
    ownerUserID: wallet.id,
    ownerWalletAddress: wallet.address,
    logoImage: "default",
    bannerImage: "default",
    title: "",
    url: "",
    description: "",
    websiteLink: "",
    discordLink: "",
    twitterLink: "",
    instagramLink: "",
    mintAble: false,
    verified: false,
    createdOn: Date.now(),
  });

  const [logoImage, setLogoImage] = useState("default");
  const [logoImageFile, setLogoImageFile] = useState(null);

  const [bannerImage, setBannerImage] = useState("default");
  const [bannerImageFile, setBannerImageFile] = useState(null);

  // Functions
  const submit = async (e) => {
    e.preventDefault();

    if (Web3.givenProvider) {
      const web3 = new Web3(Web3.givenProvider);
      await Web3.givenProvider.enable();

      const walletAddresses = await web3.eth.getAccounts();
      const walletAddress = walletAddresses[0];

      let abi =
        '[	{		"inputs": [],		"stateMutability": "nonpayable",		"type": "constructor"	},	{		"anonymous": false,		"inputs": [			{				"indexed": true,				"internalType": "address",				"name": "owner",				"type": "address"			},			{				"indexed": true,				"internalType": "address",				"name": "approved",				"type": "address"			},			{				"indexed": true,				"internalType": "uint256",				"name": "tokenId",				"type": "uint256"			}		],		"name": "Approval",		"type": "event"	},	{		"anonymous": false,		"inputs": [			{				"indexed": true,				"internalType": "address",				"name": "owner",				"type": "address"			},			{				"indexed": true,				"internalType": "address",				"name": "operator",				"type": "address"			},			{				"indexed": false,				"internalType": "bool",				"name": "approved",				"type": "bool"			}		],		"name": "ApprovalForAll",		"type": "event"	},	{		"inputs": [			{				"internalType": "address",				"name": "to",				"type": "address"			},			{				"internalType": "uint256",				"name": "tokenId",				"type": "uint256"			}		],		"name": "approve",		"outputs": [],		"stateMutability": "nonpayable",		"type": "function"	},	{		"inputs": [			{				"internalType": "string",				"name": "uri",				"type": "string"			}		],		"name": "mint",		"outputs": [			{				"internalType": "uint256",				"name": "",				"type": "uint256"			}		],		"stateMutability": "nonpayable",		"type": "function"	},	{		"inputs": [			{				"internalType": "address",				"name": "from",				"type": "address"			},			{				"internalType": "address",				"name": "to",				"type": "address"			},			{				"internalType": "uint256",				"name": "tokenId",				"type": "uint256"			}		],		"name": "safeTransferFrom",		"outputs": [],		"stateMutability": "nonpayable",		"type": "function"	},	{		"inputs": [			{				"internalType": "address",				"name": "from",				"type": "address"			},			{				"internalType": "address",				"name": "to",				"type": "address"			},			{				"internalType": "uint256",				"name": "tokenId",				"type": "uint256"			},			{				"internalType": "bytes",				"name": "_data",				"type": "bytes"			}		],		"name": "safeTransferFrom",		"outputs": [],		"stateMutability": "nonpayable",		"type": "function"	},	{		"inputs": [			{				"internalType": "address",				"name": "operator",				"type": "address"			},			{				"internalType": "bool",				"name": "approved",				"type": "bool"			}		],		"name": "setApprovalForAll",		"outputs": [],		"stateMutability": "nonpayable",		"type": "function"	},	{		"anonymous": false,		"inputs": [			{				"indexed": true,				"internalType": "address",				"name": "from",				"type": "address"			},			{				"indexed": true,				"internalType": "address",				"name": "to",				"type": "address"			},			{				"indexed": true,				"internalType": "uint256",				"name": "tokenId",				"type": "uint256"			}		],		"name": "Transfer",		"type": "event"	},	{		"inputs": [			{				"internalType": "address",				"name": "from",				"type": "address"			},			{				"internalType": "address",				"name": "to",				"type": "address"			},			{				"internalType": "uint256",				"name": "tokenId",				"type": "uint256"			}		],		"name": "transferFrom",		"outputs": [],		"stateMutability": "nonpayable",		"type": "function"	},	{		"inputs": [			{				"internalType": "address",				"name": "owner",				"type": "address"			}		],		"name": "balanceOf",		"outputs": [			{				"internalType": "uint256",				"name": "",				"type": "uint256"			}		],		"stateMutability": "view",		"type": "function"	},	{		"inputs": [			{				"internalType": "uint256",				"name": "tokenId",				"type": "uint256"			}		],		"name": "getApproved",		"outputs": [			{				"internalType": "address",				"name": "",				"type": "address"			}		],		"stateMutability": "view",		"type": "function"	},	{		"inputs": [			{				"internalType": "address",				"name": "owner",				"type": "address"			},			{				"internalType": "address",				"name": "operator",				"type": "address"			}		],		"name": "isApprovedForAll",		"outputs": [			{				"internalType": "bool",				"name": "",				"type": "bool"			}		],		"stateMutability": "view",		"type": "function"	},	{		"inputs": [			{				"internalType": "uint256",				"name": "",				"type": "uint256"			}		],		"name": "Items",		"outputs": [			{				"internalType": "uint256",				"name": "id",				"type": "uint256"			},			{				"internalType": "string",				"name": "uri",				"type": "string"			}		],		"stateMutability": "view",		"type": "function"	},	{		"inputs": [],		"name": "marketplace",		"outputs": [			{				"internalType": "address",				"name": "",				"type": "address"			}		],		"stateMutability": "view",		"type": "function"	},	{		"inputs": [],		"name": "name",		"outputs": [			{				"internalType": "string",				"name": "",				"type": "string"			}		],		"stateMutability": "view",		"type": "function"	},	{		"inputs": [			{				"internalType": "uint256",				"name": "tokenId",				"type": "uint256"			}		],		"name": "ownerOf",		"outputs": [			{				"internalType": "address",				"name": "",				"type": "address"			}		],		"stateMutability": "view",		"type": "function"	},	{		"inputs": [			{				"internalType": "bytes4",				"name": "interfaceId",				"type": "bytes4"			}		],		"name": "supportsInterface",		"outputs": [			{				"internalType": "bool",				"name": "",				"type": "bool"			}		],		"stateMutability": "view",		"type": "function"	},	{		"inputs": [],		"name": "symbol",		"outputs": [			{				"internalType": "string",				"name": "",				"type": "string"			}		],		"stateMutability": "view",		"type": "function"	},	{		"inputs": [			{				"internalType": "uint256",				"name": "index",				"type": "uint256"			}		],		"name": "tokenByIndex",		"outputs": [			{				"internalType": "uint256",				"name": "",				"type": "uint256"			}		],		"stateMutability": "view",		"type": "function"	},	{		"inputs": [			{				"internalType": "address",				"name": "owner",				"type": "address"			},			{				"internalType": "uint256",				"name": "index",				"type": "uint256"			}		],		"name": "tokenOfOwnerByIndex",		"outputs": [			{				"internalType": "uint256",				"name": "",				"type": "uint256"			}		],		"stateMutability": "view",		"type": "function"	},	{		"inputs": [			{				"internalType": "uint256",				"name": "tokenId",				"type": "uint256"			}		],		"name": "tokenURI",		"outputs": [			{				"internalType": "string",				"name": "",				"type": "string"			}		],		"stateMutability": "view",		"type": "function"	},	{		"inputs": [],		"name": "totalSupply",		"outputs": [			{				"internalType": "uint256",				"name": "",				"type": "uint256"			}		],		"stateMutability": "view",		"type": "function"	}]';
      let bytecode =
        "00057600080fd5b50565b61300c8161294c565b811461301757600080fd5b50565b61302381612998565b811461302e57600080fd5b5056fea2646970667358221220ba627304c03d83a40a8ea89495e4c8fc2ce6abac393afcf02e8930f99a6bf94e64736f6c63430008070033";
    
      const collectionsCollectionRef = collection(database, "collections");

      let deploy_contract = new web3.eth.Contract(JSON.parse(abi));
      let account = walletAddress;

      let payload = {
        data: bytecode,
      };

      let parameter = {
        from: account,
        gas: web3.utils.toHex(800000),
        gasPrice: web3.utils.toHex(web3.utils.toWei("30", "gwei")),
      };

      deploy_contract
        .deploy(payload)
        .send(parameter, (err, transactionHash) => {
          console.log("Transaction Hash :", transactionHash);
        })
        .on("confirmation", () => {})
        .then(async (newContractInstance) => {
          const logoImageData = new FormData();

          logoImageData.append("file", logoImageFile);
          logoImageData.append("upload_preset", "images");

          const logoImageRes = await fetch(
            "https://api.cloudinary.com/v1_1/mtv-art/image/upload",
            {
              method: "post",
              body: logoImageData,
            }
          );

          const logoImageResFile = await logoImageRes.json();

          const bannerImageData = new FormData();

          bannerImageData.append("file", bannerImageFile);
          bannerImageData.append("upload_preset", "images");

          const bannerImageRes = await fetch(
            "https://api.cloudinary.com/v1_1/mtv-art/image/upload",
            {
              method: "post",
              body: bannerImageData,
            }
          );

          const bannerImageResFile = await bannerImageRes.json();

          let newCollectionInfo = {
            ...collectionInfo,
            contractAddress: newContractInstance.options.address,
            logoImage: logoImageResFile.secure_url,
            bannerImage: bannerImageResFile.secure_url,
          };

          addDoc(collectionsCollectionRef, newCollectionInfo).then(() => {
            navigate("/profile", { replace: true });
          });
        });
    }
  };

  const updateLogoImage = (e) => {
    const files = e.target.files;
    setLogoImageFile(files[0]);

    const objectUrl = URL.createObjectURL(files[0]);

    setLogoImage(objectUrl);
  };

  const updateBannerImage = (e) => {
    const files = e.target.files;
    setBannerImageFile(files[0]);

    const objectUrl = URL.createObjectURL(files[0]);

    setBannerImage(objectUrl);
  };

  return (
    <React.Fragment>
      <Authenticator />

      {authenticated ? (
        <main className="import-create-collection-page">
          <section className="collection">
            <div className="container">
              <h1>Create collection</h1>
              <p className="sub-title">
                You can set preferred display name, url and manage <br />
                other personal settings
              </p>

              <form onSubmit={submit}>
                <div className="input-group logo-image-input-group">
                  <label>Logo image</label>

                  <input type="file" onChange={updateLogoImage} required />
                  <div className="logo-image-placeholder">
                    <img
                      src={logoImage !== "default" ? logoImage : null}
                      alt=""
                      className={logoImage !== "default" ? null : "disabled"}
                    />
                  </div>
                </div>

                <div className="input-group banner-image-input-group">
                  <label>Banner image</label>

                  <input type="file" onChange={updateBannerImage} required />
                  <div className="banner-image-placeholder">
                    <img
                      src={bannerImage !== "default" ? bannerImage : null}
                      alt=""
                      className={bannerImage !== "default" ? null : "disabled"}
                    />
                  </div>
                </div>

                <div className="input-group">
                  <label>Title</label>
                  <input
                    type="text"
                    value={collectionInfo.title}
                    onChange={(e) => {
                      setCollectionInfo({
                        ...collectionInfo,
                        title: e.target.value,
                      });
                    }}
                    required
                  />
                </div>

                <div className="input-group">
                  <label>URL</label>
                  <input
                    type="text"
                    value={collectionInfo.url}
                    onChange={(e) => {
                      setCollectionInfo({
                        ...collectionInfo,
                        url: e.target.value,
                      });
                    }}
                    required
                  />
                </div>

                <div className="input-group">
                  <label>Description</label>
                  <textarea
                    type="text"
                    onChange={(e) => {
                      setCollectionInfo({
                        ...collectionInfo,
                        description: e.target.value,
                      });
                    }}
                    defaultValue={collectionInfo.description}
                    required
                  ></textarea>
                </div>

                <div className="input-group">
                  <label>Website</label>
                  <input
                    type="text"
                    value={collectionInfo.websiteLink}
                    onChange={(e) => {
                      setCollectionInfo({
                        ...collectionInfo,
                        websiteLink: e.target.value,
                      });
                    }}
                  />
                </div>

                <div className="input-group">
                  <label>Discord</label>
                  <input
                    type="text"
                    value={collectionInfo.discordLink}
                    onChange={(e) => {
                      setCollectionInfo({
                        ...collectionInfo,
                        discordLink: e.target.value,
                      });
                    }}
                  />
                </div>

                <div className="input-group">
                  <label>Twitter</label>
                  <input
                    type="text"
                    value={collectionInfo.twitterLink}
                    onChange={(e) => {
                      setCollectionInfo({
                        ...collectionInfo,
                        twitterLink: e.target.value,
                      });
                    }}
                  />
                </div>

                <div className="input-group">
                  <label>Instagram</label>
                  <input
                    type="text"
                    value={collectionInfo.instagramLink}
                    onChange={(e) => {
                      setCollectionInfo({
                        ...collectionInfo,
                        instagramLink: e.target.value,
                      });
                    }}
                  />
                </div>

                <button>
                  <span>Create collection</span>
                </button>
              </form>
            </div>
          </section>
        </main>
      ) : (
        <p className="loader">Loading...</p>
      )}
    </React.Fragment>
  );
};

export default CreateCollection;
