import React, { useEffect, useState } from "react";

// Web3
import Web3 from "web3";

// Firebase
import { collection, getDocs, query, where } from "firebase/firestore";
import database from "../config/firebase";

const Activities = () => {
  // States
  const [activities, setActivities] = useState([]);

  // Fetch Collections
  useEffect(() => {
    if (Web3.givenProvider) {
      const collectionsCollectionRef = collection(database, "collections");

      getDocs(collectionsCollectionRef).then((snapshot) => {
        let collections = [];

        snapshot.docs.forEach((doc) => {
          collections.push(doc.data());
        });

        collections.forEach((collectionInfo) => {
          const collectionsCollectionRef = collection(database, "collections");
          const collectionsCollectionQueryRef = query(
            collectionsCollectionRef,
            where("contractAddress", "==", collectionInfo.contractAddress)
          );

          getDocs(collectionsCollectionQueryRef).then(async (snapshot) => {
            let collections = [];

            snapshot.docs.forEach((doc) => {
              collections.push({ ...doc.data(), id: doc.id });
            });

            const activitiesCollectionRef = collection(database, "activities");
            const activitiesCollectionQueryRef = query(
              activitiesCollectionRef,
              where("contractAddress", "==", collections[0].contractAddress)
            );

            getDocs(activitiesCollectionQueryRef).then((snapshot) => {
              snapshot.docs.forEach((doc) => {
                setActivities((activities) => {
                  return [...activities, doc.data()];
                });
              });
            });
          });
        });
      });
    }
  }, []);

  return (
    <React.Fragment>
      <main className="activities-page">
        <section className="activities">
          <div className="container">
            <h1>All activities</h1>

            <div className="activities-wrapper">
              <div className="title-row">
                <p>From</p>
                <p>Token ID</p>
                <p>Action</p>
                <p>Date</p>
              </div>
              {activities.map((activity, index) => {
                return (
                  <div className="row" key={index}>
                    <p className="collection">{activity.walletAddress}</p>
                    <p>{activity.tokenID}</p>
                    <p className="action">{activity.action}</p>
                    <p>{new Date(activity.date).toDateString()}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>
      </main>
    </React.Fragment>
  );
};

export default Activities;
