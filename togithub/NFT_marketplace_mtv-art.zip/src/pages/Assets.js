import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import IPFSGatewayTools from "@pinata/ipfs-gateway-tools/dist/browser";
import axios from "axios";
import { convertJsonLinks, getObjectType } from "./util";
// Web3
import Web3 from "web3";

// Firebase
import { collection, getDocs, query, where } from "firebase/firestore";
import database from "../config/firebase";

// Contracts Data
import { placeholderContractABI } from "../data/smart-contracts";

const Assets = () => {
  // States
  const ipfsGatewayTools = new IPFSGatewayTools();

  const [onSaleNFTs, setOnSaleNFTs] = useState([]);
  const [NFTs, setNFTs] = useState([]);

  const [activeFilter, setActiveFilter] = useState(1);

  const [tab, setTab] = useState("all");

  // Fetch On Sale NFTs
  useEffect(async () => {
    if (Web3.givenProvider) {
      const listingsCollectionRef = collection(database, "listings");
      const listingsCollectionQueryRef = query(
        listingsCollectionRef,
        where("status", "==", "listed")
      );

      getDocs(listingsCollectionQueryRef).then((snapshot) => {
        let listings = [];

        snapshot.docs.forEach((doc) => {
          listings.push({ ...doc.data(), id: doc.id });
        });

        listings.forEach(async (listing) => {
          const web3 = new Web3(Web3.givenProvider);
          await Web3.givenProvider.enable();

          const contract = new web3.eth.Contract(
            placeholderContractABI,
            listing.contractAddress
          );

          let collectionURL = "";
          let collectionTitle = "";
          let collectionLogoImage = "";

          const collectionsCollectionRef = collection(database, "collections");
          const collectionsCollectionQueryRef = query(
            collectionsCollectionRef,
            where("contractAddress", "==", listing.contractAddress)
          );

          getDocs(collectionsCollectionQueryRef).then((snapshot) => {
            let collections = [];

            snapshot.docs.forEach((doc) => {
              collections.push({ ...doc.data(), id: doc.id });
              collectionURL = collections[0].url;
              collectionTitle = collections[0].title;
              collectionLogoImage = collections[0].logoImage;
            });

            contract.methods
              .tokenURI(listing.tokenID)
              .call()
              .then((jsonLink) => {
                const newJsonLink = convertJsonLinks(jsonLink)
                if(getObjectType(newJsonLink) == "string"){
                axios.get(newJsonLink).then((res) => {
                  res.data.collectionURL = collectionURL;
                  res.data.collectionTitle = collectionTitle;
                  res.data.collectionLogoImage = collectionLogoImage;
                  res.data.tokenID = listing.tokenID;
                  res.data.price = listing.price;

                  setOnSaleNFTs((onSaleNFTs) => {
                    return [...onSaleNFTs, res.data];
                  });
                });
              }else{
                newJsonLink.collectionURL = collectionURL;
                newJsonLink.collectionTitle = collectionTitle;
                newJsonLink.collectionLogoImage = collectionLogoImage;
                newJsonLink.tokenID = listing.tokenID;
                newJsonLink.price = listing.price;

                  setOnSaleNFTs((onSaleNFTs) => {
                    return [...onSaleNFTs, newJsonLink];
                  });
              }
              });
          });
        });
      });
    }
  }, []);

  // Fetch NFTs
  useEffect(async () => {
    if (Web3.givenProvider) {
      const collectionsCollectionRef = collection(database, "collections");

      getDocs(collectionsCollectionRef).then((snapshot) => {
        let collections = [];

        snapshot.docs.forEach((doc) => {
          collections.push({ ...doc.data(), id: doc.id });
        });

        collections.forEach(async (collection) => {
          const web3 = new Web3(Web3.givenProvider);
          await Web3.givenProvider.enable();

          const contract = new web3.eth.Contract(
            placeholderContractABI,
            collection.contractAddress
          );

          contract.methods
            .totalSupply()
            .call()
            .then((totalSupplyRes) => {
              if (totalSupplyRes > 0 )
              {

              for (let i = 1; i <= 16; i++) {
                contract.methods
                  .tokenURI(i)
                  .call()
                  .then((jsonLink) => {
                    const newJsonLink = convertJsonLinks(jsonLink)
                if(getObjectType(newJsonLink) == "string"){
                    axios.get(newJsonLink).then((res) => {
                      res.data.tokenID = i;
                      res.data.collectionURL = collection.url;
                      res.data.collectionTitle = collection.title;
                      res.data.collectionLogoImage = collection.logoImage;

                      setNFTs((NFTs) => {
                        return [...NFTs, res.data];
                      });
                    });
                  }else{
                    newJsonLink.tokenID = i;
                    newJsonLink.collectionURL = collection.url;
                    newJsonLink.collectionTitle = collection.title;
                    newJsonLink.collectionLogoImage = collection.logoImage;

                    setNFTs((NFTs) => {
                      return [...NFTs, newJsonLink];
                    });
                  }
                  });
              }
            }
            });
        });
      });
    }
  }, []);

  return (
    <React.Fragment>
      <main className="assets-page">
        <section className="explore">
          <div className="container">
            <div className="top-part">
              <div className="top-part-left">
                <h2>Explore NFTs</h2>

                <div className="filters">
                  <button
                    className={activeFilter === 1 ? "filter active" : "filter"}
                    onClick={() => {
                      setActiveFilter(1);
                      setTab("all");
                    }}
                  >
                    All
                  </button>
                  <button
                    className={activeFilter === 2 ? "filter active" : "filter"}
                    onClick={() => {
                      setActiveFilter(2);
                      setTab("onsale");
                    }}
                  >
                    Onsale
                  </button>
                  <button
                    className={activeFilter === 3 ? "filter active" : "filter"}
                    onClick={() => {
                      setActiveFilter(3);
                      setTab("others");
                    }}
                  >
                    Others
                  </button>
                </div>
              </div>
            </div>

            <div className="boxes">
              {tab === "all"
                ? NFTs.map((NFT, index) => {
                    let imageLinkExtension = NFT.image.split("/");
                    imageLinkExtension =
                      imageLinkExtension[imageLinkExtension.length - 1];

                    let newImageLink = ipfsGatewayTools.convertToDesiredGateway(
                      NFT.image,
                      "https://mtv-art.mypinata.cloud"
                    );
                      if(!newImageLink.endsWith(imageLinkExtension))
                    newImageLink = newImageLink + "/" + imageLinkExtension;

                    return (
                      <Link
                        to={`/assets/${NFT.collectionURL}/${NFT.tokenID}`}
                        key={index}
                      >
                        <div className="box">
                          <div className="box-top-part">
                            <img src={newImageLink} alt="" />
                          </div>

                          <div className="box-center-part">
                            <h3>{NFT.name.substring(0, 8)}...</h3>
                            <div className="chain">
                              <p>MTV</p>
                            </div>
                          </div>

                          <div className="box-bottom-part">
                            <div className="box-bottom-part-left">
                              <div className="creator-img-placeholder">
                                <img
                                  src={
                                    NFT.collectionLogoImage !== "default"
                                      ? NFT.collectionLogoImage
                                      : null
                                  }
                                  alt=""
                                  className={
                                    NFT.collectionLogoImage !== "default"
                                      ? null
                                      : "disabled"
                                  }
                                />
                              </div>
                              <p>
                                Collection <br />
                                <span>
                                  {NFT.collectionTitle.substring(0, 8)}..
                                </span>
                              </p>
                            </div>

                            <div className="box-bottom-part-right">
                              <p>
                                Price <br />
                                <span>{NFT.price} MTV</span>
                              </p>
                            </div>
                          </div>
                        </div>
                      </Link>
                    );
                  })
                : tab === "onsale"
                ? onSaleNFTs.map((NFT, index) => {
                    let imageLinkExtension = NFT.image.split("/");
                    imageLinkExtension =
                      imageLinkExtension[imageLinkExtension.length - 1];

                    let newImageLink = ipfsGatewayTools.convertToDesiredGateway(
                      NFT.image,
                      "https://mtv-art.mypinata.cloud"
                    );
                    if(!newImageLink.endsWith(imageLinkExtension))
                    newImageLink = newImageLink + "/" + imageLinkExtension;

                    return (
                      <Link
                        to={`/assets/${NFT.collectionURL}/${NFT.tokenID}`}
                        key={index}
                      >
                        <div className="box">
                          <div className="box-top-part">
                            <img src={newImageLink} alt="" />
                          </div>

                          <div className="box-center-part">
                            <h3>{NFT.name.substring(0, 8)}...</h3>
                            <div className="chain">
                              <p>MTV</p>
                            </div>
                          </div>

                          <div className="box-bottom-part">
                            <div className="box-bottom-part-left">
                              <div className="creator-img-placeholder">
                                <img
                                  src={
                                    NFT.collectionLogoImage !== "default"
                                      ? NFT.collectionLogoImage
                                      : null
                                  }
                                  alt=""
                                  className={
                                    NFT.collectionLogoImage !== "default"
                                      ? null
                                      : "disabled"
                                  }
                                />
                              </div>
                              <p>
                                Collection <br />
                                <span>
                                  {NFT.collectionTitle.substring(0, 8)}..
                                </span>
                              </p>
                            </div>

                            <div className="box-bottom-part-right">
                              <p>
                                Price <br />
                                <span>{NFT.price} MTV</span>
                              </p>
                            </div>
                          </div>
                        </div>
                      </Link>
                    );
                  })
                : null}

              {tab === "all"
                ? NFTs.map((NFT, index) => {
                    let imageLinkExtension = NFT.image.split("/");
                    imageLinkExtension =
                      imageLinkExtension[imageLinkExtension.length - 1];

                    let newImageLink = ipfsGatewayTools.convertToDesiredGateway(
                      NFT.image,
                      "https://mtv-art.mypinata.cloud"
                    );
                    if(!newImageLink.endsWith(imageLinkExtension))
                    newImageLink = newImageLink + "/" + imageLinkExtension;

                    return (
                      <Link
                        to={`/assets/${NFT.collectionURL}/${NFT.tokenID}`}
                        key={index}
                      >
                        <div className="box">
                          <div className="box-top-part">
                            <img src={newImageLink} alt="" />
                          </div>

                          <div className="box-center-part">
                            <h3>{NFT.name.substring(0, 8)}...</h3>
                            <div className="chain">
                              <p>MTV</p>
                            </div>
                          </div>

                          <div className="box-bottom-part">
                            <div className="box-bottom-part-left">
                              <div className="creator-img-placeholder">
                                <img
                                  src={
                                    NFT.collectionLogoImage !== "default"
                                      ? NFT.collectionLogoImage
                                      : null
                                  }
                                  alt=""
                                  className={
                                    NFT.collectionLogoImage !== "default"
                                      ? null
                                      : "disabled"
                                  }
                                />
                              </div>
                              <p>
                                Collection <br />
                                <span>
                                  {NFT.collectionTitle.substring(0, 8)}..
                                </span>
                              </p>
                            </div>
                          </div>
                        </div>
                      </Link>
                    );
                  })
                : tab === "others"
                ? NFTs.map((NFT, index) => {
                    let imageLinkExtension = NFT.image.split("/");
                    imageLinkExtension =
                      imageLinkExtension[imageLinkExtension.length - 1];

                    let newImageLink = ipfsGatewayTools.convertToDesiredGateway(
                      NFT.image,
                      "https://mtv-art.mypinata.cloud"
                    );
                    if(!newImageLink.endsWith(imageLinkExtension))
                    newImageLink = newImageLink + "/" + imageLinkExtension;

                    return (
                      <Link
                        to={`/assets/${NFT.collectionURL}/${NFT.tokenID}`}
                        key={index}
                      >
                        <div className="box">
                          <div className="box-top-part">
                            <img src={newImageLink} alt="" />
                          </div>

                          <div className="box-center-part">
                            <h3>{NFT.name.substring(0, 8)}...</h3>
                            <div className="chain">
                              <p>MTV</p>
                            </div>
                          </div>

                          <div className="box-bottom-part">
                            <div className="box-bottom-part-left">
                              <div className="creator-img-placeholder">
                                <img
                                  src={
                                    NFT.collectionLogoImage !== "default"
                                      ? NFT.collectionLogoImage
                                      : null
                                  }
                                  alt=""
                                  className={
                                    NFT.collectionLogoImage !== "default"
                                      ? null
                                      : "disabled"
                                  }
                                />
                              </div>
                              <p>
                                Collection <br />
                                <span>
                                  {NFT.collectionTitle.substring(0, 8)}..
                                </span>
                              </p>
                            </div>
                          </div>
                        </div>
                      </Link>
                    );
                  })
                : null}
            </div>
          </div>
        </section>
      </main>
    </React.Fragment>
  );
};

export default Assets;
