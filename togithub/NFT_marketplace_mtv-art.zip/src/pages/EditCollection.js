import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {notification} from "antd";

// Redux
import { useSelector } from "react-redux";

// Web3
import Web3 from "web3";

// Firebase
import {
  collection,
  doc,
  getDocs,
  updateDoc,
  query,
  where,
} from "firebase/firestore";
import database from "../config/firebase";

// Components
import Authenticator from "../components/Authenticator";

const EditCollection = () => {
  // States
  const navigate = useNavigate();
  const params = useParams();

  const wallet = useSelector((state) => state.wallet);
  const authenticated = useSelector((state) => state.authenticated);

  const [collectionInfo, setCollectionInfo] = useState({
    logoImage: "default",
    bannerImage: "default",
    title: "",
    url: "",
    description: "",
    websiteLink: "",
    discordLink: "",
    twitterLink: "",
    instagramLink: "",
  });
  const [saving, setSaving] = useState(false);



  // Authenticate Collection
  useEffect(async () => {
    let collectionURL = params.collectionURL;

    const collectionsCollectionRef = collection(database, "collections");
    const collectionsCollectionQueryRef = query(
      collectionsCollectionRef,
      where("ownerWalletAddress", "==", wallet.address),
      where("url", "==", collectionURL)
    );

    getDocs(collectionsCollectionQueryRef).then(async (snapshot) => {
      let collections = [];

      snapshot.docs.forEach((doc) => {
        collections.push({ ...doc.data(), id: doc.id });
      });

      if (collections.length === 1) {
        setCollectionInfo(collections[0]);
      } else {
        navigate("/", { replace: true });
      }
    });
  }, []);

  // Functions
  const submit = async (e) => {
    e.preventDefault();
    setSaving(true);
    const collectionsCollectionRef = collection(database, "collections");
    const collectionsCollectionQueryRef = query(
      collectionsCollectionRef,
      where("url", "==", collectionInfo.url),
       
         );

    getDocs(collectionsCollectionQueryRef).then(async (snapshot) => {
      let collections = [];

      snapshot.docs.forEach((doc) => {
        collections.push({ ...doc.data(), id: doc.id });
      });

      if(collections.length == 0 || collections.length == 1 && collections[0].id == collectionInfo.id){
    const collectionsCollectionRef = doc(
      database,
      "collections",
      collectionInfo.id
    );

    updateDoc(collectionsCollectionRef, collectionInfo).then(() => {
      navigate(`/assets/${collectionInfo.url ? collectionInfo.url : null}`, {
        replace: true,
      });
    });
  }else{
    notification.error({
      message : "Input Error",
      description : "Collection Name is duplicate!!!"
    })
    setSaving(false)
  }
  })
  };

  const updateLogoImage = async (e) => {
    const files = e.target.files;
    const data = new FormData();

    data.append("file", files[0]);
    data.append("upload_preset", "images");

    const res = await fetch(
      "https://api.cloudinary.com/v1_1/mtv-art/image/upload",
      {
        method: "post",
        body: data,
      }
    );

    const file = await res.json();

    const collectionsCollectionRef = doc(
      database,
      "collections",
      collectionInfo.id
    );

    updateDoc(collectionsCollectionRef, {
      logoImage: file.secure_url,
    }).then(() => {
      navigate(`/assets/${collectionInfo.url ? collectionInfo.url : null}`, {
        replace: true,
      });
    });
  };

  const updateBannerImage = async (e) => {
    const files = e.target.files;
    const data = new FormData();

    data.append("file", files[0]);
    data.append("upload_preset", "images");

    const res = await fetch(
      "https://api.cloudinary.com/v1_1/mtv-art/image/upload",
      {
        method: "post",
        body: data,
      }
    );

    const file = await res.json();

    const collectionsCollectionRef = doc(
      database,
      "collections",
      collectionInfo.id
    );

    updateDoc(collectionsCollectionRef, {
      bannerImage: file.secure_url,
    }).then(() => {
      navigate(`/assets/${collectionInfo.url ? collectionInfo.url : null}`, {
        replace: true,
      });
    });
  };

  return (
    <React.Fragment>
      <Authenticator />

      {authenticated ? (
        <main className="edit-collection-page">
          <section className="collection">
            <div className="container">
              <h1>Edit collection</h1>
              <p className="sub-title">
                You can set preferred display name, url and manage <br />
                other personal settings
              </p>

              <form onSubmit={submit}>
                <div className="input-group logo-image-input-group">
                  <label>Logo image</label>

                  <input type="file" onChange={updateLogoImage} />
                  <div className="logo-image-placeholder">
                    <img
                      src={
                        collectionInfo.logoImage !== "default"
                          ? collectionInfo.logoImage
                          : null
                      }
                      alt=""
                      className={
                        collectionInfo.logoImage !== "default"
                          ? null
                          : "disabled"
                      }
                    />
                  </div>
                </div>

                <div className="input-group banner-image-input-group">
                  <label>Banner image</label>

                  <input type="file" onChange={updateBannerImage} />
                  <div className="banner-image-placeholder">
                    <img
                      src={
                        collectionInfo.bannerImage !== "default"
                          ? collectionInfo.bannerImage
                          : null
                      }
                      alt=""
                      className={
                        collectionInfo.bannerImage !== "default"
                          ? null
                          : "disabled"
                      }
                    />
                  </div>
                </div>

                <div className="input-group">
                  <label>Title</label>
                  <input
                    type="text"
                    value={collectionInfo.title}
                    onChange={(e) => {
                      setCollectionInfo({
                        ...collectionInfo,
                        title: e.target.value,
                      });
                    }}
                    required
                  />
                </div>

                <div className="input-group">
                  <label>Collection Name</label>
                  <input
                    type="text"
                    value={collectionInfo.url}
                    onChange={(e) => {
                      setCollectionInfo({
                        ...collectionInfo,
                        url: e.target.value,
                      });
                    }}
                    required
                  />
                </div>

                <div className="input-group">
                  <label>Description</label>
                  <textarea
                    type="text"
                    onChange={(e) => {
                      setCollectionInfo({
                        ...collectionInfo,
                        description: e.target.value,
                      });
                    }}
                    defaultValue={collectionInfo.description}
                    required
                  ></textarea>
                </div>

                <div className="input-group">
                  <label>Website</label>
                  <input
                    type="text"
                    value={collectionInfo.websiteLink}
                    onChange={(e) => {
                      setCollectionInfo({
                        ...collectionInfo,
                        websiteLink: e.target.value,
                      });
                    }}
                  />
                </div>
                <div className="input-group" >
                  <label>Royalty(%, minimum 1, maximum 25)</label>
                  <input
                    type="number"
                    min = {1} max ={25} 
                    value={collectionInfo.royalty}
                    onChange={(e) => {
                      setCollectionInfo({
                        ...collectionInfo,
                        royalty: e.target.value,
                      });
                    }}
                  />
                </div>
                <div className="input-group">
                  <label>Discord</label>
                  <input
                    type="text"
                    value={collectionInfo.discordLink}
                    onChange={(e) => {
                      setCollectionInfo({
                        ...collectionInfo,
                        discordLink: e.target.value,
                      });
                    }}
                  />
                </div>

                <div className="input-group">
                  <label>Twitter</label>
                  <input
                    type="text"
                    value={collectionInfo.twitterLink}
                    onChange={(e) => {
                      setCollectionInfo({
                        ...collectionInfo,
                        twitterLink: e.target.value,
                      });
                    }}
                  />
                </div>

                <div className="input-group">
                  <label>Instagram</label>
                  <input
                    type="text"
                    value={collectionInfo.instagramLink}
                    onChange={(e) => {
                      setCollectionInfo({
                        ...collectionInfo,
                        instagramLink: e.target.value,
                      });
                    }}
                  />
                </div>

                <button  className={saving ? "disabled":""}>
                  <span>Save changes</span>
                </button>
              </form>
            </div>
          </section>
        </main>
      ) : (
        <p className="loader">Loading...</p>
      )}
    </React.Fragment>
  );
};

export default EditCollection;
