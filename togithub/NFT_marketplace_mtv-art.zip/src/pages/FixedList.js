import React, { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import IPFSGatewayTools from "@pinata/ipfs-gateway-tools/dist/browser";
import axios from "axios";
import { convertJsonLinks, getObjectType } from "./util";
// Redux
import { useSelector } from "react-redux";

// Web3
import Web3 from "web3";

// Components
import Authenticator from "../components/Authenticator";

// Firebase
import { addDoc, collection, getDocs, query, where } from "firebase/firestore";
import database from "../config/firebase";

// Contracts Data
import {
  marketplaceContractAddress,
  marketplaceContractABI,
  placeholderContractABI,
} from "../data/smart-contracts";
import {
  Waiting
} from "./util"


const FixedList = () => {
  // States
  const navigate = useNavigate();
  const params = useParams();

  const ipfsGatewayTools = new IPFSGatewayTools();

  const wallet = useSelector((state) => state.wallet);
  const authenticated = useSelector((state) => state.authenticated);

  const [collectionInfo, setCollectionInfo] = useState({});
  const [itemInfo, setItemInfo] = useState({});

  const [price, setPrice] = useState(1);

  const [modalTitle, setModalTitle] = useState("Waiting...")
  const [modalOpen, setModalOpen] = useState(false)
  const [modalContent, setModalContent] = useState("Just a moment...")
  const [approving, setApproving] = useState(false);
  const [approved, setApproved] = useState(false);

  // Authenticate Collection & Fetch Items
  useEffect(async () => {
    let collectionURL = params.collectionURL;
    let tokenID = params.tokenID;

    const collectionsCollectionRef = collection(database, "collections");
    const collectionsCollectionQueryRef = query(
      collectionsCollectionRef,
      where("url", "==", collectionURL)
    );

    getDocs(collectionsCollectionQueryRef).then(async (snapshot) => {
      let collections = [];

      snapshot.docs.forEach((doc) => {
        collections.push({ ...doc.data(), id: doc.id });
      });

      if (collections.length === 1) {
        setCollectionInfo(collections[0]);

        if (Web3.givenProvider) {
          const web3 = new Web3(Web3.givenProvider);
          await Web3.givenProvider.enable();

          const contract = new web3.eth.Contract(
            placeholderContractABI,
            collections[0].contractAddress
          );

          contract.methods
            .ownerOf(tokenID)
            .call()
            .then((owner) => {
              let tokenOwner = owner;

              if (tokenOwner === wallet.address) {
                contract.methods
                  .tokenURI(tokenID)
                  .call()
                  .then((jsonLink) => {
                    const newJsonLink = convertJsonLinks(jsonLink)
                if(getObjectType(newJsonLink) == "string"){
                    axios.get(newJsonLink).then((res) => {
                      res.data.tokenID = tokenID;
                      res.data.owner = tokenOwner;

                      setItemInfo(res.data);
                    });
                  }
                    else{
                      newJsonLink.tokenID = tokenID
                      newJsonLink.owner = tokenOwner
                      setItemInfo(newJsonLink)
                    }
                  })
                  .catch((err) => {
                    window.location.replace("/");
                  });
              } else {
                navigate(`/`, { replace: true });
              }
            })
            .catch((err) => {
              navigate(`/`, { replace: true });
            });
        }
      } else {
        window.location.replace("/");
      }
    });
  }, []);

  // Functions
  const approve = async () => {
    if (Web3.givenProvider) {
      const web3 = new Web3(Web3.givenProvider);
      await Web3.givenProvider.enable();

      const contract = new web3.eth.Contract(
        placeholderContractABI,
        collectionInfo.contractAddress
      );

      // setApproving(true);

      contract.methods
        .setApprovalForAll(marketplaceContractAddress, true)
        .send({
          from: wallet.address,
        })
        .then((res) => {
          setApproving(false);
          setApproved(true);
        });
    }
  };

  const submit = async (e) => {
    e.preventDefault();

    if (Web3.givenProvider) {
      if (price > 0) {
        const web3 = new Web3(Web3.givenProvider);
        await Web3.givenProvider.enable();

        const contract = new web3.eth.Contract(
          marketplaceContractABI,
          marketplaceContractAddress
        );

        var tokens = web3.utils.toWei(price.toString(), "ether");
        var bntokens = web3.utils.toBN(tokens);
        setModalTitle("Listing")
          setModalContent("Just a moment for confirming...")
          setModalOpen(true)
        contract.methods
          .list(collectionInfo.contractAddress, itemInfo.tokenID, bntokens)
          .send({
            from: wallet.address,
          })
          .then((res) => {
            console.log("dog", res)
            const listingsCollectionRef = collection(database, "listings");
            const listingsCollectionQueryRef = query(
              listingsCollectionRef,
              where("contractAddress", "==", collectionInfo.contractAddress),
              where("tokenID", "==", itemInfo.tokenID),
              where("sellerWalletAddress", "==", wallet.address),
              where("status", "==", "listed")
            );
            getDocs(listingsCollectionQueryRef).then((snapshot) => {
              const date = Date.now();
              let listings = [];

              snapshot.docs.forEach((doc) => {
                listings.push({ ...doc.data(), id: doc.id });
              });
              
              console.log("this is res",res)

              if (listings.length === 0) {
                addDoc(listingsCollectionRef, {
                  type: "fixed",
                  listingID: res.events.Listed.returnValues[0],
                  contractAddress: collectionInfo.contractAddress,
                  tokenID: itemInfo.tokenID,
                  sellerWalletAddress: wallet.address,
                  price: price,
                  endDate: null,
                  status: "listed",
                  date: date,
                }).then((doc) => {
                  const date = Date.now();
                  const activitiesCollectionRef = collection(
                    database,
                    "activities"
                  );

                  addDoc(activitiesCollectionRef, {
                    contractAddress: collectionInfo.contractAddress,
                    tokenID: itemInfo.tokenID,
                    walletAddress: wallet.address,
                    action: "list",
                    date: date,
                  }).then(() => {
                    navigate(`/profile`, { replace: true });
                  });
                });
              } else {
                alert("This item is already listed.");
              }
            });
          }).catch((e) => {
            setModalOpen(false)
          });
      }
    }
  };

  return (
    <React.Fragment>
      <Authenticator />
      <Waiting content = {modalContent} title = {modalTitle} isOpen = {modalOpen}></Waiting>
      {authenticated ? (
        <main className="fixed-list-page">
          <section className="list">
            <div className="container">
              <h1>List for sale</h1>
              <p className="sub-title">You can set preferred price</p>

              <form onSubmit={submit}>
                <div className="input-group">
                  <label>Fixed price (MTV)</label>
                  <input
                    type="number"
                    min="1"
                    value={price}
                    onChange={(e) => {
                      setPrice(e.target.value);
                    }}
                    required
                  />
                </div>

                <button
                  className={approved ? "approve-btn disabled" : "approve-btn"}
                  type="button"
                  onClick={approve}
                >
                  <span>
                    {approving
                      ? "Approving..."
                      : approved
                      ? "Approved"
                      : "Approve"}
                  </span>
                </button>

                <button className={approved ? "list-btn" : "list-btn disabled"}>
                  <span>List</span>
                </button>
              </form>
            </div>
          </section>
        </main>
      ) : (
        <p className="loader">Loading...</p>
      )}
    </React.Fragment>
  );
};

export default FixedList;
