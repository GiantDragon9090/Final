import IPFSGatewayTools from "@pinata/ipfs-gateway-tools/dist/browser";
import { Modal } from "antd";
import { Component } from "react";

export const convertJsonLinks = (originLink) => {
    if(originLink.search("base64") !== -1){
        return JSON.parse(Buffer.from(originLink.split("base64,")[1].trim(),"base64").toString("ascii"))
    }else{
        if(originLink.startsWith("http")){
            return originLink
        } else {
            const temp = originLink.substring(7).search("/")
            const appendData = (temp === -1 ? "" : originLink.substring(7 + temp))
            const ipfsGatewayTools = new IPFSGatewayTools()
            const newJsonLink = ipfsGatewayTools.convertToDesiredGateway(
                originLink,
                "https://mtv-art.mypinata.cloud"
                )
            return newJsonLink + appendData
        }
    }
}

export const getObjectType = (obj) => {
    return typeof (obj)
}

export class Waiting extends Component  {
    constructor(props){
        super(props)
    }
    render(){
    const {title = "Waiting...", content = "Just a moment...", isOpen = false} = this.props;
    return <Modal title = {title} visible = {isOpen}  footer = {null} closable = {false}>
                <p>{content}</p>
            </Modal>
    }
}