import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

// Web3
import Web3 from "web3";

// Firebase
import { collection, getDocs, query, where } from "firebase/firestore";
import database from "../config/firebase";

const Stats = () => {
  // States
  const [collections, setCollections] = useState([]);

  // Fetch Collections
  useEffect(() => {
    if (Web3.givenProvider) {
      const collectionsCollectionRef = collection(database, "collections");

      getDocs(collectionsCollectionRef).then((snapshot) => {
        let collections = [];

        snapshot.docs.forEach((doc) => {
          collections.push(doc.data());
        });

        collections.forEach((collectionInfo) => {
          const sales = [];

          const salesCollectionRef = collection(database, "sales");
          const salesCollectionQueryRef = query(
            salesCollectionRef,
            where("contractAddress", "==", collectionInfo.contractAddress)
          );

          getDocs(salesCollectionQueryRef).then((snapshot) => {
            snapshot.docs.forEach((doc) => {
              sales.push({ ...doc.data(), id: doc.id });
            });

            let collectionFloorPrice = 0;
            let collectionVolumeTraded = 0;

            if (sales.length > 0) {
              sales.forEach((sale) => {
                collectionFloorPrice += parseInt(sale.price);
                collectionVolumeTraded += parseInt(sale.price);
              });

              collectionFloorPrice = (
                collectionFloorPrice / sales.length
              ).toFixed(2);

              collectionVolumeTraded = collectionVolumeTraded.toFixed(2);
            }

            collectionInfo.floorPrice = collectionFloorPrice;
            collectionInfo.volumeTraded = collectionVolumeTraded;

            setCollections((collections) => {
              return [...collections, collectionInfo];
            });
          });
        });
      });
    }
  }, []);

  return (
    <React.Fragment>
      <main className="stats-page">
        <section className="stats">
          <div className="container">
            <h1>All stats</h1>

            <div className="collections">
              {collections.map((collection, index) => {
                return (
                  <Link to={`/assets/${collection.url}`} key={index}>
                    <div className="collection">
                      <div className="collection-left">
                        <img
                          src={
                            collection.logoImage !== "default"
                              ? collection.logoImage
                              : "/images/pages/landing/collection-logo-image.png"
                          }
                          alt=""
                          className="collection-logo-image"
                        />
                        <div className="collection-left-content">
                          <h4>{collection.title}</h4>
                          <h5>
                            <img
                              src="/images/pages/collection/mtv-icon.png"
                              alt=""
                            />
                            Floor price:{" "}
                            {collection.floorPrice > 1000
                              ? `${collection.floorPrice / 1000}k`
                              : collection.floorPrice}{" "}
                            MTV
                          </h5>
                        </div>
                      </div>

                      <div className="collection-right">
                        <span>
                          <img
                            src="/images/pages/collection/mtv-icon.png"
                            alt=""
                          />{" "}
                          Volume traded
                        </span>

                        <h5>
                          {collection.volumeTraded > 1000
                            ? `${collection.volumeTraded / 1000}k`
                            : collection.volumeTraded}{" "}
                          MTV
                        </h5>
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>
        </section>
      </main>
    </React.Fragment>
  );
};

export default Stats;
