import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

// Web3
import Web3 from "web3";

// Firebase
import { collection, getDocs } from "firebase/firestore";
import database from "../config/firebase";

const Collections = () => {
  // States
  const [collections, setCollections] = useState([]);

  // Fetch Collections
  useEffect(() => {
    if (Web3.givenProvider) {
      const collectionsCollectionRef = collection(database, "collections");

      getDocs(collectionsCollectionRef).then((snapshot) => {
        snapshot.docs.forEach((doc) => {
          setCollections((collections) => {
            return [...collections, doc.data()];
          });
        });
      });
    }
  }, []);

  return (
    <React.Fragment>
      <main className="collections-page">
        <section className="collections">
          <div className="container">
            <div className="top-part">
              <div className="top-part-left">
                <h2>All collections</h2>
              </div>
            </div>

            <div className="boxes">
              {collections.map((collection, index) => {
                return (
                  <Link to={`/assets/${collection.url}`} key={index}>
                    <div className="box">
                      <img
                        src={
                          collection.logoImage !== "default"
                            ? collection.logoImage
                            : "/images/pages/landing/collection-logo-image.png"
                        }
                        alt=""
                      />

                      {collection.verified ? (
                        <svg
                          width="33"
                          height="33"
                          viewBox="0 0 33 33"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <circle
                            cx="16.5"
                            cy="16.5"
                            r="16.5"
                            fill="url(#paint0_linear_76_2)"
                          />
                          <path
                            d="M14.978 21.8073C14.8538 21.931 14.6846 22 14.5087 22C14.3328 22 14.1635 21.931 14.0394 21.8073L10.2917 18.094C9.90276 17.7087 9.90276 17.084 10.2917 16.6993L10.761 16.2344C11.15 15.8491 11.7799 15.8491 12.1689 16.2344L14.5087 18.5524L20.8311 12.289C21.2201 11.9037 21.8507 11.9037 22.239 12.289L22.7083 12.7539C23.0972 13.1392 23.0972 13.7639 22.7083 14.1486L14.978 21.8073Z"
                            fill="white"
                          />
                          <defs>
                            <linearGradient
                              id="paint0_linear_76_2"
                              x1="0"
                              y1="0"
                              x2="33"
                              y2="33"
                              gradientUnits="userSpaceOnUse"
                            >
                              <stop stopColor="#6CD1A3" />
                              <stop offset="1" stopColor="#438EB4" />
                            </linearGradient>
                          </defs>
                        </svg>
                      ) : null}
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>
        </section>
      </main>
    </React.Fragment>
  );
};

export default Collections;
