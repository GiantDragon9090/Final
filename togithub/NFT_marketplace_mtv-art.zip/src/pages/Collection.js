import React, { useEffect, useRef, useState } from "react";
import { createPath, Link, useNavigate, useParams } from "react-router-dom";
import IPFSGatewayTools from "@pinata/ipfs-gateway-tools/dist/browser";
import axios from "axios";

// Redux
import { useSelector } from "react-redux";

// Web3
import Web3 from "web3";

// Firebase
import { collection, getDocs, query, where } from "firebase/firestore";
import database from "../config/firebase";

// Contracts Data
import { placeholderContractABI } from "../data/smart-contracts";
import { convertJsonLinks, getObjectType } from "./util";

const Collection = () => {
  // States
  const navigate = useNavigate();
  const params = useParams();

  const ipfsGatewayTools = new IPFSGatewayTools();

  const wallet = useSelector((state) => state.wallet);

  const [collectionInfo, setCollectionInfo] = useState({});

  const [collectionTotalItems, setCollectionTotalItems] = useState(0);
  const [collectionFloorPrice, setCollectionFloorPrice] = useState(0);
  const [collectionVolumeTraded, setCollectionVolumeTraded] = useState(0);

  const [items, setItems] = useState([]);
  const [onSaleNFTs, setOnSaleNFTs] = useState([]);
  const [activities, setActivities] = useState([]);

  const [activeTab, setActiveTab] = useState(1);

  const totalItemPages = useRef(1);
  const currentPage = useRef(1);

  // Authenticate Collection & Fetch Items
  useEffect(async () => {
    let collectionURL = params.collectionURL;

    const collectionsCollectionRef = collection(database, "collections");
    const collectionsCollectionQueryRef = query(
      collectionsCollectionRef,
      where("url", "==", collectionURL)
    );

    getDocs(collectionsCollectionQueryRef).then(async (snapshot) => {
      let collections = [];

      snapshot.docs.forEach((doc) => {
        collections.push({ ...doc.data(), id: doc.id });
      });
      console.log(collections)

      if (collections.length === 1) {
        setCollectionInfo(collections[0]);

        if (Web3.givenProvider) {
          const web3 = new Web3(Web3.givenProvider);
          await Web3.givenProvider.enable();

          const contract = new web3.eth.Contract(
            placeholderContractABI,
            collections[0].contractAddress
          );

          contract.methods
            .totalSupply()
            .call()
            .then((totalSupplyRes) => {
              let totalSupply = totalSupplyRes;
              setCollectionTotalItems(totalSupply);

              totalItemPages.current = Math.ceil(totalSupply / 48);

              let itemsToShow = 0;

              if (totalSupply > 48) {
                itemsToShow = 48;
              } else {
                itemsToShow = totalSupply;
              }

              for (let i = 0; i <= itemsToShow; i++) {
                contract.methods
                  .tokenURI(i)
                  .call()
                  .then((jsonLink) => {
                    const newJsonLink = convertJsonLinks(jsonLink)
                if(getObjectType(newJsonLink) == "string"){
                  axios.get(newJsonLink).then((res) => {
                      res.data.tokenID = i;

                      setItems((items) => {
                        return [...items, res.data];
                      });
                    });
                  }else{
                    newJsonLink.tokenID = i;
                    setItems((items) => {
                      return [...items, newJsonLink]
                    })
                  }
                  });
              }
            });
        }
      } else {
        //window.location.replace("/");
      }
    });
  }, []);

  const fetchItems = async () => {
    let collectionURL = params.collectionURL;

    const collectionsCollectionRef = collection(database, "collections");
    const collectionsCollectionQueryRef = query(
      collectionsCollectionRef,
      where("url", "==", collectionURL)
    );

    getDocs(collectionsCollectionQueryRef).then(async (snapshot) => {
      let collections = [];

      snapshot.docs.forEach((doc) => {
        collections.push({ ...doc.data(), id: doc.id });
      });

      if (collections.length === 1) {
        setCollectionInfo(collections[0]);

        if (Web3.givenProvider) {
          const web3 = new Web3(Web3.givenProvider);
          await Web3.givenProvider.enable();

          const contract = new web3.eth.Contract(
            placeholderContractABI,
            collections[0].contractAddress
          );

          contract.methods
            .totalSupply()
            .call()
            .then((res) => {
              let totalSupply = res;

              let itemsToShow = currentPage.current * 48 + 1;

              setItems([]);

              for (
                let i = currentPage.current * 48 - 48 + 1;
                i < itemsToShow;
                i++
              ) {
                contract.methods
                  .tokenURI(i)
                  .call()
                  .then((jsonLink) => {
                    const newJsonLink = convertJsonLinks(jsonLink)
                if(getObjectType(newJsonLink) == "string"){
                    axios.get(newJsonLink).then((res) => {
                      res.data.tokenID = i;

                      setItems((items) => {
                        return [...items, res.data];
                      });
                    });
                  }else{
                    newJsonLink.tokenID = i ;
                    setItems((items) => {
                      return [...items, newJsonLink]
                    })
                  }
                  });
              }
            });
        }
      } else {
        navigate("/", { replace: true });
      }
    });
  };

  // Fetch Floor Price & Volume Traded
  useEffect(() => {
    if (Web3.givenProvider) {
      let collectionURL = params.collectionURL;

      const collectionsCollectionRef = collection(database, "collections");
      const collectionsCollectionQueryRef = query(
        collectionsCollectionRef,
        where("url", "==", collectionURL)
      );

      getDocs(collectionsCollectionQueryRef).then(async (snapshot) => {
        let collections = [];

        snapshot.docs.forEach((doc) => {
          collections.push({ ...doc.data(), id: doc.id });
        });

        const sales = [];

        const salesCollectionRef = collection(database, "sales");
        const salesCollectionQueryRef = query(
          salesCollectionRef,
          where("contractAddress", "==", collections[0].contractAddress)
        );

        getDocs(salesCollectionQueryRef).then((snapshot) => {
          snapshot.docs.forEach((doc) => {
            sales.push({ ...doc.data(), id: doc.id });
          });

          let collectionFloorPrice = 0;
          let collectionVolumeTraded = 0;

          if (sales.length > 0) {
            sales.forEach((sale) => {
              collectionFloorPrice += parseInt(sale.price);
              collectionVolumeTraded += parseInt(sale.price);
            });

            collectionFloorPrice = (
              collectionFloorPrice / sales.length
            ).toFixed(2);

            collectionVolumeTraded = collectionVolumeTraded.toFixed(2);
          }

          setCollectionFloorPrice(collectionFloorPrice);
          setCollectionVolumeTraded(collectionVolumeTraded);
        });
      });
    }
  }, []);

  // Fetch On Sale NFTs
  useEffect(async () => {
    if (Web3.givenProvider) {
      let collectionURL = params.collectionURL;

      const collectionsCollectionRef = collection(database, "collections");
      const collectionsCollectionQueryRef = query(
        collectionsCollectionRef,
        where("url", "==", collectionURL)
      );

      getDocs(collectionsCollectionQueryRef).then(async (snapshot) => {
        let collections = [];

        snapshot.docs.forEach((doc) => {
          collections.push({ ...doc.data(), id: doc.id });
        });

        const listingsCollectionRef = collection(database, "listings");
        const listingsCollectionQueryRef = query(
          listingsCollectionRef,
          where("contractAddress", "==", collections[0].contractAddress),
          where("status", "==", "listed")
        );

        getDocs(listingsCollectionQueryRef).then((snapshot) => {
          let listings = [];

          snapshot.docs.forEach((doc) => {
            listings.push({ ...doc.data(), id: doc.id });
          });

          listings.forEach(async (listing) => {
            const web3 = new Web3(Web3.givenProvider);
            await Web3.givenProvider.enable();

            const contract = new web3.eth.Contract(
              placeholderContractABI,
              listing.contractAddress
            );

            let collectionURL = "";
            let collectionTitle = "";

            const collectionsCollectionRef = collection(
              database,
              "collections"
            );
            const collectionsCollectionQueryRef = query(
              collectionsCollectionRef,
              where("contractAddress", "==", listing.contractAddress)
            );

            getDocs(collectionsCollectionQueryRef).then((snapshot) => {
              let collections = [];

              snapshot.docs.forEach((doc) => {
                collections.push({ ...doc.data(), id: doc.id });
                collectionURL = collections[0].url;
                collectionTitle = collections[0].title;
              });

              contract.methods
                .tokenURI(listing.tokenID)
                .call()
                .then((jsonLink) => {
                  const newJsonLink = convertJsonLinks(jsonLink)
                if(getObjectType(newJsonLink) == "string"){
                  axios.get(newJsonLink).then((res) => {
                    res.data.collectionURL = collectionURL;
                    res.data.collectionTitle = collectionTitle;
                    res.data.tokenID = listing.tokenID;
                    res.data.price = listing.price;

                    setOnSaleNFTs((onSaleNFTs) => {
                      return [...onSaleNFTs, res.data];
                    });
                  });
                }else{
                  newJsonLink.collectionURL = collectionURL;
                  newJsonLink.collectionTitle = collectionTitle;
                  newJsonLink.tokenID = listing.tokenID;
                  newJsonLink.price = listing.price;

                    setOnSaleNFTs((onSaleNFTs) => {
                      return [...onSaleNFTs, newJsonLink];
                    });
                }
                });
            });
          });
        });
      });
    }
  }, []);

  // Fetch Activities
  useEffect(() => {
    if (Web3.givenProvider) {
      let collectionURL = params.collectionURL;

      const collectionsCollectionRef = collection(database, "collections");
      const collectionsCollectionQueryRef = query(
        collectionsCollectionRef,
        where("url", "==", collectionURL)
      );

      getDocs(collectionsCollectionQueryRef).then(async (snapshot) => {
        let collections = [];

        snapshot.docs.forEach((doc) => {
          collections.push({ ...doc.data(), id: doc.id });
        });

        const activitiesCollectionRef = collection(database, "activities");
        const activitiesCollectionQueryRef = query(
          activitiesCollectionRef,
          where("contractAddress", "==", collections[0].contractAddress)
        );

        getDocs(activitiesCollectionQueryRef).then((snapshot) => {
          snapshot.docs.forEach((doc) => {
            setActivities((activities) => {
              return [...activities, doc.data()];
            });
          });
        });
      });
    }
  }, []);

  const mint = async () => {
    if (Web3.givenProvider) {
      const web3 = new Web3(Web3.givenProvider);
      await Web3.givenProvider.enable();

      const price = 0.3 * 1;
      var tokens = web3.utils.toWei(price.toString(), "ether");
      var bntokens = web3.utils.toBN(tokens);

      const CONTRACT_ADDRESS = "0x7908d92ae7685a0b539dc369936acb44d5c29df3";
      const CONTRACT_ABI = [
        {
          inputs: [],
          stateMutability: "nonpayable",
          type: "constructor",
        },
        {
          anonymous: false,
          inputs: [
            {
              indexed: true,
              internalType: "address",
              name: "owner",
              type: "address",
            },
            {
              indexed: true,
              internalType: "address",
              name: "approved",
              type: "address",
            },
            {
              indexed: true,
              internalType: "uint256",
              name: "tokenId",
              type: "uint256",
            },
          ],
          name: "Approval",
          type: "event",
        },
        {
          anonymous: false,
          inputs: [
            {
              indexed: true,
              internalType: "address",
              name: "owner",
              type: "address",
            },
            {
              indexed: true,
              internalType: "address",
              name: "operator",
              type: "address",
            },
            {
              indexed: false,
              internalType: "bool",
              name: "approved",
              type: "bool",
            },
          ],
          name: "ApprovalForAll",
          type: "event",
        },
        {
          inputs: [
            {
              internalType: "address",
              name: "to",
              type: "address",
            },
            {
              internalType: "uint256",
              name: "tokenId",
              type: "uint256",
            },
          ],
          name: "approve",
          outputs: [],
          stateMutability: "nonpayable",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "uint256",
              name: "_mintAmount",
              type: "uint256",
            },
          ],
          name: "mint",
          outputs: [],
          stateMutability: "payable",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "uint256",
              name: "_mintAmount",
              type: "uint256",
            },
            {
              internalType: "address",
              name: "_receiver",
              type: "address",
            },
          ],
          name: "mintForAddress",
          outputs: [],
          stateMutability: "nonpayable",
          type: "function",
        },
        {
          anonymous: false,
          inputs: [
            {
              indexed: true,
              internalType: "address",
              name: "previousOwner",
              type: "address",
            },
            {
              indexed: true,
              internalType: "address",
              name: "newOwner",
              type: "address",
            },
          ],
          name: "OwnershipTransferred",
          type: "event",
        },
        {
          inputs: [],
          name: "renounceOwnership",
          outputs: [],
          stateMutability: "nonpayable",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "address",
              name: "from",
              type: "address",
            },
            {
              internalType: "address",
              name: "to",
              type: "address",
            },
            {
              internalType: "uint256",
              name: "tokenId",
              type: "uint256",
            },
          ],
          name: "safeTransferFrom",
          outputs: [],
          stateMutability: "nonpayable",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "address",
              name: "from",
              type: "address",
            },
            {
              internalType: "address",
              name: "to",
              type: "address",
            },
            {
              internalType: "uint256",
              name: "tokenId",
              type: "uint256",
            },
            {
              internalType: "bytes",
              name: "_data",
              type: "bytes",
            },
          ],
          name: "safeTransferFrom",
          outputs: [],
          stateMutability: "nonpayable",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "address",
              name: "operator",
              type: "address",
            },
            {
              internalType: "bool",
              name: "approved",
              type: "bool",
            },
          ],
          name: "setApprovalForAll",
          outputs: [],
          stateMutability: "nonpayable",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "string",
              name: "_hiddenMetadataUri",
              type: "string",
            },
          ],
          name: "setHiddenMetadataUri",
          outputs: [],
          stateMutability: "nonpayable",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "bool",
              name: "_state",
              type: "bool",
            },
          ],
          name: "setOnlyWhitelisted",
          outputs: [],
          stateMutability: "nonpayable",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "bool",
              name: "_state",
              type: "bool",
            },
          ],
          name: "setPaused",
          outputs: [],
          stateMutability: "nonpayable",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "bool",
              name: "_state",
              type: "bool",
            },
          ],
          name: "setPresale",
          outputs: [],
          stateMutability: "nonpayable",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "uint256",
              name: "_cost",
              type: "uint256",
            },
          ],
          name: "setPresaleCost",
          outputs: [],
          stateMutability: "nonpayable",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "uint256",
              name: "_cost",
              type: "uint256",
            },
          ],
          name: "setPublicsaleCost",
          outputs: [],
          stateMutability: "nonpayable",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "bool",
              name: "_state",
              type: "bool",
            },
          ],
          name: "setRevealed",
          outputs: [],
          stateMutability: "nonpayable",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "string",
              name: "_uriPrefix",
              type: "string",
            },
          ],
          name: "setUriPrefix",
          outputs: [],
          stateMutability: "nonpayable",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "string",
              name: "_uriSuffix",
              type: "string",
            },
          ],
          name: "setUriSuffix",
          outputs: [],
          stateMutability: "nonpayable",
          type: "function",
        },
        {
          anonymous: false,
          inputs: [
            {
              indexed: true,
              internalType: "address",
              name: "from",
              type: "address",
            },
            {
              indexed: true,
              internalType: "address",
              name: "to",
              type: "address",
            },
            {
              indexed: true,
              internalType: "uint256",
              name: "tokenId",
              type: "uint256",
            },
          ],
          name: "Transfer",
          type: "event",
        },
        {
          inputs: [
            {
              internalType: "address",
              name: "from",
              type: "address",
            },
            {
              internalType: "address",
              name: "to",
              type: "address",
            },
            {
              internalType: "uint256",
              name: "tokenId",
              type: "uint256",
            },
          ],
          name: "transferFrom",
          outputs: [],
          stateMutability: "nonpayable",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "address",
              name: "newOwner",
              type: "address",
            },
          ],
          name: "transferOwnership",
          outputs: [],
          stateMutability: "nonpayable",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "address[]",
              name: "_users",
              type: "address[]",
            },
          ],
          name: "whitelistUsers",
          outputs: [],
          stateMutability: "nonpayable",
          type: "function",
        },
        {
          inputs: [],
          name: "withdraw",
          outputs: [],
          stateMutability: "nonpayable",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "address",
              name: "",
              type: "address",
            },
          ],
          name: "addressMintedBalance",
          outputs: [
            {
              internalType: "uint256",
              name: "",
              type: "uint256",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "address",
              name: "owner",
              type: "address",
            },
          ],
          name: "balanceOf",
          outputs: [
            {
              internalType: "uint256",
              name: "",
              type: "uint256",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "uint256",
              name: "tokenId",
              type: "uint256",
            },
          ],
          name: "getApproved",
          outputs: [
            {
              internalType: "address",
              name: "",
              type: "address",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [],
          name: "hiddenMetadataUri",
          outputs: [
            {
              internalType: "string",
              name: "",
              type: "string",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "address",
              name: "owner",
              type: "address",
            },
            {
              internalType: "address",
              name: "operator",
              type: "address",
            },
          ],
          name: "isApprovedForAll",
          outputs: [
            {
              internalType: "bool",
              name: "",
              type: "bool",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "address",
              name: "_user",
              type: "address",
            },
          ],
          name: "isWhitelisted",
          outputs: [
            {
              internalType: "bool",
              name: "",
              type: "bool",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [],
          name: "maxFreesaleMintAmountPerTx",
          outputs: [
            {
              internalType: "uint256",
              name: "",
              type: "uint256",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [],
          name: "maxPresaleMintAmountPerTx",
          outputs: [
            {
              internalType: "uint256",
              name: "",
              type: "uint256",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [],
          name: "maxPublicsaleMintAmountPerTx",
          outputs: [
            {
              internalType: "uint256",
              name: "",
              type: "uint256",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [],
          name: "maxSupply",
          outputs: [
            {
              internalType: "uint256",
              name: "",
              type: "uint256",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [],
          name: "name",
          outputs: [
            {
              internalType: "string",
              name: "",
              type: "string",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [],
          name: "nftFreesalePerAddressLimit",
          outputs: [
            {
              internalType: "uint256",
              name: "",
              type: "uint256",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [],
          name: "nftPresalePerAddressLimit",
          outputs: [
            {
              internalType: "uint256",
              name: "",
              type: "uint256",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [],
          name: "onlyWhitelisted",
          outputs: [
            {
              internalType: "bool",
              name: "",
              type: "bool",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [],
          name: "owner",
          outputs: [
            {
              internalType: "address",
              name: "",
              type: "address",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "uint256",
              name: "tokenId",
              type: "uint256",
            },
          ],
          name: "ownerOf",
          outputs: [
            {
              internalType: "address",
              name: "",
              type: "address",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [],
          name: "paused",
          outputs: [
            {
              internalType: "bool",
              name: "",
              type: "bool",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [],
          name: "presale",
          outputs: [
            {
              internalType: "bool",
              name: "",
              type: "bool",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [],
          name: "presaleCost",
          outputs: [
            {
              internalType: "uint256",
              name: "",
              type: "uint256",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [],
          name: "publicsaleCost",
          outputs: [
            {
              internalType: "uint256",
              name: "",
              type: "uint256",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [],
          name: "revealed",
          outputs: [
            {
              internalType: "bool",
              name: "",
              type: "bool",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "bytes4",
              name: "interfaceId",
              type: "bytes4",
            },
          ],
          name: "supportsInterface",
          outputs: [
            {
              internalType: "bool",
              name: "",
              type: "bool",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [],
          name: "symbol",
          outputs: [
            {
              internalType: "string",
              name: "",
              type: "string",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "uint256",
              name: "_tokenId",
              type: "uint256",
            },
          ],
          name: "tokenURI",
          outputs: [
            {
              internalType: "string",
              name: "",
              type: "string",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [],
          name: "totalSupply",
          outputs: [
            {
              internalType: "uint256",
              name: "",
              type: "uint256",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [],
          name: "uriPrefix",
          outputs: [
            {
              internalType: "string",
              name: "",
              type: "string",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [],
          name: "uriSuffix",
          outputs: [
            {
              internalType: "string",
              name: "",
              type: "string",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "address",
              name: "_owner",
              type: "address",
            },
          ],
          name: "walletOfOwner",
          outputs: [
            {
              internalType: "uint256[]",
              name: "",
              type: "uint256[]",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
        {
          inputs: [
            {
              internalType: "uint256",
              name: "",
              type: "uint256",
            },
          ],
          name: "whitelistedAddresses",
          outputs: [
            {
              internalType: "address",
              name: "",
              type: "address",
            },
          ],
          stateMutability: "view",
          type: "function",
        },
      ];

      const contract = new web3.eth.Contract(CONTRACT_ABI, CONTRACT_ADDRESS);

      const addresses = await web3.eth.getAccounts();
      const address = addresses[0];

      contract.methods
        .mint(1)
        .send({ from: address, value: bntokens })
        .then(() => {
          navigate(`/profile`, { replace: true });
        });
    }
  };

  return (
    <React.Fragment>
      <main className="collection-page">
        <section className="collection-info">
          <div className="container">
            <div className="banner-image-placeholder">
              <img
                src={
                  collectionInfo.bannerImage !== "default"
                    ? collectionInfo.bannerImage
                    : null
                }
                alt=""
                className={
                  collectionInfo.bannerImage !== "default" ? null : "disabled"
                }
              />
            </div>
            <div className="logo-image-placeholder">
              <img
                src={
                  collectionInfo.logoImage !== "default"
                    ? collectionInfo.logoImage
                    : null
                }
                alt=""
                className={
                  collectionInfo.logoImage !== "default" ? null : "disabled"
                }
              />
            </div>

            <h3 className="title">
              {collectionInfo.title ? collectionInfo.title : null}
            </h3>
            <p className="contract-address">
              {collectionInfo.contractAddress
                ? collectionInfo.contractAddress
                : null}
            </p>

            <div className="info-boxes">
              <div className="info-box">
                <h5>{collectionTotalItems}</h5>
                <span>items</span>
              </div>

              <div className="info-box">
                <h5>
                  <img src="/images/pages/collection/mtv-icon.png" alt="" />
                  {collectionFloorPrice > 1000
                    ? `${collectionFloorPrice / 1000}k`
                    : collectionFloorPrice}{" "}
                  MTV
                </h5>
                <span>floor price</span>
              </div>

              <div className="info-box">
                <h5>
                  <img src="/images/pages/collection/mtv-icon.png" alt="" />
                  {collectionVolumeTraded > 1000
                    ? `${collectionVolumeTraded / 1000}k`
                    : collectionVolumeTraded}{" "}
                  MTV
                </h5>
                <span>volume traded</span>
              </div>
            </div>

            <div className="social-links">
              {collectionInfo.websiteLink &&
              collectionInfo.websiteLink !== "" ? (
                <a
                  href={
                    collectionInfo.websiteLink
                      ? collectionInfo.websiteLink
                      : null
                  }
                  target="_blank"
                >
                  <i className="bi bi-globe"></i>
                </a>
              ) : null}

              {collectionInfo.discordLink &&
              collectionInfo.discordLink !== "" ? (
                <a
                  href={
                    collectionInfo.discordLink
                      ? collectionInfo.discordLink
                      : null
                  }
                  target="_blank"
                >
                  <i className="bi bi-discord"></i>
                </a>
              ) : null}

              {collectionInfo.twitterLink &&
              collectionInfo.twitterLink !== "" ? (
                <a
                  href={
                    collectionInfo.twitterLink
                      ? collectionInfo.twitterLink
                      : null
                  }
                  target="_blank"
                >
                  <i className="bi bi-twitter"></i>
                </a>
              ) : null}

              {collectionInfo.instagramLink &&
              collectionInfo.instagramLink !== "" ? (
                <a
                  href={
                    collectionInfo.instagramLink
                      ? collectionInfo.instagramLink
                      : null
                  }
                  target="_blank"
                >
                  <i className="bi bi-instagram"></i>
                </a>
              ) : null}
            </div>

            <p className="description">
              {collectionInfo.description ? collectionInfo.description : null}
            </p>

            {collectionInfo.mintAble ? (
              <button className="mint-btn" onClick={mint}>
                <span>Mint Now!</span>
              </button>
            ) : null}

            <button className="share-btn">
              <i className="bi bi-share-fill"></i>
            </button>

            {collectionInfo.ownerWalletAddress === wallet.address ? (
              <Link
                to={`/assets/${
                  collectionInfo.url ? collectionInfo.url : null
                }/settings`}
                className="settings-btn"
              >
                <i className="bi bi-gear-fill"></i>
              </Link>
            ) : null}
          </div>
        </section>

        <section className="tabs">
          <div className="container">
            <div className="tabs-navigation">
              <button
                className={activeTab === 1 ? "active" : null}
                onClick={() => {
                  setActiveTab(1);
                }}
              >
                Items
              </button>
              <button
                className={activeTab === 2 ? "active" : null}
                onClick={() => {
                  setActiveTab(2);
                }}
              >
                On sale
              </button>
              <button
                className={activeTab === 3 ? "active" : null}
                onClick={() => {
                  setActiveTab(3);
                }}
              >
                Activity
              </button>
            </div>

            <div className="tabs-wrapper">
              <div className={activeTab === 1 ? "tab active" : "tab"}>
                {items.length > 0 ? (
                  <React.Fragment>
                    <div className="items">
                      {items.map((item, index) => {
                        let imageLinkExtension = item.image.split("/");
                        imageLinkExtension =
                          imageLinkExtension[imageLinkExtension.length - 1];

                        let newImageLink =
                          ipfsGatewayTools.convertToDesiredGateway(
                            item.image,
                            "https://mtv-art.mypinata.cloud"
                          );
                          if(!newImageLink.endsWith(imageLinkExtension))
                        newImageLink = newImageLink + "/" + imageLinkExtension;

                        return (
                          <Link
                            to={`/assets/${
                              collectionInfo.url ? collectionInfo.url : null
                            }/${item.tokenID >= 0 ? item.tokenID : null}`}
                            key={index}
                          >
                            <div className="item">
                              <img src={newImageLink} alt="" />
                              <h4>{item.name ? item.name : "???"}</h4>
                            </div>
                          </Link>
                        );
                      })}
                    </div>

                    <div className="pagination">
                      {currentPage.current > 1 ? (
                        <button
                          className="prev-btn"
                          onClick={() => {
                            currentPage.current = currentPage.current - 1;
                            fetchItems();
                          }}
                        >
                          <span>Prev</span>
                        </button>
                      ) : null}

                      {totalItemPages.current > 1 ? (
                        <button
                          className="next-btn"
                          onClick={() => {
                            currentPage.current = currentPage.current + 1;
                            fetchItems();
                          }}
                        >
                          <span>Next</span>
                        </button>
                      ) : null}
                    </div>
                  </React.Fragment>
                ) : (
                  <div className="not-found-box">
                    <h4>No items found</h4>
                    <p>
                      Come back soon! Or try to browse something for you on our
                      marketplace
                    </p>

                    <div className="btns">
                      <Link to="/assets">
                        <button className="primary-btn">
                          <span>Browse marketplace</span>
                        </button>
                      </Link>
                    </div>
                  </div>
                )}
              </div>

              <div className={activeTab === 2 ? "tab active" : "tab"}>
                {onSaleNFTs.length > 0 ? (
                  <div className="items" align = "center">
                    {onSaleNFTs.map((onSaleNFT, index) => {
                      let imageLinkExtension = onSaleNFT.image.split("/");
                      imageLinkExtension =
                        imageLinkExtension[imageLinkExtension.length - 1];

                      let newImageLink =
                        ipfsGatewayTools.convertToDesiredGateway(
                          onSaleNFT.image,
                          "https://mtv-art.mypinata.cloud"
                        );
                        if(!newImageLink.endsWith(imageLinkExtension))
                      newImageLink = newImageLink + "/" + imageLinkExtension;

                      return (
                        <Link
                          to={`/assets/${onSaleNFT.collectionURL}/${onSaleNFT.tokenID}`}
                          key={index}
                        >
                          <div className="item">
                            <img src={newImageLink} alt="" />
                            <h4>{onSaleNFT.name ? onSaleNFT.name : "???"}</h4>
                          </div>
                        </Link>
                      );
                    })}
                  </div>
                ) : (
                  <div className="not-found-box">
                    <h4>No items found</h4>
                    <p>
                      Come back soon! Or try to browse something for you on our
                      marketplace
                    </p>

                    <div className="btns">
                      <Link to="/assets">
                        <button className="primary-btn">
                          <span>Browse marketplace</span>
                        </button>
                      </Link>
                    </div>
                  </div>
                )}
              </div>

              <div className={activeTab === 3 ? "tab active" : "tab"}>
                {activities.length > 0 ? (
                  <div className="activities">
                    <div className="title-row">
                      <p>From</p>
                      <p>Token ID</p>
                      <p>Action</p>
                      <p>Date</p>
                    </div>
                    {activities.map((activity, index) => {
                      return (
                        <div className="row" key={index}>
                          <p className="collection">{activity.walletAddress}</p>
                          <p>{activity.tokenID}</p>
                          <p className="action">{activity.action}</p>
                          <p>{new Date(activity.date).toDateString()}</p>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="not-found-box">
                    <h4>No activities found</h4>
                    <p>
                      Come back soon! Or try to trade something for you on our
                      marketplace
                    </p>

                    <div className="btns">
                      <Link to="/assets">
                        <button className="primary-btn">
                          <span>Browse marketplace</span>
                        </button>
                      </Link>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>
      </main>
    </React.Fragment>
  );
};

export default Collection;
