import React from "react";
import { Link, useParams } from "react-router-dom";

// Redux
import { useSelector } from "react-redux";

// Components
import Authenticator from "../components/Authenticator";

const List = () => {
  // States
  const params = useParams();

  const authenticated = useSelector((state) => state.authenticated);

  return (
    <React.Fragment>
      <Authenticator />

      {authenticated ? (
        <main className="list-page">
          <section className="boxes">
            <div className="container">
              <h1>List asset</h1>
              <p className="sub-title">
                Choose the most suitable option for your needs
              </p>

              <div className="boxes-wrapper">
                <div className="box">
                  <i className="bi bi-currency-dollar"></i>

                  <h3>Fixed</h3>
                  <Link
                    to={`/assets/${params.collectionURL}/${params.tokenID}/list/fixed`}
                  >
                    <button>
                      <span>Continue</span>
                    </button>
                  </Link>
                </div>

                <div className="box">
                  <i className="bi bi-alarm-fill"></i>

                  <h3>Auction</h3>
                  <Link
                    to={`/assets/${params.collectionURL}/${params.tokenID}/list/auction`}
                  >
                    <button>
                      <span>Continue</span>
                    </button>
                  </Link>
                </div>
              </div>
            </div>
          </section>
        </main>
      ) : (
        <p className="loader">Loading...</p>
      )}
    </React.Fragment>
  );
};

export default List;
