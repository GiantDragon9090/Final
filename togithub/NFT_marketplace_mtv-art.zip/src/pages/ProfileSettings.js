import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
// Redux
import { useSelector } from "react-redux";

// Firebase
import { doc, getDoc, updateDoc } from "firebase/firestore";
import database from "../config/firebase";

// Components
import Authenticator from "../components/Authenticator";

const ProfileSettings = () => {
  // States
  const navigate = useNavigate();

  const wallet = useSelector((state) => state.wallet);
  const authenticated = useSelector((state) => state.authenticated);

  const [user, setUser] = useState({})

  // Fetch Data
  useEffect(() => {
    if (authenticated) {
      const usersCollectionRef = doc(database, "users", wallet.id);

      getDoc(usersCollectionRef).then((snapshot) => {
        setUser(snapshot.data());
      });
    }
  }, [authenticated]);

  // Functions
  const saveChanges = (e) => {
    e.preventDefault();

    const usersCollectionRef = doc(database, "users", wallet.id);

    updateDoc(usersCollectionRef, user).then(() => {
      navigate("/profile", { replace: true });
    });
  };

  const updateProfileImage = async (e) => {
    const files = e.target.files;
    const data = new FormData();

    data.append("file", files[0]);
    data.append("upload_preset", "images");

    const res = await fetch(
      "https://api.cloudinary.com/v1_1/mtv-art/image/upload",
      {
        method: "post",
        body: data,
      }
    );

    const file = await res.json();

    const usersCollectionRef = doc(database, "users", wallet.id);

    updateDoc(usersCollectionRef, {
      profileImage: file.secure_url,
    }).then(() => {
      navigate("/profile", { replace: true });
    });
  };

  const updateProfileBanner = async (e) => {
    const files = e.target.files;
    const data = new FormData();

    data.append("file", files[0]);
    data.append("upload_preset", "images");

    const res = await fetch(
      "https://api.cloudinary.com/v1_1/mtv-art/image/upload",
      {
        method: "post",
        body: data,
      }
    );

    const file = await res.json();

    const usersCollectionRef = doc(database, "users", wallet.id);

    updateDoc(usersCollectionRef, {
      profileBanner: file.secure_url,
    }).then(() => {
      navigate("/profile", { replace: true });
    });
  };

  return (
    <React.Fragment>
      <Authenticator />

      {authenticated ? (
        <main className="profile-settings-page">
          <section className="settings">
            <div className="container">
              <h1>Edit profile</h1>
              <p>
                You can set preferred display name, username and manage <br />
                other personal settings
              </p>

              <div className="settings-layout">
                <div className="settings-left">
                  <form onSubmit={saveChanges}>
                    <div className="input-group">
                      <label>Display name</label>
                      <input
                        type="text"
                        value={user.name}
                        onChange={(e) => {
                          setUser({ ...user, name: e.target.value });
                        }}
                        required
                      />
                    </div>

                    <div className="input-group">
                      <label>Username</label>
                      <input
                        type="text"
                        value={user.username}
                        onChange={(e) => {
                          setUser({ ...user, username: e.target.value });
                        }}
                        required
                      />
                    </div>

                    <div className="input-group">
                      <label>Email</label>
                      <input
                        type="email"
                        value={user.email}
                        onChange={(e) => {
                          setUser({ ...user, email: e.target.value });
                        }}
                      />
                    </div>

                    <div className="input-group">
                      <label>Bio</label>
                      <input
                        type="text"
                        value={user.bio}
                        onChange={(e) => {
                          setUser({ ...user, bio: e.target.value });
                        }}
                      />
                    </div>

                    <div className="input-group">
                      <label>Website</label>
                      <input
                        type="text"
                        value={user.websiteLink}
                        onChange={(e) => {
                          setUser({ ...user, websiteLink: e.target.value });
                        }}
                      />
                    </div>

                    <div className="input-group">
                      <label>Discord</label>
                      <input
                        type="text"
                        value={user.discordLink}
                        onChange={(e) => {
                          setUser({ ...user, discordLink: e.target.value });
                        }}
                      />
                    </div>

                    <div className="input-group">
                      <label>Twitter</label>
                      <input
                        type="text"
                        value={user.twitterLink}
                        onChange={(e) => {
                          setUser({ ...user, twitterLink: e.target.value });
                        }}
                      />
                    </div>

                    <div className="input-group">
                      <label>Instagram</label>
                      <input
                        type="text"
                        value={user.instagramLink}
                        onChange={(e) => {
                          setUser({ ...user, instagramLink: e.target.value });
                        }}
                      />
                    </div>

                    <button>
                      <span>Save changes</span>
                    </button>
                  </form>
                </div>

                <div className="settings-right">
                  <div className="profile-banner-placeholder">
                    <img
                      src={
                        user.profileBanner !== "default"
                          ? user.profileBanner
                          : null
                      }
                      alt=""
                      className={
                        user.profileBanner !== "default" ? null : "disabled"
                      }
                    />
                  </div>

                  <div className="form form-2">
                    <input type="file" onChange={updateProfileBanner} />
                    <button>
                      <span>Choose file</span>
                    </button>
                  </div>

                  <div className="user-image-placeholder">
                    <img
                      src={
                        user.profileImage !== "default"
                          ? user.profileImage
                          : null
                      }
                      alt=""
                      className={
                        user.profileImage !== "default" ? null : "disabled"
                      }
                    />
                  </div>
                  <p>
                    We recommend an image <br /> of at least 150x150. Gifs work
                    too. <br /> Max 5mb.
                  </p>

                  <div className="form">
                    <input type="file" onChange={updateProfileImage} />
                    <button>
                      <span>Choose file</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </main>
      ) : (
        <p className="loader">Loading...</p>
      )}
    </React.Fragment>
  );
};

export default ProfileSettings;
