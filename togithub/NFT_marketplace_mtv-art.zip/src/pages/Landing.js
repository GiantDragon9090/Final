import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import IPFSGatewayTools from "@pinata/ipfs-gateway-tools/dist/browser";
// Redux
import { useSelector } from "react-redux";

// Web3
import Web3 from "web3";

// Firebase
import { collection, getDocs, query, where } from "firebase/firestore";
import database from "../config/firebase";

// Contracts Data
import { placeholderContractABI } from "../data/smart-contracts";
import { convertJsonLinks, getObjectType } from "./util";

const Landing = () => {
  // States

  const wallet = useSelector((state) => state.wallet);

  const [onSaleNFTs, setOnSaleNFTs] = useState([]);
  const [newestNFTs, setNewestNFTs] = useState([]);
  const [hotNFTs, setHotNFTs] = useState([]);

  const [collections, setCollections] = useState([]);

  const [activeFilter, setActiveFilter] = useState(1);
  const [activeFilter2, setActiveFilter2] = useState(1);


  const ipfsGatewayTools = new IPFSGatewayTools()
  // Fetch On Sale NFTs
  
  useEffect(async () => {
    if (Web3.givenProvider) {
      const listingsCollectionRef = collection(database, "listings");
      const listingsCollectionQueryRef = query(
        listingsCollectionRef,
        where("status", "==", "listed")
      );

      getDocs(listingsCollectionQueryRef).then((snapshot) => {
        let listings = [];

        snapshot.docs.forEach((doc) => {
          listings.push({ ...doc.data(), id: doc.id });
        });

        listings.forEach(async (listing) => {
          const web3 = new Web3(Web3.givenProvider);
          await Web3.givenProvider.enable();

          const contract = new web3.eth.Contract(
            placeholderContractABI,
            listing.contractAddress
          );

          let collectionURL = "";
          let collectionTitle = "";
          let collectionLogoImage = "";

          const collectionsCollectionRef = collection(database, "collections");
          const collectionsCollectionQueryRef = query(
            collectionsCollectionRef,
            where("contractAddress", "==", listing.contractAddress)
          );

          getDocs(collectionsCollectionQueryRef).then((snapshot) => {
            let collections = [];

            snapshot.docs.forEach((doc) => {
              collections.push({ ...doc.data(), id: doc.id });
              collectionURL = collections[0].url;
              collectionTitle = collections[0].title;
              collectionLogoImage = collections[0].logoImage;
            });

            contract.methods
              .tokenURI(listing.tokenID)
              .call()
              .then((jsonLink) => {
                const newJsonLink = convertJsonLinks(jsonLink)
                if(getObjectType(newJsonLink) == "string"){
                axios.get(newJsonLink).then((res) => {
                  res.data.collectionURL = collectionURL;
                  res.data.collectionTitle = collectionTitle;
                  res.data.collectionLogoImage = collectionLogoImage;
                  res.data.tokenID = listing.tokenID;
                  res.data.price = listing.price;

                  setOnSaleNFTs((onSaleNFTs) => {
                    return [...onSaleNFTs, res.data];
                  });
                });
              }else{
                newJsonLink.collectionURL = collectionURL;
                newJsonLink.collectionTitle = collectionTitle;
                newJsonLink.collectionLogoImage = collectionLogoImage;
                newJsonLink.tokenID = listing.tokenID;
                newJsonLink.price = listing.price;

                  setOnSaleNFTs((onSaleNFTs) => {
                    return [...onSaleNFTs, newJsonLink];
                  });
              }
              });
          });
        });
      });
    }
  }, []);

  // Fetch Newest NFTs
  useEffect(async () => {
    if (Web3.givenProvider) {
      const collectionsCollectionRef = collection(database, "collections");

      getDocs(collectionsCollectionRef).then((snapshot) => {
        let collections = [];

        snapshot.docs.forEach((doc) => {
          collections.push({ ...doc.data(), id: doc.id });
        });

        collections.forEach(async (collection) => {
          const web3 = new Web3(Web3.givenProvider);
          await Web3.givenProvider.enable();

          const contract = new web3.eth.Contract(
            placeholderContractABI,
            collection.contractAddress
          );

          contract.methods
            .totalSupply()
            .call()
            .then((totalSupplyRes) => {
              for (let i = 0; i <= 1; i++) {
                contract.methods
                  .tokenURI(i)
                  .call()
                  .then((jsonLink) => {
                    const newJsonLink = convertJsonLinks(jsonLink)
                if(getObjectType(newJsonLink) == "string"){
                    axios.get(newJsonLink).then((res) => {
                      res.data.tokenID = i;
                      res.data.collectionURL = collection.url;
                      res.data.collectionTitle = collection.title;
                      res.data.collectionLogoImage = collection.logoImage;

                      setNewestNFTs((newestNFTs) => {
                        return [...newestNFTs, res.data];
                      });
                    });
                  }else{
                    newJsonLink.tokenID = i;
                    newJsonLink.collectionURL = collection.url;
                    newJsonLink.collectionTitle = collection.title;
                    newJsonLink.collectionLogoImage = collection.logoImage;

                      setNewestNFTs((newestNFTs) => {
                        return [...newestNFTs, newJsonLink];
                      });
                  }
                  });
              }
            });
        });
      });
    }
  }, []);

  // Fetch Hot NFTs
  useEffect(async () => {
    if (Web3.givenProvider) {
      const collectionsCollectionRef = collection(database, "collections");

      getDocs(collectionsCollectionRef).then((snapshot) => {
        let collections = [];

        snapshot.docs.forEach((doc) => {
          collections.push({ ...doc.data(), id: doc.id });
        });

        collections.forEach(async (collection) => {
          const web3 = new Web3(Web3.givenProvider);
          await Web3.givenProvider.enable();

          const contract = new web3.eth.Contract(
            placeholderContractABI,
            collection.contractAddress
          );

          contract.methods
            .totalSupply()
            .call()
            .then((totalSupplyRes) => {
              for (let i = 0; i <= 4; i++) {
                contract.methods
                  .tokenURI(i)
                  .call()
                  .then((jsonLink) => {
                    const newJsonLink = convertJsonLinks(jsonLink)
                if(getObjectType(newJsonLink) == "string"){
                    axios.get(newJsonLink).then((res) => {
                      res.data.tokenID = i;
                      res.data.collectionURL = collection.url;
                      res.data.collectionTitle = collection.title;
                      res.data.collectionLogoImage = collection.logoImage;

                      setHotNFTs((hotNFTs) => {
                        return [...hotNFTs, res.data];
                      });
                    });
                  }else{
                    newJsonLink.tokenID = i;
                    newJsonLink.collectionURL = collection.url;
                    newJsonLink.collectionTitle = collection.title;
                    newJsonLink.collectionLogoImage = collection.logoImage;

                      setHotNFTs((hotNFTs) => {
                        return [...hotNFTs, newJsonLink];
                      });
                  }
                  });
              }
            });
        });
      });
    }
  }, []);

  // Fetch Collections
  useEffect(() => {
    if (Web3.givenProvider) {
      const collectionsCollectionRef = collection(database, "collections");

      getDocs(collectionsCollectionRef).then((snapshot) => {
        snapshot.docs.forEach((doc) => {
          setCollections((collections) => {
            return [...collections, doc.data()];
          });
        });
      });
    }
  }, []);

  return (
    <React.Fragment>
      <main className="landing-page">
        <section className="hero">
          <div className="container">
            <div className="hero-left">
              <h1>Discover all the extraordinary NFTs on MTV!</h1>
              <p>
                MTVArt is the premier community run NFT Marketplace on MultiVAC.
              </p>

              <div className="btns">
                <Link to="/explore">
                  <button className="primary-btn">
                    <span>Explore</span>
                  </button>
                </Link>

                <Link to="/get-started">
                  <button className="secondary-btn">
                    <span>Get started</span>
                  </button>
                </Link>
              </div>
            </div>
            <div className="hero-right">
              <img
                src="/images/pages/landing/hero-img-1.png"
                alt=""
                className="hero-img-1"
              />
            </div>
          </div>
        </section>

        <section className="explore">
          <div className="container">
            <div className="top-part">
              <div className="top-part-left">
                <h2>Explore NFTs</h2>

                <div className="filters">
                  <button
                    className={activeFilter === 1 ? "filter active" : "filter"}
                    onClick={() => {
                      setActiveFilter(1);
                    }}
                  >
                    Hot
                  </button>
                  <button
                    className={activeFilter === 2 ? "filter active" : "filter"}
                    onClick={() => {
                      setActiveFilter(2);
                    }}
                  >
                    Trending
                  </button>
                  <button
                    className={activeFilter === 3 ? "filter active" : "filter"}
                    onClick={() => {
                      setActiveFilter(3);
                    }}
                  >
                    New
                  </button>
                </div>
              </div>

              <div className="top-part-right">
                <Link to="/assets">
                  <button>See all</button>
                </Link>
              </div>
            </div>

            <div className="boxes">
              {onSaleNFTs.map((onSaleNFT, index) => {
                if(index > 10) return null;

                let imageLinkExtension = onSaleNFT.image.split("/");
                imageLinkExtension =
                  imageLinkExtension[imageLinkExtension.length - 1];

                let newImageLink = ipfsGatewayTools.convertToDesiredGateway(
                  onSaleNFT.image,
                  "https://mtv-art.mypinata.cloud"
                );
                  if(!newImageLink.endsWith(imageLinkExtension))
                newImageLink = newImageLink + "/" + imageLinkExtension;

                return (
                  <Link
                    to={`/assets/${onSaleNFT.collectionURL}/${onSaleNFT.tokenID}`}
                    key={index}
                  >
                    <div className="box">
                      <div className="box-top-part">
                        <img src={newImageLink} alt="" />
                      </div>

                      <div className="box-center-part">
                        <h3>{onSaleNFT.name.substring(0, 8)}...</h3>
                        <div className="chain">
                          <p>MTV</p>
                        </div>
                      </div>

                      <div className="box-bottom-part">
                        <div className="box-bottom-part-left">
                          <div className="creator-img-placeholder">
                            <img
                              src={
                                onSaleNFT.collectionLogoImage !== "default"
                                  ? onSaleNFT.collectionLogoImage
                                  : null
                              }
                              alt=""
                              className={
                                onSaleNFT.collectionLogoImage !== "default"
                                  ? null
                                  : "disabled"
                              }
                            />
                          </div>
                          <p>
                            Collection <br />
                            <span>
                              {onSaleNFT.collectionTitle.substring(0, 8)}..
                            </span>
                          </p>
                        </div>

                        <div className="box-bottom-part-right">
                          <p>
                            Price <br />
                            <span>{onSaleNFT.price} MTV</span>
                          </p>
                        </div>
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>
        </section>

        <section className="collections">
          <div className="container">
            <div className="top-part">
              <div className="top-part-left">
                <h2>Top collections</h2>
              </div>

              <div className="top-part-right">
                <Link to="/collections">
                  <button>See all</button>
                </Link>
              </div>
            </div>

            <div className="boxes">
              {collections.map((collection, index) => {
                return (
                  <Link to={`/assets/${collection.url}`} key={index}>
                    <div className="box">
                      <img
                        src={
                          collection.logoImage !== "default"
                            ? collection.logoImage
                            : "/images/pages/landing/collection-logo-image.png"
                        }
                        alt=""
                      />

                      {collection.verified ? (
                        <svg
                          width="33"
                          height="33"
                          viewBox="0 0 33 33"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <circle
                            cx="16.5"
                            cy="16.5"
                            r="16.5"
                            fill="url(#paint0_linear_76_2)"
                          />
                          <path
                            d="M14.978 21.8073C14.8538 21.931 14.6846 22 14.5087 22C14.3328 22 14.1635 21.931 14.0394 21.8073L10.2917 18.094C9.90276 17.7087 9.90276 17.084 10.2917 16.6993L10.761 16.2344C11.15 15.8491 11.7799 15.8491 12.1689 16.2344L14.5087 18.5524L20.8311 12.289C21.2201 11.9037 21.8507 11.9037 22.239 12.289L22.7083 12.7539C23.0972 13.1392 23.0972 13.7639 22.7083 14.1486L14.978 21.8073Z"
                            fill="white"
                          />
                          <defs>
                            <linearGradient
                              id="paint0_linear_76_2"
                              x1="0"
                              y1="0"
                              x2="33"
                              y2="33"
                              gradientUnits="userSpaceOnUse"
                            >
                              <stop stopColor="#6CD1A3" />
                              <stop offset="1" stopColor="#438EB4" />
                            </linearGradient>
                          </defs>
                        </svg>
                      ) : null}
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>
        </section>

        <section className="explore">
          <div className="container">
            <div className="top-part">
              <div className="top-part-left">
                <h2>Newest Items</h2>
              </div>

              <div className="top-part-right">
                <Link to="/assets">
                  <button>See all</button>
                </Link>
              </div>
            </div>

            <div className="boxes">
              {newestNFTs.map((NFT, index) => {
                if(index > 10) return null;

                let imageLinkExtension = NFT.image.split("/");
                imageLinkExtension =
                  imageLinkExtension[imageLinkExtension.length - 1];

                let newImageLink = ipfsGatewayTools.convertToDesiredGateway(
                  NFT.image,
                  "https://mtv-art.mypinata.cloud"
                );
                if(!newImageLink.endsWith(imageLinkExtension))
                newImageLink = newImageLink + "/" + imageLinkExtension;

                return (
                  <Link
                    to={`/assets/${NFT.collectionURL}/${NFT.tokenID}`}
                    key={index}
                  >
                    <div className="box">
                      <div className="box-top-part">
                        <img src={newImageLink} alt="" />
                      </div>

                      <div className="box-center-part">
                        <h3>{NFT.name.substring(0, 8)}...</h3>
                        <div className="chain">
                          <p>MTV</p>
                        </div>
                      </div>

                      <div className="box-bottom-part">
                        <div className="box-bottom-part-left">
                          <div className="creator-img-placeholder">
                            <img
                              src={
                                NFT.collectionLogoImage !== "default"
                                  ? NFT.collectionLogoImage
                                  : null
                              }
                              alt=""
                              className={
                                NFT.collectionLogoImage !== "default"
                                  ? null
                                  : "disabled"
                              }
                            />
                          </div>
                          <p>
                            Collection <br />
                            <span>{NFT.collectionTitle.substring(0, 8)}..</span>
                          </p>
                        </div>
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>
        </section>

        <section className="explore">
          <div className="container">
            <div className="top-part">
              <div className="top-part-left">
                <h2>Hot NFTs</h2>
              </div>

              <div className="top-part-right">
                <Link to="/assets">
                  <button>See all</button>
                </Link>
              </div>
            </div>

            <div className="boxes">
              {hotNFTs.map((NFT, index) => {
                if(index > 10 )
                return null;

                let imageLinkExtension = NFT.image.split("/");
                imageLinkExtension =
                  imageLinkExtension[imageLinkExtension.length - 1];

                let newImageLink = ipfsGatewayTools.convertToDesiredGateway(
                  NFT.image,
                  "https://mtv-art.mypinata.cloud"
                );
                if(!newImageLink.endsWith(imageLinkExtension))
                newImageLink = newImageLink + "/" + imageLinkExtension;

                return (
                  <Link
                    to={`/assets/${NFT.collectionURL}/${NFT.tokenID}`}
                    key={index}
                  >
                    <div className="box">
                      <div className="box-top-part">
                        <img src={newImageLink} alt="" />
                      </div>

                      <div className="box-center-part">
                        <h3>{NFT.name.substring(0, 8)}...</h3>
                        <div className="chain">
                          <p>MTV</p>
                        </div>
                      </div>

                      <div className="box-bottom-part">
                        <div className="box-bottom-part-left">
                          <div className="creator-img-placeholder">
                            <img
                              src={
                                NFT.collectionLogoImage !== "default"
                                  ? NFT.collectionLogoImage
                                  : null
                              }
                              alt=""
                              className={
                                NFT.collectionLogoImage !== "default"
                                  ? null
                                  : "disabled"
                              }
                            />
                          </div>
                          <p>
                            Collection <br />
                            <span>{NFT.collectionTitle.substring(0, 8)}..</span>
                          </p>
                        </div>
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>
        </section>
      </main>
    </React.Fragment>
  );
};

export default Landing;
