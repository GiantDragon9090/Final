import React from "react";

const Error = () => {
  return (
    <React.Fragment>
      <main className="error-page">
        <p></p>
      </main>
    </React.Fragment>
  );
};

export default Error;
