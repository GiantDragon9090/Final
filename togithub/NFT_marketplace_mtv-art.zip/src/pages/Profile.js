import React, { useEffect, useState, useRef } from "react";
import { Link } from "react-router-dom";
import IPFSGatewayTools from "@pinata/ipfs-gateway-tools/dist/browser";
import axios from "axios";
import { convertJsonLinks, getObjectType } from "./util";
// Redux
import { useSelector } from "react-redux";

// Web3
import Web3 from "web3";

// Firebase
import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  where,
} from "firebase/firestore";
import database from "../config/firebase";

// Components
import Authenticator from "../components/Authenticator";

// Contracts Data
import { placeholderContractABI } from "../data/smart-contracts";

const Profile = () => {
  // States
  const ipfsGatewayTools = new IPFSGatewayTools();

  const wallet = useSelector((state) => state.wallet);
  const authenticated = useSelector((state) => state.authenticated);

  const [user, setUser] = useState({});
  const [ownedNFTs, setOwnedNFTs] = useState([]);
  const [onSaleNFTs, setOnSaleNFTs] = useState([]);
  const [collections, setCollections] = useState([]);
  const [activities, setActivities] = useState([]);

  const [activeTab, setActiveTab] = useState(1);
  const curPage = useRef(1)
  const [hasMore, setHasMore] = useState(1)
  const pagePerCount = 3
  let j;
  // Fetch Data
  useEffect(() => {
    if (Web3.givenProvider) {
      if (authenticated) {
        const usersCollectionRef = doc(database, "users", wallet.id);

        getDoc(usersCollectionRef).then((snapshot) => {
          setUser(snapshot.data());
        });
      }
    }
  }, [authenticated]);

  const fetchOwnNFTs = async() => {
    const collectionsCollectionRef = collection(database, "collections");
    setOwnedNFTs([])
    setHasMore(-1)
    await getDocs(collectionsCollectionRef).then(async(snapshot) => {
      let collections = [];

      snapshot.docs.forEach((doc) => {
        collections.push({ ...doc.data(), id: doc.id });
      });
      const web3 = new Web3(Web3.givenProvider);
      await Web3.givenProvider.enable();

      let previouseCnt = 0;
      let fetched = 0;
      let hastemp = false;
      for(let j = 0 ; j < collections.length ; j ++){
        const collection = collections[j]
        const contract = new web3.eth.Contract(
          placeholderContractABI,
          collection.contractAddress
        );
        await contract.methods
        .balanceOf(wallet.address)
        .call()
        .then(async (bcount)=> {
          if(fetched == pagePerCount && bcount > 0){
            setHasMore(1)
            hastemp = true
            j = collections.length
            return
          }
          previouseCnt += bcount * 1;
          if(previouseCnt <= pagePerCount * (curPage.current - 1) || fetched == pagePerCount) return;
          const startVal = (fetched == 0 ? bcount - (previouseCnt + pagePerCount * 1 - curPage.current * pagePerCount ) : 0)
          for( let i = startVal ; i < bcount && fetched < pagePerCount ; i ++){
            try{
              const token = await contract.methods.tokenOfOwnerByIndex(wallet.address, i).call();
              await contract.methods
                    .tokenURI(token)
                    .call()
                    .then(async(jsonLink) => {
                      const newJsonLink = convertJsonLinks(jsonLink)
                      if(getObjectType(newJsonLink) == "string"){
                      await axios.get(newJsonLink).then(async(res) => {
                        res.data.collectionURL = collection.url;
                        res.data.tokenID = token;
                        
                        setOwnedNFTs((ownedNFTs) => {
                          return [...ownedNFTs, res.data];
                        });
                        fetched ++;
                        if(fetched == pagePerCount  && i < bcount-1){
                          setHasMore(1)
                          hastemp = true
                        }
                      });
                    }else{
                      newJsonLink.collectionURL = collection.url;
                      newJsonLink.tokenID = token;                  
                      setOwnedNFTs((ownedNFTs) => {
                        return [...ownedNFTs, newJsonLink];
                      });
                      fetched ++;
                      if(fetched == pagePerCount && i < bcount-1){
                        setHasMore(1)
                        hastemp = true
                      }
                    }
                  });
            }catch(e){
              i = bcount-1;
              await contract.methods
              .walletOfOwner(wallet.address)
              .call()
              .then(async(result) => {
                if (result.length > 0) {
                  for( let k = startVal ; k < result.length && fetched < pagePerCount ; k ++){
                    const token = result[k]
                    await contract.methods
                      .tokenURI(token)
                      .call()
                      .then(async(jsonLink) => {
                        const newJsonLink = convertJsonLinks(jsonLink)
                        if(getObjectType(newJsonLink) == "string"){
                          await axios.get(newJsonLink).then(async(res) => {
                            res.data.collectionURL = collection.url;
                            res.data.tokenID = token;
  
                          setOwnedNFTs((ownedNFTs) => {
                            return [...ownedNFTs, res.data];
                          });
                          fetched ++;
                          if(fetched == pagePerCount  && k < result.length - 1){
                            setHasMore(1)
                            hastemp = true
                          }
                        });
                      }else{
                        newJsonLink.collectionURL = collection.url;
                        newJsonLink.tokenID = token;
  
                          setOwnedNFTs((ownedNFTs) => {
                            return [...ownedNFTs, newJsonLink];
                          });
                          fetched ++;
                          if(fetched == pagePerCount && k < result.length - 1){
                            setHasMore(1)
                            hastemp = true
                          }
                      }
                      });
                }
              }
              });
            }//catch ended
          }
        });
      }
      if(!hastemp){
        setHasMore(0)
      }
    });

  }

  // Fetch Owned NFTs
  useEffect(fetchOwnNFTs, [authenticated]);

  // Fetch On Sale NFTs
  useEffect(async () => {
    if (Web3.givenProvider) {
      if (authenticated) {
        const listingsCollectionRef = collection(database, "listings");
        const listingsCollectionQueryRef = query(
          listingsCollectionRef,
          where("sellerWalletAddress", "==", wallet.address),
          where("status", "==", "listed")
        );

        getDocs(listingsCollectionQueryRef).then((snapshot) => {
          let listings = [];

          snapshot.docs.forEach((doc) => {
            listings.push({ ...doc.data(), id: doc.id });
          });

          listings.forEach(async (listing) => {
            const web3 = new Web3(Web3.givenProvider);
            await Web3.givenProvider.enable();

            const contract = new web3.eth.Contract(
              placeholderContractABI,
              listing.contractAddress
            );

            let collectionURL = "";

            const collectionsCollectionRef = collection(
              database,
              "collections"
            );
            const collectionsCollectionQueryRef = query(
              collectionsCollectionRef,
              where("contractAddress", "==", listing.contractAddress)
            );

            getDocs(collectionsCollectionQueryRef).then((snapshot) => {
              let collections = [];

              snapshot.docs.forEach((doc) => {
                collections.push({ ...doc.data(), id: doc.id });
                collectionURL = collections[0].url;
              });

              contract.methods
                .tokenURI(listing.tokenID)
                .call()
                .then((jsonLink) => {
                  const newJsonLink = convertJsonLinks(jsonLink)
                if(getObjectType(newJsonLink) == "string"){
                  axios.get(newJsonLink).then((res) => {
                    res.data.collectionURL = collectionURL;
                    res.data.tokenID = listing.tokenID;

                    setOnSaleNFTs((onSaleNFTs) => {
                      return [...onSaleNFTs, res.data];
                    });
                  });
                }else{
                  newJsonLink.collectionURL = collectionURL;
                  newJsonLink.tokenID = listing.tokenID;

                    setOnSaleNFTs((onSaleNFTs) => {
                      return [...onSaleNFTs, newJsonLink];
                    });
                }
                });
            });
          });
        });
      }
    }
  }, [authenticated]);

  // Fetch Collections
  useEffect(() => {
    if (Web3.givenProvider) {
      if (authenticated) {
        const collectionsCollectionRef = collection(database, "collections");
        const collectionsCollectionQueryRef = query(
          collectionsCollectionRef,
          where("ownerWalletAddress", "==", wallet.address)
        );

        getDocs(collectionsCollectionQueryRef).then((snapshot) => {
          snapshot.docs.forEach((doc) => {
            setCollections((collections) => {
              return [...collections, doc.data()];
            });
          });
        });
      }
    }
  }, [authenticated]);

  // Fetch Activities
  useEffect(() => {
    if (Web3.givenProvider) {
      if (authenticated) {
        const activitiesCollectionRef = collection(database, "activities");
        const activitiesCollectionQueryRef = query(
          activitiesCollectionRef,
          where("walletAddress", "==", wallet.address)
        );

        getDocs(activitiesCollectionQueryRef).then((snapshot) => {
          snapshot.docs.forEach((doc) => {
            setActivities((activities) => {
              return [...activities, doc.data()];
            });
          });
        });
      }
    }
  }, [authenticated]);

  return (
    <React.Fragment>
      <Authenticator />

      {authenticated ? (
        <main className="profile-page">
          <section className="profile-info">
            <div className="container">
              <div className="profile-cover-placeholder">
                <img
                  src={
                    user.profileBanner !== "default" ? user.profileBanner : null
                  }
                  alt=""
                  className={
                    user.profileBanner !== "default" ? null : "disabled"
                  }
                />
              </div>
              <div className="profile-image-placeholder">
                <img
                  src={
                    user.profileImage !== "default" ? user.profileImage : null
                  }
                  alt=""
                  className={
                    user.profileImage !== "default" ? null : "disabled"
                  }
                />
              </div>

              <h3 className="name">{user.name ? user.name : null}</h3>
              <p className="wallet-address">{wallet.address}</p>

              <p className="bio">{user.bio ? user.bio : null}</p>

              <button className="share-btn">
                <i className="bi bi-share-fill"></i>
              </button>

              <Link to="/profile/settings" className="settings-btn">
                <i className="bi bi-gear-fill"></i>
              </Link>
            </div>
          </section>

          <section className="tabs">
            <div className="container">
              <div className="tabs-navigation">
                <button
                  className={activeTab === 1 ? "active" : null}
                  onClick={() => {
                    setActiveTab(1);
                  }}
                >
                  Owned
                </button>
                <button
                  className={activeTab === 2 ? "active" : null}
                  onClick={() => {
                    setActiveTab(2);
                  }}
                >
                  On sale
                </button>
                <button
                  className={activeTab === 3 ? "active" : null}
                  onClick={() => {
                    setActiveTab(3);
                  }}
                >
                  Created
                </button>
                <button
                  className={activeTab === 4 ? "active" : null}
                  onClick={() => {
                    setActiveTab(4);
                  }}
                >
                  Collections
                </button>
                <button
                  className={activeTab === 5 ? "active" : null}
                  onClick={() => {
                    setActiveTab(5);
                  }}
                >
                  Activity
                </button>
              </div>

              <div className="tabs-wrapper">
                <div className={activeTab === 1 ? "tab active" : "tab"}>
                  {ownedNFTs.length > 0 ? (
                    <div className="owned-nfts">
                      {ownedNFTs.map((ownedNFT, index) => {
                        let imageLinkExtension = ownedNFT.image.split("/");
                        imageLinkExtension =
                          imageLinkExtension[imageLinkExtension.length - 1];

                        let newImageLink =
                          ipfsGatewayTools.convertToDesiredGateway(
                            ownedNFT.image,
                            "https://mtv-art.mypinata.cloud"
                          );
                          if(!newImageLink.endsWith(imageLinkExtension))
                        newImageLink = newImageLink + "/" + imageLinkExtension;

                        return (
                          <Link
                            to={`/assets/${ownedNFT.collectionURL}/${ownedNFT.tokenID}`}
                            key={index}
                          >
                            <div className="owned-nft">
                              <img src={newImageLink} alt="" />
                              <h4>{ownedNFT.name ? ownedNFT.name : "???"}</h4>
                            </div>
                          </Link>
                        );
                      })}
                    </div>

                  ) : (
                    <div className="not-found-box">
                      <h4>No items found</h4>
                      <p>
                        Come back soon! Or try to browse something for you on
                        our marketplace
                      </p>

                      <div className="btns">
                        <Link to="/assets">
                          <button className="primary-btn">
                            <span>Browse marketplace</span>
                          </button>
                        </Link>
                      </div>
                    </div>
                  )}
                  <div className="pagination">
                      {curPage.current > 1 && hasMore != -1? (
                        <button
                          className="prev-btn"
                          onClick={() => {
                            curPage.current = curPage.current - 1;
                            fetchOwnNFTs();
                          }}
                        >
                          <span>Prev</span>
                        </button>
                      ) : null}

                      {hasMore == 1 ? (
                        <button
                          className="next-btn"
                          onClick={() => {
                            curPage.current = curPage.current + 1;
                            fetchOwnNFTs();
                          }}
                        >
                          <span>Next</span>
                        </button>
                      ) : null}
                    </div>
                </div>

                <div className={activeTab === 2 ? "tab active" : "tab"}>
                  {onSaleNFTs.length > 0 ? (
                    <div className="owned-nfts">
                      {onSaleNFTs.map((onSaleNFT, index) => {
                        let imageLinkExtension = onSaleNFT.image.split("/");
                        imageLinkExtension =
                          imageLinkExtension[imageLinkExtension.length - 1];

                        let newImageLink =
                          ipfsGatewayTools.convertToDesiredGateway(
                            onSaleNFT.image,
                            "https://mtv-art.mypinata.cloud"
                          );
                          if(!newImageLink.endsWith(imageLinkExtension))
                        newImageLink = newImageLink + "/" + imageLinkExtension;

                        return (
                          <Link
                            to={`/assets/${onSaleNFT.collectionURL}/${onSaleNFT.tokenID}`}
                            key={index}
                          >
                            <div className="owned-nft">
                              <img src={newImageLink} alt="" />
                              <h4>{onSaleNFT.name ? onSaleNFT.name : "???"}</h4>
                            </div>
                          </Link>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="not-found-box">
                      <h4>No items found</h4>
                      <p>
                        Come back soon! Or try to browse something for you on
                        our marketplace
                      </p>

                      <div className="btns">
                        <Link to="/assets">
                          <button className="primary-btn">
                            <span>Browse marketplace</span>
                          </button>
                        </Link>
                      </div>
                    </div>
                  )}
                </div>

                <div className={activeTab === 3 ? "tab active" : "tab"}>
                  <div className="not-found-box">
                    <h4>No items found</h4>
                    <p>
                      Come back soon! Or try to create something for you on our
                      marketplace
                    </p>

                    <div className="btns">
                      <Link to="/assets">
                        <button className="primary-btn">
                          <span>Create</span>
                        </button>
                      </Link>
                    </div>
                  </div>
                </div>

                <div className={activeTab === 4 ? "tab active" : "tab"}>
                  {collections.length > 0 ? (
                    <div className="collections">
                      {collections.map((collection, index) => {
                        return (
                          <Link to={`/assets/${collection.url}`} key={index}>
                            <div className="collection">
                              <div className="banner-image-placeholder">
                                <img
                                  src={
                                    collection.bannerImage !== "default"
                                      ? collection.bannerImage
                                      : null
                                  }
                                  alt=""
                                  className={
                                    collection.bannerImage !== "default"
                                      ? null
                                      : "disabled"
                                  }
                                />
                              </div>
                              <div className="logo-image-placeholder">
                                <img
                                  src={
                                    collection.logoImage !== "default"
                                      ? collection.logoImage
                                      : null
                                  }
                                  alt=""
                                  className={
                                    collection.logoImage !== "default"
                                      ? null
                                      : "disabled"
                                  }
                                />
                              </div>

                              <h4>{collection.title}</h4>
                            </div>
                          </Link>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="not-found-box">
                      <h4>No collections found</h4>
                      <p>
                        Come back soon! Or try to create collection for you on
                        our marketplace
                      </p>

                      <div className="btns">
                        <Link to="/import-collection">
                          <button className="primary-btn">
                            <span>Import</span>
                          </button>
                        </Link>

                        <Link to="/create-collection">
                          <button className="secondary-btn">
                            <span>Create</span>
                          </button>
                        </Link>
                      </div>
                    </div>
                  )}
                </div>

                <div className={activeTab === 5 ? "tab active" : "tab"}>
                  {activities.length > 0 ? (
                    <div className="activities">
                      <div className="title-row">
                        <p>Collection</p>
                        <p>Token ID</p>
                        <p>Action</p>
                        <p>Date</p>
                      </div>
                      {activities.map((activity, index) => {
                        return (
                          <div className="row">
                            <p className="collection">
                              {activity.contractAddress}
                            </p>
                            <p>{activity.tokenID}</p>
                            <p className="action">{activity.action}</p>
                            <p>{new Date(activity.date).toDateString()}</p>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="not-found-box">
                      <h4>No activities found</h4>
                      <p>
                        Come back soon! Or try to trade something for you on our
                        marketplace
                      </p>

                      <div className="btns">
                        <Link to="/assets">
                          <button className="primary-btn">
                            <span>Browse marketplace</span>
                          </button>
                        </Link>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </section>
        </main>
      ) : (
        <p className="loader">Loading...</p>
      )}
    </React.Fragment>
  );
};

export default Profile;
