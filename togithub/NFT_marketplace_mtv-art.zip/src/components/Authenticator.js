import { useNavigate } from "react-router-dom";

// Redux
import { useDispatch, useSelector } from "react-redux";
import { actions } from "../redux/index";

// Firebase
import { collection, getDocs, query, where } from "firebase/firestore";
import database from "../config/firebase";

const Authenticator = () => {
  // States
  const navigate = useNavigate();

  const wallet = useSelector((state) => state.wallet);

  // Actions
  const dispatch = useDispatch();

  if (wallet.connected) {
    const usersCollectionRef = collection(database, "users");
    const usersCollectionQueryRef = query(
      usersCollectionRef,
      where("walletAddress", "==", wallet.address)
    );

    getDocs(usersCollectionQueryRef).then((snapshot) => {
      let users = [];

      snapshot.docs.forEach((doc) => {
        users.push({ ...doc.data(), id: doc.id });
      });

      if (users.length === 1) {
        dispatch(actions.authenticationStatus(true));
      } else {
        dispatch(actions.authenticationStatus(false));
        navigate("/", { replace: true });
      }
    });
  } else {
    dispatch(actions.authenticationStatus(false));
    navigate("/", { replace: true });
  }

  return null;
};

export default Authenticator;
