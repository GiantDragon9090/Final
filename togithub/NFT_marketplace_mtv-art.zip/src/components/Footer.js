import React from "react";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <React.Fragment>
      <footer>
        <div className="container">
          <div className="footer-left">
            <Link to="/" className="logo">
              <img src="/images/brand/logo.png" alt="" />
            </Link>

            <h3>Get the latest updates</h3>
            <div className="form">
              <input type="text" placeholder="Your e-mail" />
              <button>
                <span>Subscribe</span>
              </button>
            </div>
          </div>

          <div className="footer-right">
            <div className="footer-right-top">
              <h3>Join the community</h3>

              <div className="social-links">
                <a href="" target="_blank">
                  <svg
                    width="40"
                    height="40"
                    viewBox="0 0 40 40"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <rect
                      width="40"
                      height="40"
                      rx="12"
                      fill="url(#paint0_linear_26_724)"
                    />
                    <path
                      d="M23.4757 21L23.8906 18.1044H21.2968V16.2253C21.2968 15.4332 21.6591 14.661 22.8208 14.661H24V12.1956C24 12.1956 22.9299 12 21.9068 12C19.7707 12 18.3744 13.3868 18.3744 15.8975V18.1044H16V21H18.3744V28H21.2968V21H23.4757Z"
                      fill="white"
                    />
                    <defs>
                      <linearGradient
                        id="paint0_linear_26_724"
                        x1="0"
                        y1="0"
                        x2="44.9525"
                        y2="6.68186"
                        gradientUnits="userSpaceOnUse"
                      >
                        <stop stopColor="#6CD1A3" />
                        <stop offset="1" stopColor="#438EB4" />
                      </linearGradient>
                    </defs>
                  </svg>
                </a>

                <a href="" target="_blank">
                  <svg
                    width="40"
                    height="40"
                    viewBox="0 0 40 40"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <rect
                      width="40"
                      height="40"
                      rx="12"
                      fill="url(#paint0_linear_26_726)"
                    />
                    <path
                      d="M20.002 15.1414C17.4481 15.1414 15.3881 17.0874 15.3881 19.5C15.3881 21.9126 17.4481 23.8585 20.002 23.8585C22.5559 23.8585 24.616 21.9126 24.616 19.5C24.616 17.0874 22.5559 15.1414 20.002 15.1414ZM20.002 22.3337C18.3516 22.3337 17.0023 21.0628 17.0023 19.5C17.0023 17.9372 18.3476 16.6663 20.002 16.6663C21.6564 16.6663 23.0017 17.9372 23.0017 19.5C23.0017 21.0628 21.6524 22.3337 20.002 22.3337ZM25.8809 14.9631C25.8809 15.5283 25.399 15.9797 24.8047 15.9797C24.2064 15.9797 23.7285 15.5245 23.7285 14.9631C23.7285 14.4017 24.2104 13.9465 24.8047 13.9465C25.399 13.9465 25.8809 14.4017 25.8809 14.9631ZM28.9368 15.995C28.8685 14.6331 28.5392 13.4268 27.4831 12.4329C26.431 11.4391 25.154 11.128 23.7124 11.0597C22.2267 10.9801 17.7733 10.9801 16.2876 11.0597C14.85 11.1242 13.573 11.4353 12.5169 12.4292C11.4608 13.423 11.1355 14.6293 11.0632 15.9911C10.9789 17.3946 10.9789 21.6015 11.0632 23.005C11.1315 24.3669 11.4608 25.5732 12.5169 26.5671C13.573 27.5609 14.846 27.872 16.2876 27.9402C17.7733 28.0199 22.2267 28.0199 23.7124 27.9402C25.154 27.8758 26.431 27.5647 27.4831 26.5671C28.5352 25.5732 28.8645 24.3669 28.9368 23.005C29.0211 21.6015 29.0211 17.3984 28.9368 15.995ZM27.0173 24.511C26.7041 25.2546 26.0977 25.8273 25.3066 26.127C24.122 26.5708 21.3111 26.4684 20.002 26.4684C18.6929 26.4684 15.878 26.5671 14.6974 26.127C13.9103 25.8312 13.304 25.2583 12.9867 24.511C12.5169 23.392 12.6253 20.7366 12.6253 19.5C12.6253 18.2634 12.5209 15.6042 12.9867 14.489C13.2999 13.7454 13.9063 13.1726 14.6974 12.873C15.882 12.4292 18.6929 12.5316 20.002 12.5316C21.3111 12.5316 24.126 12.4329 25.3066 12.873C26.0937 13.1688 26.7001 13.7417 27.0173 14.489C27.4871 15.608 27.3787 18.2634 27.3787 19.5C27.3787 20.7366 27.4871 23.3958 27.0173 24.511Z"
                      fill="white"
                    />
                    <defs>
                      <linearGradient
                        id="paint0_linear_26_726"
                        x1="0"
                        y1="0"
                        x2="44.9525"
                        y2="6.68186"
                        gradientUnits="userSpaceOnUse"
                      >
                        <stop stopColor="#6CD1A3" />
                        <stop offset="1" stopColor="#438EB4" />
                      </linearGradient>
                    </defs>
                  </svg>
                </a>

                <a href="" target="_blank">
                  <svg
                    width="40"
                    height="40"
                    viewBox="0 0 40 40"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <rect
                      width="40"
                      height="40"
                      rx="12"
                      fill="url(#paint0_linear_26_729)"
                    />
                    <path
                      d="M27.1498 15.7383C27.1612 15.9023 27.1612 16.0664 27.1612 16.2304C27.1612 21.2343 23.4493 27 16.665 27C14.5748 27 12.6332 26.3788 11 25.3008C11.297 25.3359 11.5825 25.3476 11.8909 25.3476C13.6155 25.3476 15.203 24.75 16.4708 23.7305C14.849 23.6953 13.4898 22.6054 13.0215 21.1055C13.25 21.1406 13.4784 21.164 13.7182 21.164C14.0495 21.164 14.3807 21.1172 14.6891 21.0352C12.9987 20.6836 11.7309 19.1602 11.7309 17.3203V17.2735C12.222 17.5547 12.7932 17.7305 13.3985 17.7538C12.4048 17.0742 11.7538 15.914 11.7538 14.6015C11.7538 13.8984 11.9365 13.2539 12.2564 12.6914C14.0723 14.9882 16.802 16.4882 19.8629 16.6523C19.8058 16.371 19.7716 16.0781 19.7716 15.7851C19.7716 13.6992 21.4162 12 23.4606 12C24.5229 12 25.4823 12.457 26.1561 13.1954C26.9898 13.0312 27.7893 12.7148 28.4975 12.2813C28.2233 13.1602 27.6409 13.8984 26.8756 14.3672C27.618 14.2852 28.3376 14.0742 29 13.7813C28.4976 14.5312 27.8693 15.1992 27.1498 15.7383Z"
                      fill="white"
                    />
                    <defs>
                      <linearGradient
                        id="paint0_linear_26_729"
                        x1="0"
                        y1="0"
                        x2="44.9525"
                        y2="6.68186"
                        gradientUnits="userSpaceOnUse"
                      >
                        <stop stopColor="#6CD1A3" />
                        <stop offset="1" stopColor="#438EB4" />
                      </linearGradient>
                    </defs>
                  </svg>
                </a>
              </div>
            </div>

            <div className="footer-right-bottom">
              <div className="footer-links">
                <h3>MTV.Art</h3>

                <Link to="/assets">Explore</Link>
                <Link to="/stats">Stats</Link>
                <Link to="/activities">Activities</Link>
              </div>

              {/* <div className="footer-links">
                <h3>Community</h3>

                <Link to="/">About</Link>
                <Link to="/">Blog</Link>
                <Link to="/">Subscribe</Link>
              </div> */}

              {/* <div className="footer-links">
                <h3>Others</h3>

                <Link to="/">Privacy Policy</Link>
                <Link to="/">Terms and conditions</Link>
              </div> */}
            </div>
          </div>
        </div>
      </footer>
    </React.Fragment>
  );
};

export default Footer;
