import React from "react";

const AnnouncementBar = () => {
  return (
    <React.Fragment>
      <header className="announcement-bar">
        <div className="container">
          <p>Under development, coming soon...</p>
        </div>
      </header>
    </React.Fragment>
  );
};

export default AnnouncementBar;
