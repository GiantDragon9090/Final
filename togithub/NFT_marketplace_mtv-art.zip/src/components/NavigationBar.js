import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

// Redux
import { useDispatch, useSelector } from "react-redux";
import { actions } from "../redux/index";

// Web3
import Web3 from "web3";
import Web3Modal from "web3modal";

// Firebase
import { addDoc, collection, getDocs, query, where } from "firebase/firestore";
import database from "../config/firebase";

const NavigationBar = () => {
  // Loader States
  const [signingInLoaderActive, setSigningInLoaderActive] = useState(false);

  // States
  const wallet = useSelector((state) => state.wallet);

  const [hamburgerMenuOpened, setHamburgerMenuOpened] = useState(false);

  // Actions
  const dispatch = useDispatch();

  // Functions
  useEffect(() => {
    walletAuthenticate();
  }, []);

  const signInAuth = async () => {
    console.log("dog")
    if (Web3.givenProvider) {
      setSigningInLoaderActive(true);

      const networks = {
        multivac: {
          chainId: `0x${Number(62621).toString(16)}`,
          chainName: "MultiVAC Mainnet",
          nativeCurrency: {
            name: "MTV",
            symbol: "MTV",
            decimals: 18,
          },
          rpcUrls: ["https://rpc.mtv.ac"],
          blockExplorerUrls: ["https://e.mtv.ac"],
        },
      };

      const providerOptions = {};

      // Connect Wallet
      const web3Modal = new Web3Modal({
        network: "mainnet",
        cacheProvider: true,
        providerOptions,
      });

      const provider = await web3Modal.connect();
      console.log("connect ok")
      const web3 = new Web3(provider);

      const walletAddresses = await web3.eth.getAccounts();
      const walletAddress = walletAddresses[0];

      console.log("account ok")
      const { ethereum } = window;

      const chainID = await ethereum.request({
        method: "net_version",
      });

      console.log("chainId oks")
      // Authenticating Chain Changed
      ethereum.on("chainChanged", async () => {
        console.log("sfr")
        const chainID = await ethereum.request({
          method: "net_version",
        });

        if (chainID === "62621") {
          console.log("here1")
          signIn(walletAddress);
        } else {
          window.location.href = "/";
        }
      }).on("notification", (msg) => {
        console.log("event", msg)
      });
      // ethereum.on("accountsChanged", async (accounts) => {
      //   await web3Modal.clearCachedProvider();
      //   localStorage.removeItem("wallet");

      //   window.location.href= "/";
      // });
      // Authenticating Chain ID
      if (chainID === "62621") {
        console.log("here2")
        signIn(walletAddress);
      } else {
        await ethereum.request({
          method: "wallet_addEthereumChain",
          params: [
            {
              ...networks["multivac"],
            },
          ],
        });
      }
    } else {
      window.open("https://metamask.io/download/", "_blank").focus();
    }
  };

  const signIn = async (walletAddress) => {
    const usersCollectionRef = collection(database, "users");
    const usersCollectionQueryRef = query(
      usersCollectionRef,
      where("walletAddress", "==", walletAddress)
    );

    getDocs(usersCollectionQueryRef).then((snapshot) => {
      const date = Date.now();
      let users = [];

      snapshot.docs.forEach((doc) => {
        users.push({ ...doc.data(), id: doc.id });
      });

      if (users.length === 1) {
        setSigningInLoaderActive(false);
        console.log("temp")
        dispatch(
          actions.signIn({
            connected: true,
            id: users[0].id,
            address: walletAddress,
          })
        );
      } else {
        addDoc(usersCollectionRef, {
          walletAddress: walletAddress,
          profileImage: "default",
          profileBanner: "default",
          name: "Unnamed",
          username: walletAddress,
          email: "",
          bio: "",
          websiteLink: "",
          discordLink: "",
          twitterLink: "",
          instagramLink: "",
          signedUpOn: date,
        }).then((doc) => {
          setSigningInLoaderActive(false);
          dispatch(
            actions.signIn({
              connected: true,
              id: doc.id,
              address: walletAddress,
            })
          );
        });
      }
    });
  };
  const { ethereum } = window;
  if(ethereum)
  ethereum.on("accountsChanged", async (accounts) => {
    const providerOptions = {};
    console.log("miss", accounts)
    // Connect Wallet
    const web3Modal = new Web3Modal({
      network: "mainnet",
      cacheProvider: true,
      providerOptions,
    });
    await web3Modal.clearCachedProvider();
    localStorage.removeItem("wallet");
    if(accounts.length === 0)
    window.location.href= "/";
  });
  // Realtime Authentication
  const walletAuthenticate = async () =>{
    if (Web3.givenProvider) {


      const networks = {
        multivac: {
          chainId: `0x${Number(62621).toString(16)}`,
          chainName: "MultiVAC Mainnet",
          nativeCurrency: {
            name: "MTV",
            symbol: "MTV",
            decimals: 18,
          },
          rpcUrls: ["https://rpc.mtv.ac"],
          blockExplorerUrls: ["https://e.mtv.ac"],
        },
      };

      const providerOptions = {};

      // Connect Wallet
      const web3Modal = new Web3Modal({
        network: "mainnet",
        cacheProvider: true,
        providerOptions,
      });

      const provider = await web3Modal.connect();
      console.log("connect ok")
      const web3 = new Web3(provider);

      const walletAddresses = await web3.eth.getAccounts();
      const walletAddress = walletAddresses[0];

      console.log("account ok")
      const { ethereum } = window;

      const chainID = await ethereum.request({
        method: "net_version",
      });

      console.log("chainId oks")
      // Authenticating Chain Changed
      ethereum.on("chainChanged", async () => {
        console.log("sfr")
        const chainID = await ethereum.request({
          method: "net_version",
        });

        if (chainID === "62621") {
          console.log("here1")
          signIn(walletAddress);
        } else {
          window.location.href = "/";
        }
      });
      ethereum.on("accountsChanged", async (accounts) => {
        await web3Modal.clearCachedProvider();
        localStorage.removeItem("wallet");

        window.location.href= "/";
      });
      // Authenticating Chain ID
      if (chainID === "62621") {
        console.log("here2")
        signIn(walletAddress);
      } else {
        await ethereum.request({
          method: "wallet_addEthereumChain",
          params: [
            {
              ...networks["multivac"],
            },
          ],
        });
      }
    } else {
    }      // window.open("https://metamask.io/download/", "_blank").focus();

  }

  const walletAuthenticate1 = async () => {
    if (Web3.givenProvider) {
      
      const networks = {
        multivac: {
          chainId: `0x${Number(62621).toString(16)}`,
          chainName: "MultiVAC Mainnet",
          nativeCurrency: {
            name: "MTV",
            symbol: "MTV",
            decimals: 18,
          },
          rpcUrls: ["https://rpc.mtv.ac"],
          blockExplorerUrls: ["https://e.mtv.ac"],
        },
      };
      const providerOptions = {};

      const web3Modal = new Web3Modal({
        network: "mainnet",
        cacheProvider: true,
        providerOptions,
      });
      console.log("modal ok")
      const provider = await web3Modal.connect();
      
      console.log("init connect ok")
      const web3 = new Web3(provider);

      const { ethereum } = window;

      const chainID = await ethereum.request({
        method: "net_version",
      });
      console.log("init chanID ok")
      
      const walletAddresses = await web3.eth.getAccounts();
      const walletAddress = walletAddresses[0];
      // Authenticating Chain Changed
      ethereum.on("chainChanged", async () => {
        const chainID = await ethereum.request({
          method: "net_version",
        });
        console.log(chainID)
        if (chainID === "62621") {
          console.log("here3")
          signIn(walletAddress);
        }

        window.location.href = "/temp";
      });

      ethereum.on("accountsChanged", async (accounts) => {
        await web3Modal.clearCachedProvider();
        localStorage.removeItem("wallet");

        window.location.href= "/";
      });
      if (chainID === "62621") {
        console.log("here4")
        signIn(walletAddress);
      } else {
        await ethereum.request({
          method: "wallet_addEthereumChain",
          params: [
            {
              ...networks["multivac"],
            },
          ],
        });
      }
    } else {
      window.open("https://metamask.io/download/", "_blank").focus();
    }
  };

 
  return (
    <React.Fragment>
      <nav>
        <div className="container">
          <Link to="/" className="logo">
            <img src="/images/brand/logo.png" alt="" />
          </Link>

          <button
            className="hamburger-menu-open-trigger"
            onClick={() => {
              setHamburgerMenuOpened(!hamburgerMenuOpened);
            }}
          >
            <svg
              width="33"
              height="24"
              viewBox="0 0 33 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M31 0H2C0.89543 0 0 0.89543 0 2C0 3.10457 0.89543 4 2 4H31C32.1046 4 33 3.10457 33 2C33 0.89543 32.1046 0 31 0Z"
                fill="black"
              />
              <path
                d="M31 10H2C0.89543 10 0 10.8954 0 12C0 13.1046 0.89543 14 2 14H31C32.1046 14 33 13.1046 33 12C33 10.8954 32.1046 10 31 10Z"
                fill="black"
              />
              <path
                d="M31 20H2C0.89543 20 0 20.8954 0 22C0 23.1046 0.89543 24 2 24H31C32.1046 24 33 23.1046 33 22C33 20.8954 32.1046 20 31 20Z"
                fill="black"
              />
            </svg>
          </button>

          <div className="navigation-bar-items">
            <ul>
              <li>
                <Link to="/">Home</Link>
              </li>
              <li>
                <Link to="/assets">Explore</Link>
              </li>
              <li>
                <Link to="/collections">Collections</Link>
              </li>
              <li>
                <Link to="/stats">Stats</Link>
              </li>
              <li>
                <Link to="/activities">Activities</Link>
              </li>
            </ul>

            <div className="btns">
              <Link to="/get-started">
                <button className="primary-btn">
                  <span>Create collection</span>
                </button>
              </Link>

              {wallet.connected === true ? (
                <Link to="/profile">
                  <button className="secondary-btn">
                    <span>Profile</span>
                  </button>
                </Link>
              ) : (
                <button className="secondary-btn" onClick={signInAuth}>
                  <span>
                    {signingInLoaderActive ? "Signing in..." : "Sign in"}
                  </span>
                </button>
              )}
            </div>
          </div>
        </div>
      </nav>

      <div
        className={
          hamburgerMenuOpened ? "hamburger-menu active" : "hamburger-menu"
        }
      >
        <button
          className="hamburger-menu-close-trigger"
          onClick={() => {
            setHamburgerMenuOpened(!hamburgerMenuOpened);
          }}
        >
          <svg
            width="27"
            height="27"
            viewBox="0 0 27 27"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <rect
              x="3.28516"
              y="0.508545"
              width="33"
              height="4"
              rx="2"
              transform="rotate(45 3.28516 0.508545)"
              fill="black"
            ></rect>
            <rect
              y="23.3345"
              width="33"
              height="4"
              rx="2"
              transform="rotate(-45 0 23.3345)"
              fill="black"
            ></rect>
          </svg>
        </button>

        <div className="form">
          <svg
            width="16"
            height="16"
            viewBox="0 0 16 16"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              fillRule="evenodd"
              clipRule="evenodd"
              d="M2 7C2 4.23858 4.23858 2 7 2C9.76142 2 12 4.23858 12 7C12 9.76142 9.76142 12 7 12C4.23858 12 2 9.76142 2 7ZM7 0C3.13401 0 0 3.13401 0 7C0 10.866 3.13401 14 7 14C8.57591 14 10.0302 13.4792 11.2001 12.6004C11.2281 12.6376 11.259 12.6733 11.2929 12.7071L14.2929 15.7071C14.6834 16.0976 15.3166 16.0976 15.7071 15.7071C16.0976 15.3166 16.0976 14.6834 15.7071 14.2929L12.7071 11.2929C12.6733 11.259 12.6376 11.2281 12.6004 11.2001C13.4792 10.0302 14 8.57591 14 7C14 3.13401 10.866 0 7 0Z"
              fill="#8E8E8E"
            />
          </svg>

          <input type="text" placeholder="Collection, item or user" />
        </div>

        <ul>
        <li>
            <Link
              to="/"
              onClick={() => {
                setHamburgerMenuOpened(false);
              }}
            >
              Home <i className="bi bi-caret-right-fill"></i>
            </Link>
          </li>
          <li>
            <Link
              to="/assets"
              onClick={() => {
                setHamburgerMenuOpened(false);
              }}
            >
              Explore <i className="bi bi-caret-right-fill"></i>
            </Link>
          </li>
          <li>
            <Link
              to="/collections"
              onClick={() => {
                setHamburgerMenuOpened(false);
              }}
            >
              Collections <i className="bi bi-caret-right-fill"></i>
            </Link>
          </li>
          <li>
            <Link
              to="/stats"
              onClick={() => {
                setHamburgerMenuOpened(false);
              }}
            >
              Stats <i className="bi bi-caret-right-fill"></i>
            </Link>
          </li>
          <li>
            <Link
              to="/activities"
              onClick={() => {
                setHamburgerMenuOpened(false);
              }}
            >
              Activities <i className="bi bi-caret-right-fill"></i>
            </Link>
          </li>
        </ul>

        <div className="btns">
          <Link
            to="/get-started"
            onClick={() => {
              setHamburgerMenuOpened(false);
            }}
          >
            <button className="primary-btn">
              <span>Create collection</span>
            </button>
          </Link>

          {wallet.connected === true ? (
            <Link
              to="/profile"
              onClick={() => {
                setHamburgerMenuOpened(false);
              }}
            >
              <button className="secondary-btn">
                <span>Profile</span>
              </button>
            </Link>
          ) : (
            <button className="secondary-btn" onClick={signInAuth}>
              <span>{signingInLoaderActive ? "Signing in..." : "Sign in"}</span>
            </button>
          )}
        </div>
      </div>
    </React.Fragment>
  );
};

export default NavigationBar;
