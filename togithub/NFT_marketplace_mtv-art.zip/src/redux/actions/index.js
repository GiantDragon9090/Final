// Sign In
export const signIn = (state) => {
  return (dispatch) => {
    dispatch({
      type: "signIn",
      payload: state,
    });
  };
};

// Sign Out
export const signOut = (state) => {
  return (dispatch) => {
    dispatch({
      type: "signOut",
      payload: state,
    });
  };
};

// Authentication Status
export const authenticationStatus = (state) => {
  return (dispatch) => {
    dispatch({
      type: "authenticationStatus",
      payload: state,
    });
  };
};