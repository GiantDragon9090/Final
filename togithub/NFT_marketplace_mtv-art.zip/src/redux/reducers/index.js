import { combineReducers } from "redux";

import wallet from "./wallet";
import authenticated from "./authenticated";

const reducers = combineReducers({
  wallet,
  authenticated,
});

export default reducers;
