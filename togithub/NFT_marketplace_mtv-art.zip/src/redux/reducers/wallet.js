// Wallet
let initialState = {
  connected: false,
  id: null,
  address: null,
};

if (localStorage.getItem("wallet")) {
  initialState = JSON.parse(localStorage.getItem("wallet"));
}

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case "signIn":
      localStorage.setItem(
        "wallet",
        JSON.stringify({
          connected: action.payload.connected,
          id: action.payload.id,
          address: action.payload.address,
        })
      );

      return {
        connected: action.payload.connected,
        id: action.payload.id,
        address: action.payload.address,
      };
    default:
      return state;
  }
};

export default reducer;
