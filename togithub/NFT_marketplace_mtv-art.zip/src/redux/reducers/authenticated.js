// Authenticated
let initialState = false;

if (localStorage.getItem("wallet")) {
  initialState = true;
}

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case "authenticationStatus":
      return action.payload;
    default:
      return state;
  }
};

export default reducer;
