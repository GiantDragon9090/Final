// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBJ0aNLxI2eDT3xC74eP84BnftjrJ3Yp4M",
  authDomain: "mtv-y-b2d9a.firebaseapp.com",
  projectId: "mtv-y-b2d9a",
  storageBucket: "mtv-y-b2d9a.appspot.com",
  messagingSenderId: "502917785735",
  appId: "1:502917785735:web:d8095bdada678276b67022",
  measurementId: "G-78SPGX3YBR"
};


// Initialize Firebase
const app = initializeApp(firebaseConfig);
const database = getFirestore(app);
export default database;
