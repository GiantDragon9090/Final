import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyBtOE2qogs_zMbObFe_6dgPRZnhVqdEjrA",
  authDomain: "mtv-art-marketplace.firebaseapp.com",
  projectId: "mtv-art-marketplace",
  storageBucket: "mtv-art-marketplace.appspot.com",
  messagingSenderId: "149619709325",
  appId: "1:149619709325:web:0f5825a8ec194836ab19c4",
};

const app = initializeApp(firebaseConfig);
const database = getFirestore(app);

export default database;
