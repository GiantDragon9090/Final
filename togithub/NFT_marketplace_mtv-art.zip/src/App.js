import React from "react";
import { Routes, Route} from "react-router-dom";
// Components
import NavigationBar from "./components/NavigationBar";
import Footer from "./components/Footer";
import Scroller from "./components/Scroller";

// Pages
import Landing from "./pages/Landing";
import Assets from "./pages/Assets";
import Collections from "./pages/Collections";
import Stats from "./pages/Stats";
import Activities from "./pages/Activities";
import Collection from "./pages/Collection";
import Asset from "./pages/Asset";
import List from "./pages/List";
import FixedList from "./pages/FixedList";
import AuctionList from "./pages/AuctionList";
import EditCollection from "./pages/EditCollection";
import Profile from "./pages/Profile";
import ProfileSettings from "./pages/ProfileSettings";
import GetStarted from "./pages/GetStarted";
import ImportCollection from "./pages/ImportCollection";
import CreateCollection from "./pages/CreateCollection";


const App = () => {
  return (
    <React.Fragment>
      {/* <AnnouncementBar /> */}
      <NavigationBar />
      <Scroller />

      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/assets" element = {<Assets/>} />

        <Route path="/collections" element={<Collections />} />
        <Route path="/assets/:collectionURL" element={<Collection />} />
        <Route
          path="/assets/:collectionURL/settings"
          element={<EditCollection />}
        />
        <Route path="/assets/:collectionURL/:tokenID" element={<Asset />} />
        <Route path="/assets/:collectionURL/:tokenID/list" element={<List />} />
        <Route
          path="/assets/:collectionURL/:tokenID/list/fixed"
          element={<FixedList />}
        />
        <Route
          path="/assets/:collectionURL/:tokenID/list/auction"
          element={<AuctionList />}
        />
        <Route path="/stats" element={<Stats />} />
        <Route path="/activities" element={<Activities />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/profile/settings" element={<ProfileSettings />} />
        <Route path="/get-started" element={<GetStarted />} />
        <Route path="/import-collection" element={<ImportCollection />} />
        <Route path="/create-collection" element={<CreateCollection />} />
        
      </Routes>

      <Footer />
    </React.Fragment>
  );
};

export default App;
