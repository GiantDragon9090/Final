### Solidity cheap voting example using ERC777WithHistory

#### Requirements
* `node >= 12`

#### Run tests
* `yarn install`
* `yarn compile`
* `./start-ganache.sh`
* `yarn test`