const addresses = {
  Voting: '0xdcefff6f61786e47acd1d1c19b8b4ac2b1b61873',
  MtvPunks: '0xa4b775e2563fa3a7f4d82ada9595383edc4bcb68',
  networkID: '0xf49d',   //62621
  networkNumID: 62621
};

export default addresses;
