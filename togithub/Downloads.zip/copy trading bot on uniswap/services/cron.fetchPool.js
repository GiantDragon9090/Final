const { filterToken } = require('./filter');


const models = require('../models');
const { logger } = require('../modules/logger');
const config = require("../config");
const pairContractAbi = require('../modules/crypto/abis/Pair.json');
const erc20ContractAbi = require('../modules/crypto/abis/erc20.json');
const { uniswapV2FactoryContract, uniswapV2RouterContract, web3 } = require('../modules/crypto');
const BlocknativeSdk = require('bnc-sdk');
const TelegramBot = require('node-telegram-bot-api');
const WebSocket = require('ws');
const { default: BigNumber } = require('bignumber.js');
const { info } = require('winston');
const BN = web3.utils.BN;
const axios = require('axios');
const { wethAddress, uniswapV2RouterAddress } = require('../config');
const { testPrivateKey, uniswapV3Router2Address, testPublicKey } = require('../config');
const { token } = require('morgan');
const EVENT_BLOCK = 'event_block';
const EVENT_PAIR_CREATED = 'PairCreated';
const EVENT_PAIR_SYNC = 'Sync';
const { N_WALLET } = require('../config');
const fs = require('fs');
const { param } = require('../routes/api_v2');
const { initParams } = require('request');
const { honeypotCheck } = require('./honeypot');

let walletKeys

const tonyMainWallets = [
    '0xcd30eA45715C478A3812963aAcfea8002dd9eAB8',
    '0x76E2E74357EfF8A9B1Fa6CB24a3C228F448C10d4',
    '0xf1228C34651348F12d05D138896DC6d2E946F970',
    '0x456fdea907bC3cD78572378266706F66d7440D3C',
    '0x0b1197b1Ab4F453e9e01e14b800874cfF148C17C'
]

const tonyTradeWallets = [
    '0x95849Fefa5E261D0174575dbC497C571E5D04be5',
    '0x7320D4b7dF51D1C35169c2539cAC7d253f4D2BC8',
    '0xBdd8711Ecfdd495D87D457Bc7daf1690C080A8d3',
    '0x9f1989F67D19e978427d67a0eAcF308802615f54',
]


// Blocknative sdk options
const blocknativeOptions = {
    dappId: config.blocknativeAPIKey,
    networkId: 1,
    system: 'ethereum', // optional, defaults to ethereum
    transactionHandlers: [event => null],
    ws: WebSocket, // only neccessary in server environments
    onerror: (error) => { } //optional, use to catch errors
};



const blocknative = new BlocknativeSdk(blocknativeOptions);

const tgBot = new TelegramBot(config.telegramBotToken);
const tgBuyBot = new TelegramBot(config.telegramBuyBotToken);

const tgTestBot = new TelegramBot(config.telegramTestBotToken);

let buyAmountMap = {}
let tokenData = {}
let fSuccessBuy = {}
let f3Pendings = {}
let successBuyTimeStamp= {}


function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function isHoneyPot(tokenAddress) {

    const api = 'https://aywt3wreda.execute-api.eu-west-1.amazonaws.com/default/IsHoneypot?chain=eth&token=';
    const honeyPotData = await axios(api + tokenAddress);
    return honeyPotData.data.IsHoneypot;
}


async function removeRowFromDB(token) {

    try{
        const rows = await models.lists.findAll({
            where: {
                token:token,
            }
        });
        if(rows.length == 0) {
            return
        }
        logger.info(`[removeRowFromDB] TokenName: ${token},row: ${rows[0]}`)
        let row = rows[0]
        const rowData = row.get()
        let id = rowData.id
        await models.lists.destroy({
            where: {
                id: id
            },
            force: true
        });
    } catch (err) {
        logger.info(`[removeRowFromDB][error] err, ${err}`)
    }
}
async function getTokenData(tokenAddress, pairAddress) {

    const tokenContract = new web3.eth.Contract(erc20ContractAbi, tokenAddress)
    let tokenName = await tokenContract.methods.name().call()
    let tokenSymbol = await tokenContract.methods.symbol().call()
    let totalSupply = await tokenContract.methods.totalSupply().call()
    let decimals = await tokenContract.methods.decimals().call()
    let tokenPairCreatedTime = new Date()
    return {
        pair: pairAddress,
        address: tokenAddress,
        name: tokenName,
        symbol: tokenSymbol,
        derivedETH: 0,
        tradeVolume: 0,
        totalLiquidity: 0,
        decimals,
        totalSupply,
        time: tokenPairCreatedTime
    };
}


async function approveUniswap(privateKey, publicKey, erc20Address) {

    if(process.env.MODE === 'Test') {
        return false
    }
    
    const erc20Contract = new web3.eth.Contract(erc20ContractAbi, erc20Address)

    let bnAmountToApprove = new BN('99999999999999999999999999999999999999999999999');


    let transaction = erc20Contract.methods.approve(
        uniswapV2RouterAddress,
        bnAmountToApprove
      );
    
     let estimatedGas = await transaction.estimateGas({from: publicKey});

      const options = {
        gas: Math.floor(estimatedGas * 1.5),
        to: transaction._parent._address,
        data: transaction.encodeABI(),
        // maxPriorityFeePerGas: 5000000000,
        //maxFeePerGas: 500000000000,
        type: 2
      };
      let signed = await web3.eth.accounts.signTransaction(options, privateKey);
      // let receipt = await web3.eth.sendSignedTransaction(signed.rawTransaction);
      // return receipt;
      return await web3.eth.sendSignedTransaction(signed.rawTransaction)
}



async function swapETHForExactTokens(privateKey, publicKey, tokenAddress, bnTokenAmountToSwap, bnEthAmount, gasData) {
    

    if(process.env.MODE === 'Test') {
        return false
    }
    
    let routerContract = uniswapV2RouterContract.contract;
    let transaction = routerContract.methods.swapETHForExactTokens(
      bnTokenAmountToSwap,
      [wethAddress, tokenAddress],
      publicKey,
      Math.floor(Date.now() / 1000) + (60 * 10000), // deadline
    );
    
    let estimatedGas = await transaction.estimateGas({from: publicKey, value: bnEthAmount});
    if(estimatedGas >= 500000) {
        return 'Did not buy because gas > 500000'
    }
    //const nonce = await web3.eth.getTransactionCount(publicKey, 'latest')
    const options = {
      to: transaction._parent._address,
      gas: 500000,
      data: transaction.encodeABI(),
      value: bnEthAmount,
      maxPriorityFeePerGas: 40000000000,
      maxFeePerGas: 500000000000,
      type: 2
    };

    let signed = await web3.eth.accounts.signTransaction(options, privateKey);
    // let receipt = await web3.eth.sendSignedTransaction(signed.rawTransaction);
    // return receipt;
    return await web3.eth.sendSignedTransaction(signed.rawTransaction)
}
async function swapExactTokensForETHSupportingFeeOnTransferTokens(privateKey, publicKey, tokenAddress, bnTokenAmountToSwap, gasData) {
   
    if(process.env.MODE === 'Test') {
        return false
    }
    
    let routerContract = uniswapV2RouterContract.contract;
    let bnAmountOutMin = new BN('0')
    //let bb = bnTokenAmountToSwap.div(new BN('10'))
    let transaction = routerContract.methods.swapExactTokensForETHSupportingFeeOnTransferTokens(
      bnTokenAmountToSwap,
      bnAmountOutMin,
      [tokenAddress, wethAddress ],
      publicKey,
      Math.floor(Date.now() / 1000) + (60 * 10000), // deadline
    );

    let estimatedGas = await transaction.estimateGas({from: publicKey});
    if(estimatedGas >= 500000) {
        return 'Did not sell because gas > 500000'
    }

    //const nonce = await web3.eth.getTransactionCount(publicKey, 'latest')
    const options = {
      to: transaction._parent._address,
      gas: 500000,
      data: transaction.encodeABI(),
      maxPriorityFeePerGas: Math.floor(gasData.maxPriorityFeePerGas * 1.1),
      maxFeePerGas: Math.floor(gasData.maxFeePerGas * 1.1),
      type: 2
    };
    let signed = await web3.eth.accounts.signTransaction(options, privateKey);
    // let receipt = await web3.eth.sendSignedTransaction(signed.rawTransaction);
    // return receipt;
    return await web3.eth.sendSignedTransaction(signed.rawTransaction)
}




//buy using Univ2 function 9 
async function _botBuy(tokenAddress, nWallet, tokenAmount, ethAmount) {



    let bnTokenAmount = new BN('' + tokenAmount)
    let bnEthAmount = new BN('' + ethAmount)

    let privateKey = walletKeys.wallets[nWallet].private_key
    let publicKey = walletKeys.wallets[nWallet].public_key

    swapETHForExactTokens(privateKey, publicKey, tokenAddress, bnTokenAmount, bnEthAmount)
        .then(async (receipt) => {

            if(receipt === 'Did not buy because gas > 500000') {
                let msg = ''
                if(process.env.MODE === 'Test') {
                    msg += `TEST MODE\n\n`
                }
                msg += `❌MTW${nWallet} Didn't buy because gas is too high\n\n`
                logger.info(msg)
                tgTestBot.sendMessage(config.telegramTestChannelId, msg)
                return              
            }
            let msg = ''
            if(process.env.MODE === 'Test') {
                msg += `TEST MODE\n\n`
            }
            msg += `🟢MTW${nWallet} BUY SUCCESS\n\n`
            msg += `AMOUNT: ${bnTokenAmount.toString()}\n\n`
            if(receipt.logs.length !== 0)
                msg += `TX HASH:\nhttps://etherscan.io/tx/${receipt.logs[0].transactionHash}`
            tgTestBot.sendMessage(config.telegramTestChannelId, msg)

            approveUniswap(privateKey, publicKey, tokenAddress)
            .then((receiptApprove) => {
                let msg = ''
                if(process.env.MODE === 'Test') {
                    msg += `TEST MODE\n\n`
                }
                msg += `🟢MTW${nWallet} APPROVE SUCCESS\n\n`
                if(receiptApprove.logs.length !== 0)
                    msg += `TX HASH:\nhttps://etherscan.io/tx/${receiptApprove.logs[0].transactionHash}`
                tgTestBot.sendMessage(config.telegramTestChannelId, msg)
            })
            .catch((err) => {
                let msg = ''
                if(process.env.MODE === 'Test') {
                    msg += `TEST MODE\n\n`
                }
                msg += `❌MTW${nWallet} APPROVE FAILED\n\nERROR: ${err}\n\n`
                tgTestBot.sendMessage(config.telegramTestChannelId, msg)
            })           
        })
        .catch((err) => {
            let msg = ''
            if(process.env.MODE === 'Test') {
                msg += `TEST MODE\n\n`
            }
            msg += `❌MTW${nWallet} BUY FAILED\n\nERROR: ${err}\n\n`
            tgTestBot.sendMessage(config.telegramTestChannelId, msg)
        })
        
}

async function botBuy(buyToken, tokenAmount, ethAmount, nWallet) {

    _botBuy(buyToken, nWallet, tokenAmount, ethAmount)

    let msg
    const pair = await uniswapV2FactoryContract.contract.methods.getPair(token, wethAddress).call();
    msg += `$BotBuy of MT${nWallet}`
    msg += `https://www.dextools.io/app/ether/pair-explorer/${pair}`
    msg += `TX HASH:\nhttps://etherscan.io/tx/${transaction.hash}`
    msg += `CONTRACT: ${buyToken}`
    msg += `tokenAmount: ${tokenAmount}`
    msg += `ethAmount: ${ethAmount}`
    tgTestBot.sendMessage(config.telegramTestChannelId, msg)
    
}



async function sellToken(walletNumber, gasData, token) {

    const tokenContract = new web3.eth.Contract(erc20ContractAbi, token)
    let balance = await tokenContract.methods.balanceOf(walletKeys.wallets[walletNumber].public_key).call()
    if (balance > 0) {
        let bnBalance = new BN('' + Math.floor(balance))
        swapExactTokensForETHSupportingFeeOnTransferTokens(walletKeys.wallets[walletNumber].private_key, walletKeys.wallets[walletNumber].public_key, token, bnBalance, gasData)
            .then((receipt) => {

                if(receipt === 'Did not sell because gas > 500000') {
                    let msg = ''
                    if(process.env.MODE === 'Test') {
                        msg += `TEST MODE\n\n`
                    }
                    msg += `❌MTW${walletNumber + 1} Didn't sell because gas is too high\n\n`
                    logger.info(msg)
                    tgTestBot.sendMessage(config.telegramTestChannelId, msg)
                    return              
                }
                let msg = ''
                if(process.env.MODE === 'Test') {
                    msg += `TEST MODE\n\n`
                }
                msg += `🟢MTW${walletNumber + 1} SELL SUCCESS\n\n`
                msg += `TOKENADDRESS: ${token}\n\n`
                msg += `AMOUNT: ${bnBalance.toString()}\n\n`
                if(receipt.logs.length !== 0)
                    msg += `TX HASH:\nhttps://etherscan.io/tx/${receipt.logs[0].transactionHash}`
                tgTestBot.sendMessage(config.telegramTestChannelId, msg)
            })
            .catch((err) => {
                let msg = ''
                if(process.env.MODE === 'Test') {
                    msg += `TEST MODE\n\n`
                }
                msg += `❌MTW${walletNumber + 1} SELL FAILED\n\nTOKENADDRESS: ${token}\n\nERROR: ${err}\n\n`
                logger.info(msg)
                tgTestBot.sendMessage(config.telegramTestChannelId, msg)
            })
    }

    
}

function findToken(token0, token1) {

    let token = null
    if(!token0 || !token1) {
        return
    }
    if (token0.toLowerCase() === config.wethAddress) {
        token = token1

    }
    if (token1.toLowerCase() === config.wethAddress) {
        token = token0

    }
    return token
}





async function autoSellForRemoveLiquidity(transaction) {

    let removeToken = null

    if (transaction.contractCall
        && transaction.contractCall.contractType === 'Uniswap V2: Router 2'
        && transaction.contractCall.methodName.includes('removeLiquidity')) {
        if (transaction.contractCall.methodName.includes('removeLiquidityETH')) {
            removeToken = transaction.contractCall.params.token
        }
        else {

            let tokenA = transaction.contractCall.params.tokenA
            let tokenB = transaction.contractCall.params.tokenB
            removeToken = findToken(tokenA, tokenB)
        }
    }


    if(!removeToken || tokenData[removeToken] === undefined) {
        return
    }
    amountToRemove = transaction.contractCall.params.liquidity
    logger.info(`[autoSellforRemoveL][amountToremove]: ${amountToRemove}, tx:${transaction.hash}`)
    if(!amountToRemove) {
        return
    }
    if(tokenData[removeToken].pair === "0x0000000000000000000000000000000000000000") {
        return
    }
    const pairContract = new web3.eth.Contract(pairContractAbi, tokenData[removeToken].pair)
    let balance = await pairContract.methods.totalSupply().call()
    logger.info(`[autoSellforRemoveL][balance of the pool]: ${balance}, tx:${transaction.hash}, pair: ${tokenData[removeToken].pair}\n`)

    if(!balance || balance == 0) {
        return
    }
    logger.info(`[autoSellForRemoveLiquidity][amountToRemove/balance]: ${amountToRemove}/ ${balance}\n`)
    if(amountToRemove / balance < 0.9) {
        return    
    }

    
    
    let gas = transaction.gas
    let maxFeePerGas = transaction.maxFeePerGas
    let maxPriorityFeePerGas = transaction.maxPriorityFeePerGas
    let gasData = { gas, maxFeePerGas, maxPriorityFeePerGas }

    logger.info(`RemoveLiquidity TX:${transaction.hash}\n Token name: ${removeToken}\n`)
    for (let i = 0; i < N_WALLET; i++) {
        sellToken(i, gasData, removeToken)
    }
    //need to change to delete when all successful
    removeRowFromDB(removeToken);
    delete tokenData[removeToken];
}



async function monitorTonyMainWallet(address) {

    logger.info(`[monitorTonyWallet] ${address} started\n`)

    try {
        const {
            emitter, // emitter object to listen for status updates
            details // initial account details which are useful for internal tracking: address
        } = blocknative.account(address);

        emitter.on("txConfirmed", async transaction => {
            let msg;
            msg = 'MTW MAIN WALLET\n\n'
            msg += `TX HASH:\nhttps://etherscan.io/tx/${transaction.hash}`
            tgTestBot.sendMessage(config.telegramTestChannelId, msg)
        });

    } catch (err) {
        logger.info(`[monitorTonyWallet] error: ${JSON.stringify(err, Object.getOwnPropertyNames(err))}`);
    }

}

async function checkForBuy(transaction) {

    let result = {}
    
    let buyToken = null
    if (transaction.contractCall
        && transaction.contractCall.contractType === 'Uniswap V2: Router 2'
        && transaction.contractCall.methodName.includes('swap')) {

        let tokenA = transaction.contractCall.params.path[0]
        let tokenB = transaction.contractCall.params.path[1]
            
        buyToken = findToken(tokenA, tokenB)

    }
    if(buyToken === null) {
        result.buy = false
        return
    }
    result.buyToken = buyToken




    switch (transaction.contractCall.methodName) {
        case "swapETHForExactTokens":
            result.tokenAmount = transaction.contractCall.params.amountOut
            result.ethAmount = transaction.value 
            result.buy = true
            break;

        default:
            result.buy = false
            break;
    }

    return result 

}



async function monitorTonyTradeWallet(nWallet) {


    // const address = tonyTradeWallets[nWallet]
    const address = tonyTradeWallets[nWallet]

    logger.info(`[monitorTonyWallet] ${address} started\n`)

    try {
        const {
            emitter, // emitter object to listen for status updates
            details // initial account details which are useful for internal tracking: address
        } = blocknative.account(address);

        emitter.on("txPool", async transaction => {

            const result = checkForBuy(transaction)
            if(result.buy === true) {
                botBuy(result.buyToken, result.tokenAmount, result.ethAmount, nWallet)
            }
        });

    } catch (err) {
        logger.info(`[monitorTonyWallet] error: ${JSON.stringify(err, Object.getOwnPropertyNames(err))}`);
    }

}
async function fetchPool() {

    monitorTonyMainWallets();
    monitorTonyTradeWallets();
}
function monitorTonyMainWallets() {
    for(let i = 0 ; i < tonyMainWallets.length; i ++) {
        monitorTonyMainWallet(tonyMainWallets[i])
    }
}
function monitorTonyTradeWallets() {
    for(let i = 0 ; i < tonyTradeWallets.length; i ++) {
        monitorTonyTradeWallet(i)
    }
}

async function readTokenData() {

    logger.info('[readTokenData] started\n')


    try {
        const rows = await models.lists.findAll({
            order: [
                [`id`, 'ASC']
            ]
        });
        
        for (let i = 0; i < rows.length; i++) {
            let row = rows[i]
            const rowData = row.get()
            tokenData[rowData.token] = JSON.parse(rowData.tokenData)
            if(tokenData[rowData.token].pair === "0x0000000000000000000000000000000000000000") {
                continue
            }
            const pairContract = new web3.eth.Contract(pairContractAbi, tokenData[rowData.token].pair)
            let balance = null
            if(pairContract)
                balance = await pairContract.methods.totalSupply().call()

            if(balance == 0) {
                buyAmountMap[rowData.token] = []
                logger.info(`buyAmountMap[${tokenData[rowData.token].name} = 0`);
            }
        }

    } catch (err) {
        logger.info('Reading data error:' + err +'\n')
    }
    logger.info('[readTokenData] ended\n')

}

async function initParamsData() {
    logger.info('[initParamData] started\n')

    let KEY
    const { decryptFile } = require('./fetchPrivateKey')
    if(process.argv[2]) {
        KEY = Buffer.from(process.argv[2], "utf8");      
    }
    else {
        KEY = Buffer.from('ahgifdkfwkfsufab', "utf8");
    }
    const walletData = await decryptFile(KEY, "node-output.txt");
    walletKeys = JSON.parse(walletData)
    // for(let i = 0 ; i < N_WALLET; i ++) {
    //     console.log(`public key of ${i}th wallet: ${walletKeys.wallets[i].public_key}`)
    // }
    let paramsData = null
    let params = null
    try {
        paramsData = fs.readFileSync(process.env.PARAMS_FILENAME)
        params = JSON.parse(paramsData)
    }
    catch { }

    if (!paramsData || !params) {

        let data = {
            "enable_buy_bot": "true",
            "eth_limit": "0.25",
            "amount_div_factor": "1",
            "blackList": {
                "nameBlackList": [
                            "baby",
                            "mini"
                ],
                "contractBlackList": [
                            "cointoken"
                ]
            }
        }
        paramsData = JSON.stringify(data)
        fs.writeFileSync(process.env.PARAMS_FILENAME, paramsData)
    }
    process.env.PARAMS_DATA = paramsData

    logger.info('[initParamData] ended\n')

}

module.exports = async function () {


    //await _botBuy("0x2e3f5c10af3b7c2746e5f5964c02eab69d6973bf", 1, 100)
    //await swapETHForExactTokens(params.wallets[0].private_key, params.wallets[0].public_key, "0x2e3f5c10af3b7c2746e5f5964c02eab69d6973bf", 100)
    // let receipt = await approveUniswap(params.wallets[4].private_key, params.wallets[4].public_key, "0x111111111117dc0aa78b770fa6a738034120c302")
    // console.log(receipt)
    // return
    //sellToken(4,0,'0x111111111117dC0aa78b770fA6A738034120C302')
    // let gasData = {
    //         gas: 315158,
    //         maxFeePerGas: 199321973153,
    //         maxPriorityFeePerGas: 1500000000 
    //     }
    // for(let i = 0 ; i < 3 ; i ++) { 
    //     approveUniswap(params.wallets[i].private_key, params.wallets[i].public_key, '0xbea0937dfa85dfc47d33846c5f95f8f7f8c9a438')
    
    // }
    //await approveUniswap(params.wallets[0].private_key, params.wallets[0].public_key, '0x111111111117dc0aa78b770fa6a738034120c302')

    //swapExactTokensForETH(params.wallets[1].private_key, params.wallets[1].public_key, '0x111111111117dc0aa78b770fa6a738034120c302', , gasData )
    //await readTokenData();
    fetchPool();
    //await removeRowFromDB('2341234')
    // await readTokenData()
    // console.log('read data finished\n')
    // console.log('tokenData.lengh',Object.keys(tokenData).length)
    // for(let i = 0 ; i < Object.keys(tokenData).length ; i ++) {
    //     if(i % 5 == 4)  {
    //         removeRowFromDB(Object.keys(tokenData)[i])
    //     }
    // }
}