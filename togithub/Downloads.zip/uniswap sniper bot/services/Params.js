class Params {

 
  }
  
  module.exports = Utils