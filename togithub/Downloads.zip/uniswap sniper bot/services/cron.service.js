const cronFetchPool = require('./cron.fetchPool');

module.exports = function () {
  cronFetchPool();
};
