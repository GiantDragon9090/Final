const defaults = require('./default.js');

module.exports = defaults;
