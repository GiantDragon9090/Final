from bxcommon.rpc.provider.cloud_wss_provider import CloudWssProvider
from bxcommon.rpc.provider.abstract_ws_provider import WsException
from bxcommon.rpc.provider.ws_provider import WsProvider
from bxcommon.rpc.rpc_request_type import RpcRequestType
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from web3 import Web3

import websockets
import threading
import traceback
import asyncio
import time
import json
import sys

async def sniper(config, bot_info, headers, nonce, web3, idx, transaction):

    method_claim = "0x6ba4c138"

    async with WsProvider(
        uri=config['uri'],
        headers=headers,
        skip_ssl_cert_verify=True,
        retry_connection=True,
    ) as cloud_ws:

        subscription_id = await cloud_ws.subscribe( "newTxs", 
                                                        {
                                                            "include": ["tx_contents"],
                                                            "filters": f"from = {bot_info['monitoring_address']} and to = 0x18B2A687610328590Bc8F2e5fEdDe3b582A49cdA",
                                                            "blockchain_network": "BSC-Mainnet"
                                                        }
                                                    )


        # Listen for txs forevr
        while True:
            
            async with WsProvider(
                                    uri="wss://api.blxrbdn.com/ws",
                                    headers=headers,
                                    skip_ssl_cert_verify=True,
                                    retry_connection=True,
                                ) as ws:
                
                txn = await cloud_ws.get_next_subscription_notification_by_id(subscription_id)


                val = int(txn.notification['txContents']['value'], 16)
                txn_input = txn.notification['txContents']['input']

                tx = transaction.copy()
                
                if not method_claim in txn_input:
                    tx.update({ 'nonce' : nonce['nonce'], 'value' : int(val*config['amount_ratio']), 'data' : txn_input})
                    # tx.update({ 'nonce' : nonce['nonce'], 'data' : txn_input})
                else:
                    tx.update({ 'nonce' : nonce['nonce'], 'value' : 0, 'data' : txn_input})                
                
                signed_tx = web3.eth.account.sign_transaction(tx, bot_info['secret_key'])
                
                comp_txn = await ws.call_bx(   RpcRequestType.BLXR_TX, 
                                                {
                                                    "transaction": signed_tx.rawTransaction.hex()[2:], 
                                                    "blockchain_network": "BSC-Mainnet"
                                                }
                                            )
                nonce['nonce'] += 1

def start_sniping(config, bot_info, idx):
    config = json.loads(config)
    bot_info = json.loads(bot_info)
    idx = int(idx)


    # Important variables
    headers = {"Authorization": "NDgzYzBhN2QtMjYxYy00NDVlLWEwZjItZjU4NDExMTc5ZDcyOjNjMjU4Mzk2NTg4ZDFkM2Y5YzI2ZjlhOTZkNzU2ZGRh"}
    web3 = Web3(Web3.WebsocketProvider("wss://floral-divine-dawn.bsc.quiknode.pro/542c7aad8648bdd6bf5c1a30ed759bf13421cf5f/"))
    nonce = {"nonce": web3.eth.getTransactionCount(bot_info['from_address'])}

    transaction =   {
                        "chainId": 56,
                        "nonce": 0,
                        "value": 1000000000000000,
                        "gas": 200000,
                        "gasPrice": 5500000000,
                        "to": "0x18B2A687610328590Bc8F2e5fEdDe3b582A49cdA",
                        "data": ''
                    }

    # Start async in loop
    while True:
        try:
            asyncio.run(sniper(config, bot_info, headers, nonce, web3, idx, transaction))
        except Exception as e:

            # Log error
            with open(f"logfile{idx}.log", 'a') as log:
                now = datetime.now()
                log.write(now.strftime("%m/%d/%Y, %H:%M:%S") + "\tException!\n")
                log.write(traceback.format_exc())
                log.write("\n\n")


start_sniping(sys.argv[1], sys.argv[2], sys.argv[3])