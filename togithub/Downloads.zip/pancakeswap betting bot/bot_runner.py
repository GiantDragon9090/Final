import os
import sys
import time
import json
import signal
import subprocess

from shlex import split as splitsh


### Get Config files
with open("config_runner.json") as fp:
    config = json.load(fp)

timeout = config['reset_timer'] * 60

while True:
    procs = list()

    for idx, bot_info in enumerate(config['bot_info']):
        cmd = ["python", "pred_bot.py", json.dumps(config), json.dumps(bot_info), str(idx+1)]
        procs.append(subprocess.Popen(cmd))
    
    try:
        time.sleep(timeout)
    except KeyboardInterrupt:
        try:
            for proc in procs:
                proc.terminate()
            sys.exit()
        except OSError:
            pass
 
    for proc in procs:
        proc.kill()
    
