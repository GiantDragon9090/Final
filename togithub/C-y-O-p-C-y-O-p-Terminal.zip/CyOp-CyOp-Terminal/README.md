For installing the project:
yarn install

For running the project:
yarn start

