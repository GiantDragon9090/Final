import ExchangeLeftPanel from "components/exchange-left-panel"
import ExchangePriceChart from "components/exchange-price-chart"

export const ExchangePage = () => {

	return (
		<div className="d-flex h-100 overflow-hidden">
			<div className="co-inner-left-panel d-flex flex-column">
				<ExchangeLeftPanel />
			</div>

			<div className="co-inner-right-panel d-flex flex-column">
				<div className="co-main-content flex-1">
					<ExchangePriceChart />
				</div>
			</div>
		</div>
	)
}

export default ExchangePage