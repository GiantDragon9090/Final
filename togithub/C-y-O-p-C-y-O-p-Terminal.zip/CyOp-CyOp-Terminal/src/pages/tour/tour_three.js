import { useState, useEffect } from 'react';
import { useNavigate } from "react-router-dom";
import TourArrow from 'components/tour-arrow';
import YouTube from 'react-youtube';
import useTyped from 'hooks/typed';
import { WindowMode, VideoMode } from 'components/tour-view';

export const TourPageThree = () => {
	const [enableVid, setVid] = useState(false);
	const [vidHeight, setVidHeight] = useState('264');
	const navigate = useNavigate();

	useEffect(() => {
		const width = window.screen.width;
		if(width < 992)
			setVidHeight((width / 16 * 9).toString());
	}, []);
	const onCompleteJourney = () => {
		setVid(true);
	}
	const [greetingTxt, greetingCompleted] = useTyped({
		text: "Join the CyOp Syndicate.",
		start: true,
		speed: 20,
	})
	const [contentTxt, contentCompleted] = useTyped({
		text: "A dedicated fellowship of punks committed to a mission and helping you on this unique ",
		start: greetingCompleted,
		speed: 20,
		endDelay: 0
	})
	const [journeyTxt, journeyCompleted] = useTyped({
		text: "journey to reward yielding disruption.",
		start: contentCompleted,
		onComplete: onCompleteJourney,
		speed: 20,
	})

	return (
		<WindowMode>
			<div className="mb-2">
				<span className="text-danger">{greetingTxt}</span>
				{!greetingCompleted &&
					<span className="typed-cursor danger text-danger">|</span>
				}
			</div>
			<div className="mb-2">
				<span>{contentTxt}</span>
				{(!contentCompleted && greetingCompleted) &&
					<span className="typed-cursor danger">|</span>
				}
				<span className="text-danger">{journeyTxt}</span>
				{(!journeyCompleted && contentCompleted) &&
					<span className="typed-cursor danger text-danger">|</span>
				}
			</div>

			{enableVid &&
				<>
					<div className="co-tour-button mb-2" onClick={ () => navigate("/database") }>
						<TourArrow label={"enter terminal"}/>
					</div>
					<VideoMode>
						<YouTube
							videoId="e6jff1pK3Eg"
							opts={{
								height: vidHeight,
								width: "100%",
								playerVars: {
									autoplay: 0,
									controls: 0
								}
							}}
						/>
					</VideoMode>
				</>
			}
		</WindowMode>
	)
}

export default TourPageThree