import { useState, useEffect } from 'react';
import { useNavigate } from "react-router-dom";
import TourArrow from 'components/tour-arrow';
import YouTube from 'react-youtube';
import useTyped from 'hooks/typed';
import { WindowMode, VideoMode } from 'components/tour-view';

export const TourPageOne = () => {
	const [enableVid, setVid] = useState(false);
	const [vidHeight, setVidHeight] = useState('264');
	const navigate = useNavigate();

	useEffect(() => {
		const width = window.screen.width;
		if(width < 992){
			setVidHeight((width / 16 * 9).toString());
		}
	}, []);
	const onCompleteJoin = () => {
		setVid(true);
	}
	const [greetingTxt, greetingCompleted] = useTyped({
		text: "Back to the roots of Crypto with the CyOp Protocol.",
		start: true,
		speed: 20,
	})
	const [contentTxt, contentCompleted] = useTyped({
		text: "Governed by the community it constantly triggers a massive buying frenzy on any given ERC-20 token.",
		start: greetingCompleted,
		speed: 20,
	})
	const [generateTxt, generateCompleted] = useTyped({
		text: "These disruptions generate passive income and big $ETH rewards for all members...",
		start: contentCompleted,
		speed: 20,
		endDelay: 0
	})
	const [joinTxt, joinCompleted] = useTyped({
		text: " join the revolution",
		start: generateCompleted,
		onComplete: onCompleteJoin,
		speed: 20
	})

	return (
		<WindowMode>
			<div className="mb-2">
				<span className="text-danger">{greetingTxt}</span>
				{!greetingCompleted &&
					<span className="typed-cursor danger text-danger">|</span>
				}
			</div>
			<div className="mb-2">
				<span>{contentTxt}</span>
				{(!contentCompleted && greetingCompleted) &&
					<span className="typed-cursor danger">|</span>
				}
			</div>
			<div className="mb-2">
				<span>{generateTxt}</span>
				{(!generateCompleted && contentCompleted) &&
					<span className="typed-cursor danger">|</span>
				}
				<span className="text-danger">{joinTxt}</span>
				{(!joinCompleted && generateCompleted) &&
					<span className="typed-cursor danger text-danger">|</span>
				}
			</div>

			{enableVid &&
				<>
					<div className="co-tour-button mb-2" onClick={ () => navigate("/tour_two") }>
						<TourArrow label={"next"} />
					</div>
					<VideoMode>
						<YouTube
							videoId="YyEkGg-I6p0"
							opts={{
								height: vidHeight,
								width: "100%",
								playerVars: {
									autoplay: 0,
									controls: 0
								}
							}}
						/>
					</VideoMode>
				</>
			}
		</WindowMode>
	)
}

export default TourPageOne