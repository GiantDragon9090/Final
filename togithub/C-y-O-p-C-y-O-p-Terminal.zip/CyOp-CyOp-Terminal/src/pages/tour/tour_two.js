import { useState, useEffect } from 'react';
import { useNavigate } from "react-router-dom";
import TourArrow from 'components/tour-arrow';
import YouTube from 'react-youtube';
import useTyped from 'hooks/typed';
import { WindowMode, VideoMode } from 'components/tour-view';

export const TourPageTwo = () => {
	const [enableVid, setVid] = useState(false);
	const [vidHeight, setVidHeight] = useState('264');
	const navigate = useNavigate();

	useEffect(() => {
		const width = window.screen.width;
		if(width < 992)
			setVidHeight((width / 16 * 9).toString());
	}, []);
	const onCompleteHacker = () => {
		setVid(true);
	}
	const [greetingTxt, greetingCompleted] = useTyped({
		text: "To become part of the community disruption,",
		start: true,
		speed: 20,
	})
	const [contentTxt, contentCompleted] = useTyped({
		text: "CyOp holders will need to stake their tokens and vote for their favorite projects using the ",
		start: greetingCompleted,
		speed: 20,
		endDelay: 0
	})
	const [hackerTxt, hackerCompleted] = useTyped({
		text: "hacker-inspired blockchain terminal.",
		start: contentCompleted,
		onComplete: onCompleteHacker,
		speed: 20,
	})

	return (
		<WindowMode>
			<div className="mb-2">
				<span className="text-danger">{greetingTxt}</span>
				{!greetingCompleted &&
					<span className="typed-cursor danger text-danger">|</span>
				}
			</div>
			<div className="mb-2">
				<span>{contentTxt}</span>
				{(!contentCompleted && greetingCompleted) &&
					<span className="typed-cursor danger">|</span>
				}
				<span className="text-danger">{hackerTxt}</span>
				{(!hackerCompleted && contentCompleted) &&
					<span className="typed-cursor danger text-danger">|</span>
				}
			</div>

			{enableVid &&
				<>
					<div className="co-tour-button mb-2" onClick={ () => navigate("/tour_three") }>
						<TourArrow label={"next"} />
					</div>
					<VideoMode>
						<YouTube
							videoId="36AI8apgUOM"
							opts={{
								height: vidHeight,
								width: "100%",
								playerVars: {
									autoplay: 0,
									controls: 0
								}
							}}
						/>
					</VideoMode>
				</>
			}
		</WindowMode>
	)
}

export default TourPageTwo