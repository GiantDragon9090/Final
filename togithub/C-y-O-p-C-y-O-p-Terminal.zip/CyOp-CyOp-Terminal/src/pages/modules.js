import { /*useRef,*/ useState } from 'react';
import useTyped from 'hooks/typed';

// import nftVideo from "assets/video/NFT.mp4";

export const Modules = () => {
  const [videoReady, setVideoReady] = useState(false);
  // const videoRef = useRef();

  const onCompleteLoading = () => {
    setVideoReady(true);
  };

  const [textLoading, loadingCompleted] = useTyped({
    text: 'loading uNFT module...',
    start: true,
    speed: 30,
    onComplete: onCompleteLoading,
  });

  // const onClickVideo = () => {
  //   videoRef.current.muted = false;
  //   videoRef.current.play();

  //   let timer = setInterval(function () {
  //     if (!videoRef.current) return;

  //     if (Math.abs(videoRef.current.currentTime - 6) < 0.2) {
  //       videoRef.current.pause();
  //       clearInterval(timer);
  //       return;
  //     }
  //   }, 500);
  // };

  return (
    <>
      <div className="mb-2 ps-2">
        <span>{textLoading}</span>
        {!loadingCompleted && <span className="typed-cursor danger">|</span>}
      </div>
      {videoReady && (
        <div
          style={{
            height: 'calc(100% - 70px)',
            width: '100%',
            textAlign: 'center',
          }}
        >
          {/* <video ref={videoRef} src={nftVideo} style={{ height: "100%", width: "100%" }} muted playsInline controlsList="nodownload noplaybackrate" className="pointer" onClick={onClickVideo}>
					</video> */}

          <iframe
            style={{ height: '100%', width: '100%' }}
            className="pointer"
            src={`https://www.youtube.com/embed/onZmKwlsquM`}
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            title="Embedded youtube"
          />
        </div>
      )}
    </>
  );
};

export default Modules;
