export const LoadingPage = () => {
  return (
    <div className="full-screen text-center p-3 d-flex flex-column justify-content-center align-items-center">
      loading...
    </div>
  );
};

export default LoadingPage;
