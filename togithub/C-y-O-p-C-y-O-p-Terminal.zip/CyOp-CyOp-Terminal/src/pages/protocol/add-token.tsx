
import { useState, useEffect } from "react"
import { BigNumber, ethers } from 'ethers'
import useTyped from "hooks/typed"
import { useAudio } from "react-awesome-audio"
import useContracts from 'shared/hooks/useContracts'
import { useWeb3 } from "shared/hooks";
import addresses from "shared/addresses";
import TextInputing from "components/text-input"

const sndAction = require('assets/audio/action.mp3').default

export const AddToken = (props: any) => {
    const {
        chainId,
        switchNetwork
    } = useWeb3()

    useEffect(() => {
        if (chainId !== addresses.arbitrumNetworkID) {
            switchNetwork(addresses.arbitrumNetworkID);
        }
    }, [chainId, switchNetwork]);
    const {
        approve,
        allowance,
    } = useContracts();

    const [enterNameCompleted, setNameCompleted] = useState(false)
    const [enterContractCompleted, setContractCompleted] = useState(false)
    const [enterPairCompleted, setPairCompleted] = useState(false)
    const [enterSlipCompleted, setSlipCompleted] = useState(false)
    const [enterDescriptionCompleted, setDescriptionCompleted] = useState(false)
    const [enterRejected, setRejected] = useState(false)

    const [tokenName, setTokenName] = useState("")
    const [amount] = useState('1000000000000000000')
    const [contractAddress, setContractAddress] = useState("")
    const [pairAddress, setPairAddress] = useState("")
    const [slippage, setSlippage] = useState("")
    const [description, setDescription] = useState("")


    const [approved, setApproved] = useState(false);
    const [checkingApproval, setCheckingApproval] = useState(true);


    const [processing, setProcessing] = useState(false)

    const { play } = useAudio({
        src: sndAction,
    });
    const { walletAddress } = useWeb3();
    const { createProposal } = useContracts()

    const isValidContractAddress = ((value: string) => {
        if (!value) {
            return false
        }
        return ethers.utils.isAddress(value)
    })


    useEffect(() => {
        (async () => {
            // check approval
            if (allowance && walletAddress) {
                try {
                    setCheckingApproval(true);
                    const approvalAmount = await allowance(
                        walletAddress,
                        addresses.arbitrumDAO
                    );
                    if (approvalAmount !== null) {
                        if (approvalAmount.gt('0')) {
                            setApproved(true);
                            return;
                        }
                    }
                } catch (e) {
                    // TODO handle errors
                    console.log(e);
                } finally {
                    setCheckingApproval(false);
                }
            }
        })();
    }, [allowance, walletAddress]);


    const isValidNumber = ((value: string) => {
        if (!value)
            return false
        // return !isNaN(Number(value)) &&
        //     parseInt(value) == Number(value) &&
        //     !isNaN(parseInt(value, 10))
        if (isNaN(Number(value)))
            return false
        return true
    })

    const isValidTokenName = ((value: string) => {
        if (!value)
            return false
        return ethers.utils.isValidName(value)
    })

    const isValidText = ((value: string) => {
        return true
    })


    const onClickApprove = async () => {
        setProcessing(true);
        play();
        // try approve
        if (approve) {
            try {
                const approved = await approve(
                    addresses.arbitrumDAO,
                    ethers.constants.MaxUint256
                );
                if (approved) {
                    setApproved(true);
                    setProcessing(false);
                }
            } catch (e) {
                setApproved(false);
                setProcessing(false);
            }
        }
    };


    const onClickSubmit = () => {

        play()

        setProcessing(true)

        if (createProposal) {
            let slippageBN = BigNumber.from(slippage)
            createProposal(
                contractAddress,
                pairAddress,
                slippageBN,
                description,
                tokenName,
                amount
            )

                .then((result) => {

                    setProcessing(false)
                    if (result) {
                        // redirect to active event page
                        if (props.setAddToken) {
                            console.log("props.setAddToken")
                            props.setAddToken(false)
                        }
                    }
                })
        }
        console.log(contractAddress,
            pairAddress,
            slippage,
            description,
            tokenName,
            amount)
    }

    const [textConnected, connectCompleted] = useTyped({
        text: "Listing a new token on the Protocol costs 1,000,000,000 CyOp",
        start: true,
        speed: 30
    })

    const [textName, nameCompleted] = useTyped({
        text: "Enter token ticker",
        start: connectCompleted,
        speed: 30
    })

    const [textContract, contractCompleted] = useTyped({
        text: "Enter token contract address",
        start: enterNameCompleted,
        speed: 30
    })

    const [textPair, pairCompleted] = useTyped({
        text: "Enter pair address",
        start: enterContractCompleted,
        speed: 30
    })

    const [textSlippage, slippageCompleted] = useTyped({
        text: "Enter slippage (only whole numbers)",
        start: enterPairCompleted,
        speed: 30
    })

    const [textDescription, descriptionCompleted] = useTyped({
        text: "Enter short description (140 characters)",
        start: enterSlipCompleted,
        speed: 30
    })

    return (
        <>
            <div className="co-left-panel">
                <div className="mb-2">
                    <span>{textConnected}</span>
                    {!connectCompleted &&
                        <span className="typed-cursor danger">▌</span>
                    }
                </div>
                <div className="mb-2">
                    <span>{textName}</span>
                    {(connectCompleted && !nameCompleted) &&
                        <span className="typed-cursor danger">▌</span>
                    }
                </div>
                <div className="mb-2 text-inputting">
                    {nameCompleted &&
                        <TextInputing
                            setCompleted={setNameCompleted}
                            setRejected={setRejected}
                            setValue={setTokenName}
                            validation={isValidTokenName} />
                    }
                </div>
                <div className="mb-2">
                    <span>{textContract}</span>
                    {(enterNameCompleted && !contractCompleted) &&
                        <span className="typed-cursor danger">▌</span>
                    }
                </div>
                <div className="mb-2 text-inputting">
                    {contractCompleted &&
                        <TextInputing
                            setCompleted={setContractCompleted}
                            setRejected={setRejected}
                            setValue={setContractAddress}
                            validation={isValidContractAddress} />
                    }
                </div>
                <div className="mb-2">
                    <span>{textPair}</span>
                    {(enterContractCompleted && !pairCompleted) &&
                        <span className="typed-cursor danger">▌</span>
                    }
                </div>
                <div className="mb-2">
                    {pairCompleted &&
                        <TextInputing
                            setCompleted={setPairCompleted}
                            setRejected={setRejected}
                            setValue={setPairAddress}
                            validation={isValidContractAddress} />
                    }
                </div>
                <div className="mb-2">
                    <span>{textSlippage}</span>
                    {(enterPairCompleted && !slippageCompleted) &&
                        <span className="typed-cursor danger">▌</span>
                    }
                </div>
                <div className="mb-2">
                    {slippageCompleted &&
                        <TextInputing
                            setCompleted={setSlipCompleted}
                            setRejected={setRejected}
                            setValue={setSlippage}
                            validation={isValidNumber} />
                    }
                </div>
                <div className="mb-2">
                    <span>{textDescription}</span>
                    {(enterSlipCompleted && !descriptionCompleted) &&
                        <span className="typed-cursor danger">▌</span>
                    }
                </div>
                <div className="mb-2">
                    {descriptionCompleted &&
                        <TextInputing
                            setCompleted={setDescriptionCompleted}
                            setRejected={setRejected}
                            setValue={setDescription}
                            validation={isValidText} />
                    }
                </div>
                <div></div>

                {processing &&
                    <div className="button-label" style={{ width: "200px", opacity: "0.5" }} >
                        <i className="fa fa-repeat fa-spin" aria-hidden="true" style={{ fontSize: "15px" }}></i>&nbsp;processing</div>
                }

                {!processing && !approved && enterDescriptionCompleted && (
                    <div className="button-label" onClick={onClickApprove}>
                        {checkingApproval ? (
                            <>
                                <i
                                    className="fa fa-repeat fa-spin"
                                    aria-hidden="true"
                                    style={{ fontSize: '15px' }}
                                ></i>
                                &nbsp;checking approval
                            </>
                        ) : (
                            'approve'
                        )}
                    </div>
                )}


                {(!processing && !enterRejected && enterDescriptionCompleted && approved) &&
                    <div className="d-flex flex-row">
                        <div className="button-label" style={{ width: "100px" }} onClick={onClickSubmit}>submit</div>
                    </div>
                }




                {(!processing && enterRejected) &&
                    <div className="d-flex flex-row">
                        <div className="button-label" style={{ width: "200px", background: "#FF00A0" }}>Invalid input</div>
                    </div>
                }
            </div>
        </>
    )
}

export default AddToken