import { useState } from 'react';
// import { useWeb3, useHasCyopBalance } from 'shared/hooks';
import PreviousPanel from 'components/previous-panel';
import useTyped from 'hooks/typed';

export const PreviousEvent = () => {
  // const { chainId, walletAddress } = useWeb3();
  // const hasCyopBalance = useHasCyopBalance(walletAddress!, chainId!);
  const hasCyopBalance = true;
  const [textLeft, islefttextCompleted] = useTyped({
    text: 'All of this has happened before.',
    start: true,
    speed: 30,
  });

  const [textRight, isrighttextCompleted] = useTyped({
    text: ' All of this will happen again.',
    start: islefttextCompleted,
    speed: 30,
  });

  const [ispreviousVisible, setPreviousVisible] = useState(false);
  if (!ispreviousVisible && isrighttextCompleted) {
    setTimeout(() => {
      setPreviousVisible(true);
    }, 1000);
  }

  return (
    <>
      {!hasCyopBalance && (
        <>
          <h2>CyOp balance required to access this page</h2>
        </>
      )}
      {hasCyopBalance && (
        <>
          {!ispreviousVisible && (
            <div>
              <span>{textLeft}</span>
              {!islefttextCompleted && (
                <span className="typed-cursor danger">|</span>
              )}
              {islefttextCompleted && (
                <span className="text-desc">
                  <span>{textRight}</span>
                  {!isrighttextCompleted && (
                    <span className="typed-cursor danger">|</span>
                  )}
                </span>
              )}
            </div>
          )}
          {ispreviousVisible && <PreviousPanel />}
        </>
      )}
    </>
  );
};

export default PreviousEvent;
