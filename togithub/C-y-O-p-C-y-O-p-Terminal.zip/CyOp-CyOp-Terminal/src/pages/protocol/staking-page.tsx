import { useState, useEffect } from 'react';
import { useAudio } from 'react-awesome-audio';
import { useWeb3, useContracts /*, useHasCyopBalance*/ } from 'shared/hooks';
import addresses from 'shared/addresses';
import { formatUnits } from 'helpers/utils';
import StakeLeftPanel from 'components/stake-left-panel';
const sndContent = require('assets/audio/content.mp3').default;

export const StakingPage = () => {
  const { play } = useAudio({
    src: sndContent,
  });

  const { totalSupply, erc20TotalSupply } = useContracts();

  const { chainId, switchNetwork /*, walletAddress*/ } = useWeb3();

  // const hasCyopBalance = useHasCyopBalance(walletAddress!, chainId!);
  const hasCyopBalance = true;

  useEffect(() => {
    if (chainId !== addresses.arbitrumNetworkID) {
      switchNetwork(addresses.arbitrumNetworkID);
    }
  }, [chainId, switchNetwork]);

  const [protocolSupplyDisplay, setProtocolSupplyDisplay] = useState('0');
  const [protocolSupply, setProtocolSupply] = useState('0');
  const [nTotalSupply, setTotalSupply] = useState('0');
  const [supplyPercent, setSupplyPercent] = useState('0');

  const [detailUpdateInterval] = useState(1000);

  const [isStakeTopicVisible, setStakeTopicVisible] = useState(false);
  if (!isStakeTopicVisible) {
    setTimeout(() => {
      setStakeTopicVisible(true);
    }, 150);
  }

  const [isStakeTextVisible, setStakeTextVisible] = useState(false);
  if (!isStakeTextVisible && isStakeTopicVisible) {
    setTimeout(() => {
      setStakeTextVisible(true);
      play();
    }, 150);
  }

  const [isAllTopicVisible, setAllTopicVisible] = useState(false);
  if (!isAllTopicVisible && isStakeTextVisible) {
    setTimeout(() => {
      setAllTopicVisible(true);
    }, 150);
  }

  const [isAllTextVisible, setAllTextVisible] = useState(false);
  if (!isAllTextVisible && isAllTopicVisible) {
    setTimeout(() => {
      setAllTextVisible(true);
      play();
    }, 150);
  }

  const [isLastTopicVisible, setLastTopicVisible] = useState(false);
  if (!isLastTopicVisible && isAllTextVisible) {
    setTimeout(() => {
      setLastTopicVisible(true);
    }, 150);
  }

  const [isLastTextVisible, setLastTextVisible] = useState(false);
  if (!isLastTextVisible && isLastTopicVisible) {
    setTimeout(() => {
      setLastTextVisible(true);
      play();
    }, 150);
  }

  const [issolidTopicVisible, setsolidTopicVisible] = useState(false);
  if (!issolidTopicVisible && isLastTextVisible) {
    setTimeout(() => {
      setsolidTopicVisible(true);
    }, 150);
  }

  const [issolidTextVisible, setsolidTextVisible] = useState(false);
  if (!issolidTextVisible && issolidTopicVisible) {
    setTimeout(() => {
      setsolidTextVisible(true);
      play();
    }, 150);
  }

  const [isChosenTopicVisible, setChosenTopicVisible] = useState(false);
  if (!isChosenTopicVisible && issolidTextVisible) {
    setTimeout(() => {
      setChosenTopicVisible(true);
    }, 150);
  }

  const getDetails = async () => {
    if (!totalSupply || !erc20TotalSupply) {
      return;
    }

    // get protocol supply
    totalSupply().then((supply) => {
      if (supply !== null) {
        let amountDisplay = formatUnits(supply, 9);
        let amount = formatUnits(supply, 9, false);
        setProtocolSupplyDisplay(amountDisplay);
        setProtocolSupply(amount);
      } else {
        setProtocolSupplyDisplay('0');
      }
    });

    erc20TotalSupply().then((supply) => {
      if (supply !== null) {
        let amount = formatUnits(supply, 9, false);
        setTotalSupply(amount);
      } else {
        setTotalSupply('0');
      }
    });
  };

  useEffect(() => {
    const timer = setInterval(getDetails, detailUpdateInterval);

    return () => {
      clearInterval(timer);
    };
  }, []); // eslint-disable-line

  useEffect(() => {
    let protocolSupplyAmount = parseFloat(protocolSupply);
    let totalSupplyAmount = parseFloat(nTotalSupply);

    // console.log("Protocal Supply:", protocolSupplyAmount)
    // console.log("CyOp totalSupply:", totalSupplyAmount)

    let percent = 0;
    if (totalSupplyAmount !== 0) {
      percent = (protocolSupplyAmount / totalSupplyAmount) * 100;
    }

    let percentString = percent.toFixed(2);
    setSupplyPercent(percentString);
  }, [protocolSupply, nTotalSupply]);

  return (
    <>
      {!hasCyopBalance && (
        <>
          <h2>CyOp balance required to access this page</h2>
        </>
      )}
      {hasCyopBalance && (
        <div className="d-flex h-100 overflow-hidden">
          <div className="co-inner-left-panel d-flex flex-column">
            <StakeLeftPanel />
          </div>
          <div className="co-inner-right-panel d-flex flex-column">
            <div className="co-main-content flex-1">
              {isStakeTopicVisible && <div>Staked within protocol:</div>}
              {isStakeTextVisible && (
                <div className="text-desc">
                  {protocolSupplyDisplay} CyOp [ {supplyPercent}% ]
                </div>
              )}
              {isAllTopicVisible && (
                <div className="pt-3">All time rewards:</div>
              )}
              {isAllTextVisible && (
                <div className="text-desc">0 eth [&#8709;0]</div>
              )}
              {isLastTopicVisible && <div className="pt-3">Last reward:</div>}
              {isLastTextVisible && <div className="text-desc">0 eth</div>}
              {issolidTopicVisible && (
                <div className="pt-3">
                  <span>- sold 0 token for 0 eth </span>
                  <span className="text-danger">[txid]</span>
                </div>
              )}
              {issolidTextVisible && (
                <div className="text-desc">
                  - sold 0 token for 0 eth [txid]
                  <br />
                  - sold 0 token for 0 eth [txid]
                  <br />
                  - sold 0 token for 0 eth [txid]
                  <br />- sold 0 token for 0 eth [txid]
                </div>
              )}
            </div>
            {isChosenTopicVisible && (
              <div style={{ borderTop: '3px solid #05CCB2' }}>
                <div className="pt-2 pb-1">Lucky user</div>
                <div className="pb-1">
                  <span>last: </span>
                  <span className="text-desc">1.7 eth</span>
                </div>
                <div className="pb-1">
                  <span>&nbsp;&nbsp;all time: </span>
                  <span className="text-desc">39.1 eth [&#8709;13.6]</span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
};

export default StakingPage;
