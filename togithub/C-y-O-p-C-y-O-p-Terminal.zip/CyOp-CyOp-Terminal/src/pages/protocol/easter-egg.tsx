import useTyped from "hooks/typed"
import { useState, useRef } from "react"

export const EasterEgg = (props: any) => {
	const [isWakeEnable, setWakeEnable] = useState(false)
	const inputRef = useRef(null)

	const onCompleteRunAnimation = () => {
		setTimeout(() => {
			setWakeEnable(true)
		}, 500)
	}

	const [title, titleCompleted] = useTyped({
		text: "Call trans opt: received. 8-30-18 00:00:00",
		start: true,
		speed: 20,
	})

	const [txtrun, txtrunCompleted] = useTyped({
		text: "Trace program: running",
		start: titleCompleted,
		speed: 20,
		onComplete: onCompleteRunAnimation,
	})

	const [txtwake, txtwakeCompleted] = useTyped({
		text: "Wake up, Neo...",
		start: isWakeEnable,
		speed: 20,
	})

	const [txtmatrix, txtmatrixCompleted] = useTyped({
		text: "The Matrix has you...",
		start: txtwakeCompleted,
		speed: 20,
	})

	const [txtfollow, txtfollowCompleted] = useTyped({
		text: "Follow the white rabbit.",
		start: txtmatrixCompleted,
		speed: 20,
	})

	const onCompleteKnock = () => {
		props.setMatrix(false)

		let tempCmd = props.inputCommand.concat(<div><div>CyOp:\Terminal&gt;{props.matrixCmd}</div><p/><div>Call trans opt: received. 8-30-18 00:00:00</div><div>Trace program: running</div><p/><div>Wake up, Neo...</div><div>The Matrix has you...</div><div>Follow the white rabbit.</div><div>Knock, knock, Neo.</div><br /></div>)
		props.setInputCommand(tempCmd)
		props.setEasterFinish(true)
	}

	const [txtknock, txtknockCompleted] = useTyped({
		text: "Knock, knock, Neo.",
		start: txtfollowCompleted,
		speed: 20,
		onComplete: onCompleteKnock
	})

	return (
		<div ref={inputRef}>
			<div>
				<div>CyOp:\Terminal&gt;{props.matrixCmd}</div><p></p>
				<span>{title}</span>
				{!titleCompleted &&
					<span className="typed-cursor danger">|</span>
				}
			</div>
			<div>
				<span>{txtrun}</span>
				{titleCompleted && !txtrunCompleted &&
					<span className="typed-cursor">|</span>
				}
			</div>
			<p></p>
			<div>
				<span>{txtwake}</span>
				{isWakeEnable && !txtwakeCompleted &&
					<span className="typed-cursor">|</span>
				}
			</div>
			<div ref={inputRef}>
				<span>{txtmatrix}</span>
				{txtwakeCompleted && !txtmatrixCompleted &&
					<span className="typed-cursor">|</span>
				}
			</div>
			<div>
				<span>{txtfollow}</span>
				{txtmatrixCompleted && !txtfollowCompleted &&
					<span className="typed-cursor">|</span>
				}
			</div>
			<div>
				<span>{txtknock}</span>
				{txtfollowCompleted && !txtknockCompleted &&
					<span className="typed-cursor">|</span>
				}
			</div>
		</div>
	)
}

export default EasterEgg