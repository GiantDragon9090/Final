import { useState } from 'react';
import { useAudio } from 'react-awesome-audio';
// import { useWeb3, useHasCyopBalance } from 'shared/hooks';
import WalletLeftPanel from 'components/wallet-left-panel';
const sndContent = require('assets/audio/content.mp3').default;

export const WalletPage = () => {
  const { play } = useAudio({
    src: sndContent,
  });
  // const { chainId, walletAddress } = useWeb3();
  // const hasCyopBalance = useHasCyopBalance(walletAddress!, chainId!);
  const hasCyopBalance = true;
  const [isAboutTopicVisible, setAboutTopicVisible] = useState(false);
  if (!isAboutTopicVisible) {
    setTimeout(() => {
      setAboutTopicVisible(true);
    }, 300);
  }

  const [isAboutTextVisible, setAboutTextVisible] = useState(false);
  if (!isAboutTextVisible && isAboutTopicVisible) {
    setTimeout(() => {
      setAboutTextVisible(true);
      play();
    }, 300);
  }

  return (
    <>
      {!hasCyopBalance && (
        <>
          <h2>CyOp balance required to access this page</h2>
        </>
      )}
      {hasCyopBalance && (
        <div className="d-flex h-100 overflow-hidden">
          <div className="co-inner-left-panel d-flex flex-column">
            <WalletLeftPanel />
          </div>
          <div className="co-inner-right-panel d-flex flex-column">
            <div className="co-main-content flex-1">
              {isAboutTopicVisible && <div>PROTOCOL USER GUIDE:</div>}
              {isAboutTextVisible && (
                <div className="pt-3">
                  <div className="co-main-content flex-1">
                    <div className="text-desc pt-3">
                      This is a step by step guide on how to tune into the
                      protocol.<br></br>
                      <br></br>
                      <br></br>
                    </div>
                    <div>Step 1: Send CyOp and Ether to Arbitrum</div>
                    <div className="text-desc pt-3">
                      The CyOp protocol runs on  <a href="https://metamask.zendesk.com/hc/en-us/articles/4415758358299-Network-profile-Arbitrum" target="_blank" rel="noreferrer">Arbitrum</a>, which saves you plenty
                      of fees while interacting with it. Therefore it is
                      required to transfer CyOp and Ether (for gas) over there. The bridging of CyOp to the Arbitrum network works only via the terminal. 
                      <br></br>
                    </div>
                    <div className="text-desc pt-3">
                      <div>
                        · go to ‘wallet‘<br></br>· select ‘Ethereum network’
                        <br></br>· click on ‘approve‘<br></br>· select CyOp or
                        eth
                        <br></br>· type the amount you want to send and click on
                        ‘send to arbitrum’<br></br>· wait for the blockchain confirmation.
                        Do not leave the page, otherwise your transaction might
                        be canceled.
                        <br></br>· switch chain to Arbitrum and click on ‘approve‘
                        <br></br>· click on ‘claim‘ to receive your CyOp on Arbitrum
                        <br></br>·  If you do not hold any eth for gas fees you must send eth to Arbitrum before you can claim
                        <br></br>· The eth deposit happens automatically within 15 minutes therefore you don't have to claim it<br></br>
                      </div>
                    </div>
                    <br></br>
                    <br></br>
                    <div>Step 2: Stake your CyOp</div>
                    <div className="text-desc pt-3">
                      You need to stake CyOp in order to be able to vote.
                      <br></br>
                    </div>
                    <div className="text-desc pt-3">
                      <div>
                        · go to ‘staking’<br></br>· select ‘Stake’<br></br>·
                        click on ‘approve‘ <br></br>· type the amount you want
                        to send and click on ‘enter‘ <br></br>
                        <br></br>
                      </div>
                    </div>
                    <br></br>
                    <div>Step 3: Vote for a token</div>
                    <div className="text-desc pt-3">
                      <div>
                        · go to ‘Active event’<br></br>· click on ‘vote‘{' '}
                        <br></br>· use the slider to set the amount of CyOp
                        <br></br>· click on ‘lock in‘ to confirm<br></br>
                      </div>
                    </div>

                    <div className="text-desc pt-3">
                      Reminder: Your staked CyOp will be locked for the duration
                      of the voting period and can not be unstaked.
                      <br></br>
                      <br></br>
                    </div>
                    <br></br>
                    <div>Rewards</div>
                    <div className="text-desc pt-3">
You're eligible to receive rewards if you voted in the round from which the "awakened" and sold tokens originate. The CyOp amount used for voting will be put in relation to all other users and determine your share. Note: You will not be rewarded if you unstake before distribution.
                      <br></br>
                      <br></br>
                    </div>
                    <br></br>
                    <div>Lucky User</div>
                    <div className="text-desc pt-3">
                      A 'Lucky user' will experience a matrix glitch in his favor and is awarded 10% of the disruption fund each time the CyOp protocol is executed. In order to be eligible, you must hold at least 2,000,000,000 CyOp tokens and vote in that respective round. If the disruption fund is bigger than 30 ETH, three Lucky user will be selected randomly.
                     <br></br>
                    </div>
                    <br></br>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default WalletPage;
