import { useState } from 'react';
import { useAudio } from 'react-awesome-audio';
// import { useWeb3, useHasCyopBalance } from 'shared/hooks';
import useTyped from 'hooks/typed';
const sndContent = require('assets/audio/content.mp3').default;

export const VoidPage = () => {
  // const { chainId, walletAddress } = useWeb3();
  // const hasCyopBalance = useHasCyopBalance(walletAddress!, chainId!);
  const hasCyopBalance = true;
  const [textEnter, isentertextCompleted] = useTyped({
    text: 'entering the void...',
    start: true,
    speed: 30,
  });
  const [textTotal, istotaltextCompleted] = useTyped({
    text: 'total value sucked in: ',
    start: isentertextCompleted,
    endDelay: 0,
    speed: 30,
  });
  const [textEth, isethtextCompleted] = useTyped({
    text: '$1,972,413',
    start: istotaltextCompleted,
    endDelay: 0,
    speed: 30,
  });
  const [textUSD, isusdtextCompleted] = useTyped({
    text: ' [622.6 eth] ',
    start: isethtextCompleted,
    speed: 30,
  });

  const { play } = useAudio({
    src: sndContent,
  });

  const [isSleepingVisible, setSleepingVisible] = useState(false);
  if (!isSleepingVisible && isusdtextCompleted) {
    setTimeout(() => {
      setSleepingVisible(true);
    }, 300);
  }

  const [isSleepingTextVisible, setSleepingTextVisible] = useState(false);
  if (!isSleepingTextVisible && isSleepingVisible) {
    setTimeout(() => {
      setSleepingTextVisible(true);
      play();
    }, 300);
  }

  const [isBurnedVisible, setBurnedVisible] = useState(false);
  if (!isBurnedVisible && isSleepingTextVisible) {
    setTimeout(() => {
      setBurnedVisible(true);
    }, 300);
  }

  const [isBurnedTextVisible, setBurnedTextVisible] = useState(false);
  if (!isBurnedTextVisible && isBurnedVisible) {
    setTimeout(() => {
      setBurnedTextVisible(true);
      play();
    }, 300);
  }

  return (
    <>
      {!hasCyopBalance && (
        <>
          <h2>CyOp balance required to access this page</h2>
        </>
      )}
      {hasCyopBalance && (
        <div className="co-main-content">
          <div className="mb-2">
            <span>{textEnter}</span>
            {!isentertextCompleted && (
              <span className="typed-cursor danger">|</span>
            )}
          </div>
          <div className="mb-2">
            <span>{textTotal}</span>
            {isentertextCompleted && !istotaltextCompleted && (
              <span className="typed-cursor danger">|</span>
            )}
            <span className="text-danger">{textEth}</span>
            {istotaltextCompleted && !isethtextCompleted && (
              <span className="typed-cursor danger">|</span>
            )}
            {isethtextCompleted && (
              <>
                <span className="text-desc">{textUSD}</span>
                {!isusdtextCompleted && (
                  <span className="typed-cursor danger">|</span>
                )}
              </>
            )}
          </div>
          <div className="mb-2">
            {isSleepingVisible && (
              <div className="pt-3 pb-2">sleeping tokens...</div>
            )}
            {isSleepingTextVisible && (
              <div className="text-desc">
                99,739 X2Y2 
                <br />
                713,170 VXL 
                <br />
                4,903,930 ARC 
                <br />
              </div>
            )}
            {isBurnedVisible && (
              <div className="pt-4 pb-2">burned tokens...</div>
            )}
            {isBurnedTextVisible && (
              <div className="text-desc">
                713,170 VXL - 4,200,000,000,000 CyOp - 4,000,000 ARC - 
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
};

export default VoidPage;
