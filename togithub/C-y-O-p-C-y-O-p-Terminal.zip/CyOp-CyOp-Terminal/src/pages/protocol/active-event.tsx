import { useState, useEffect, ReactNode } from 'react';
import { useAudio } from 'react-awesome-audio';
import { formatUnits } from 'helpers/utils';
import { useWeb3, useContracts /*, useHasCyopBalance*/ } from 'shared/hooks';
import addresses from 'shared/addresses';
import TreeNode from 'components/tree-node';
import Vote from 'components/vote';
import Loading from 'components/loading';
import AddToken from 'pages/protocol/add-token';
import { BigNumber } from 'ethers';
import { IProposal } from 'shared/context/Contracts/Context';

const sndContent = require('assets/audio/content.mp3').default;

interface IEventNode {
  title: string;
  description: string;
  project: string;
  vote: number;
  votePercent: number;
  children?: ReactNode[];
}

export const ActiveEvent = () => {
  const [eventsLoading, setEventsLoading] = useState(false);
  const [voteCountLoading, setVoteCountLoading] = useState(false);
  const [events, setEvents] = useState<IEventNode[]>([]);
  const [proposals, setProposals] = useState<IProposal[]>([]);
  const [isStart, setIsStart] = useState(false);
  const { play } = useAudio({
    src: sndContent,
  });

  const [detailUpdateInterval] = useState(5000);

  const { round, getAllProposals, getVoteCountForAllProposals } =
    useContracts();

  const { chainId, switchNetwork, walletAddress } = useWeb3();
  // const hasCyopBalance = useHasCyopBalance(walletAddress!, chainId!);
  const hasCyopBalance = true;

  const [count, setCount] = useState(0);

  useEffect(() => {
    if (chainId !== addresses.arbitrumNetworkID) {
      switchNetwork(addresses.arbitrumNetworkID);
      if (chainId === addresses.arbitrumNetworkID) {
        setTimeout(() => {
          setEventsLoading(true);
          setVoteCountLoading(true);
          setIsStart(true);
        }, 7000);
      }
    }
    if (chainId === addresses.arbitrumNetworkID && count === 0) {
      setEventsLoading(true);
      setVoteCountLoading(true);
      setIsStart(true);
      setCount(count + 1);
    }
  }, [chainId, switchNetwork, count]);

  const nodeChild = (proposal: IProposal) => [
    <Vote totalVote={proposal.vote || 0} address={proposal.project} />,
    <>
      <span className="text-danger">description:\</span>
      <span>{proposal.description}</span>
    </>,
    <>
      <span className="text-danger">input:\</span>
      <span>
        <a
          href={`https://etherscan.io/token/${proposal.project}`}
          target="_blank"
          rel="noreferrer"
        >
          etherscan
        </a>{' '}
        /
        <a
          href={`https://www.dextools.io/app/ether/pair-explorer/${proposal.pair}`}
          target="_blank"
          rel="noreferrer"
        >
          dextools
        </a>{' '}
        / slippage {proposal.slippage.toString()}%
      </span>
    </>,
  ];

  const renderRootNode = (node: IEventNode, loading?: boolean): ReactNode => (
    <div>
      <span>{node.title}</span>
      <span className="ms-1">
        [&nbsp;{loading && <Loading />}
        {!loading && (
          <>
            {node.votePercent.toFixed(2)}%
            {/* <span className="text-small-vote">{commaValue(node.vote)}</span> */}
          </>
        )}
        &nbsp;]
      </span>
    </div>
  );

  // useEffect(() => {
  //     let newEvents = [...events]
  //     for (var i in newEvents) newEvents[i].value = savedVote[i]
  //     setEvents(newEvents)
  // }, [savedVote])

  let loadTimer: NodeJS.Timeout | null = null;

  const addEvent = (idx: number) => {
    let humanize =
      idx === 0
        ? Math.round(Math.random() * 800 + 500)
        : Math.round(Math.random() * 300 + 100);
    loadTimer = setTimeout(() => {
      if (idx < proposals.length) {
        let newEvents = [];
        for (let i = 0; i <= idx; i++) {
          newEvents.push({
            title: proposals[i].name,
            description: proposals[i].description,
            project: proposals[i].project,
            vote: proposals[i].vote || 0,
            votePercent: proposals[i].votePercent || 0,
            children: nodeChild(proposals[i]),
          });
        }
        newEvents = newEvents.sort((a, b) => b.vote - a.vote);
        setEvents(newEvents);
        if (idx < 2) play();

        addEvent(idx + 1);
      }
    }, humanize);
  };

  const [isAddToken, setAddToken] = useState(false);
  const onAddToken = () => {
    setAddToken(true);
  };

  const getVoteCount = async (proposals: Array<IProposal>) => {
    if (!round || !getVoteCountForAllProposals) return;
    setVoteCountLoading(true);
    try {
      const rnd = await round();
      if (rnd) {
        const voteCountResult: any = await getVoteCountForAllProposals(rnd);
        let roundProposals = voteCountResult._proposals;
        let roundVotes = voteCountResult._votes;
        let totalVotes = BigNumber.from(0);
        roundVotes.forEach((voteCount: BigNumber) => {
          totalVotes = totalVotes.add(voteCount);
        });
        // populate round vote map
        let roundVoteMap: Map<string, number> = new Map([]);
        let roundProposalCount = roundProposals.length;
        for (let i = 0; i < roundProposalCount; i++) {
          const address = roundProposals[i] as string;
          const voteCount = roundVotes[i] as BigNumber;
          const oldVoteCount = roundVoteMap.get(address) || 0;
          roundVoteMap.set(
            address,
            oldVoteCount + parseInt(formatUnits(voteCount, 9, false))
          );
        }
        // filter proposals by vote map
        let proposalCount = proposals.length;
        let finalProposals: IProposal[] = [];
        for (let i = 0; i < proposalCount; i++) {
          let proposal = proposals[i] as any;
          const address = proposal.project;
          const voteCount = roundVoteMap.get(address) || 0;
          const totalVoteCount = parseInt(formatUnits(totalVotes, 9, false));
          finalProposals.push({
            ...proposal,
            vote: voteCount,
            votePercent: (voteCount / totalVoteCount) * 100,
          });
        }
        setProposals(finalProposals);
      }
    } catch (e) {
      console.log(e);
    } finally {
      setVoteCountLoading(false);
    }
  };

  const getDetails = async () => {
    if (!getAllProposals) {
      return;
    }
    if (proposals.length === 0) {
      setEventsLoading(true);
      const result = await getAllProposals();
      if (result !== null && result.length > 0) {
        // setProposals(result);
        // setIsStart(false);
        getVoteCount(result);
        setEventsLoading(false);
      }
    } else {
      getVoteCount(proposals);
    }
  };

  useEffect(() => {
    return () => {
      if (loadTimer) clearTimeout(loadTimer);
    };
  }, []); // eslint-disable-line

  useEffect(() => {
    const timer = setInterval(getDetails, detailUpdateInterval);
    if (proposals.length > 0) {
      if (isStart) {
        setEvents([]);
        addEvent(0);
        setIsStart(false);
      } else {
        let newEvents: IEventNode[] = [];
        for (let i = 0; i < events.length; i++) {
          // get event proposal vote
          const eventProposal = proposals.find(
            (proposal) => proposal.project === events[i].project
          );
          newEvents.push({
            ...events[i],
            vote: eventProposal?.vote || 0,
            votePercent: eventProposal?.votePercent || 0,
          });
        }
        newEvents = newEvents.sort((a, b) => b.vote - a.vote);
        setEvents(newEvents);
      }
    }
    return () => {
      clearInterval(timer);
    };
  }, [proposals, isStart]); // eslint-disable-line

  return (
    <>
      {hasCyopBalance && (
        <>
          {!isAddToken && (
            <>
              <div className="co-searchbar px-2 d-flex align-items-center">
                {/* <div className="me-1">search</div> */}
                <div className="co-search-field-wrapper">
                  {/*      <input className="co-search-field" /> */}
                </div>
                    <div className="ms-auto pointer" onClick={onAddToken}>
                      add token
                    </div>
              </div>
              <div className="co-main-content py-3 flex-1">
                <div className="co-treeview">
                  {eventsLoading && <Loading />}
                  {events.map((event, idx) => (
                    <TreeNode
                      key={`rootnode-${event.title}-${idx}`}
                      title={renderRootNode(event, voteCountLoading)}
                      defaultExpanded={idx === 0}
                    >
                      {event.children?.map((node, idChild) => (
                        <TreeNode
                          key={`child-${event.title}-${idChild}`}
                          title={node}
                        />
                      ))}
                    </TreeNode>
                  ))}
                </div>
              </div>
            </>
          )}
          {isAddToken && <AddToken setAddToken={setAddToken} />}
        </>
      )}
      {!hasCyopBalance && (
        <>
          <h2>CyOp balance required to access this page</h2>
        </>
      )}
    </>
  );
};

export default ActiveEvent;
