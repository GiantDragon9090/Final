import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import useTyped from 'hooks/typed';
import Button from 'components/base/button';
import useWeb3 from 'shared/hooks/useWeb3';
import addresses from 'shared/addresses';
import AppLayout from 'layouts';

export const ConnectWallet = ({
  redirectLink = null,
  setRedirectLink,
}: any) => {
  const navigate = useNavigate();
  const [showConnectButton, setShowConnectButton] = useState(false);
  const { connected, chainId, handleConnect, switchNetwork } = useWeb3();

  const onCompleteTitleAnimation = () => {};

  const onCompleteAnimation = () => {
    setShowConnectButton(true);
  };

  const [title, titleCompleted] = useTyped({
    text: 'TUNE INTO THE GRID:\\',
    start: true,
    speed: 20,
    startDelay: 500,
    onComplete: onCompleteTitleAnimation,
  });
  // eslint-disable-next-line
  const [description, descCompleted] = useTyped({
    text: 'ACCESS THE PROTOCOL BY CONNECTING YOUR WALLET',
    start: titleCompleted,
    speed: 20,
    onComplete: onCompleteAnimation,
  });

  const onClickConnect = () => {
    if (chainId !== addresses.arbitrumNetworkID) {
      switchNetwork(addresses.arbitrumNetworkID);
    }
    handleConnect();
  };

  useEffect(() => {
    if (connected) {
      if (redirectLink) {
        navigate(redirectLink);
        setRedirectLink(null);
      }
    }
  }, [redirectLink, connected, navigate, setRedirectLink]);

  return (
    <>
      <div className="full-screen">
        {(!connected || !chainId) && (
          <div className="full-screen p-3 d-flex flex-column justify-content-center align-items-center">
            <div className="text-large text-danger mb-2">
              <span>{title}</span>
              {!titleCompleted && (
                <span className="typed-cursor danger">|</span>
              )}
            </div>
            <div className="text-large">
              <span>{description}</span>
              {titleCompleted && <span className="typed-cursor">|</span>}
            </div>
            <Button
              className={`btn-connect ${showConnectButton ? '' : 'invisible'}`}
              style={{ marginTop: '70px' }}
              onClick={onClickConnect}
            >
              connect
            </Button>
          </div>
        )}
        {connected &&
          (chainId === addresses.networkID ||
            chainId === addresses.arbitrumNetworkID) && <AppLayout />}
      </div>
    </>
  );
};

export default ConnectWallet;
