import LandingLogo from "components/landing/landing-logo";
import LandingNav from "components/landing/landing-nav";
import LandingContent from "components/landing/landing-content";
import LandingFooter from "components/landing/landing-footer";

export const LandingPage = () => {
  return (
		<div className="full-screen text-center d-flex flex-column align-items-center" style={{padding: "0 50px"}}>
			<LandingLogo />
			<LandingNav />
			<LandingContent />
			<LandingFooter />
		</div>
  );
};

export default LandingPage;
