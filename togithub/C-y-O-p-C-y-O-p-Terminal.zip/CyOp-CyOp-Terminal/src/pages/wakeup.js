import { useState } from "react";
import LoadingPanel from "components/loading-panel";
import Button from "components/base/button";
import TourView from "components/tour-view";
// import ConnectWallet from "./protocol/connect-wallet";

export const WakeUpPage = () => {
  const [initialFinished, setInitialFinished] = useState(true); // eslint-disable-line
  const [iswakedUp, setWakedUp] = useState(false);

  return (
    <div className="full-screen text-center d-flex flex-column justify-content-center align-items-center disable-select">
      <>
        <div className="co-wakeup-initial"></div>
        {initialFinished && !iswakedUp && (
          <>
            <div className="co-wakeup-logo">
              <div className="label-cyop">CYOP</div>
              <div className="label-terminal">TERMINAL</div>
              <Button
                className="btn-wakeup btn-connect border border-secondary"
                onClick={() => { setWakedUp(true); }}
              >
                wake up
              </Button>
            </div>
            
            <div className="co-wakeup-background justify-content-center aligns-items-center">
              <div className="lineLightening">
                <div className="line-1" style={{ marginTop: "2.6vh" }}></div>
                <div className="line-2" style={{ marginTop: "11.25vh" }}></div>
                <div
                  className="line-1 logo-line-l"
                  style={{
                    marginTop: "15.7vh",
                    marginRight: "35vw",
                    animationDelay: "2s",
                  }}
                ></div>
                <div
                  className="line-2 logo-line-r"
                  style={{
                    marginTop: "8.7vh",
                    marginLeft: "35vw",
                    animationDelay: "1s",
                  }}
                ></div>
                <div className="line-3" style={{ marginTop: "18.2vh" }}></div>
                <div
                  className="line-3"
                  style={{ marginTop: "8.7vh", animationDelay: "1s" }}
                ></div>
              </div>
            </div>

            <TourView />
          </>
        )}
        {initialFinished && iswakedUp && <LoadingPanel />}
      </>
    </div>
  );
};

export default WakeUpPage;
