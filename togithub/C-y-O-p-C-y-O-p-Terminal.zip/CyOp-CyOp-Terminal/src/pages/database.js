import { useState, useEffect, useRef } from "react"
import { useAudio } from "react-awesome-audio"
import useTyped from "hooks/typed"
import CommandInputing from "components/input-command"
import ClickCommand from "components/click-command"
import EasterEgg from "./protocol/easter-egg"

const sndContent = require("assets/audio/content.mp3").default

export const DatabasePage = () => {

	const { play } = useAudio({
		src: sndContent,
	})

	const containerRef = useRef(null)

	const [commandVisible, setCommandVisible] = useState(false)
	const [isCleared, setCleared] = useState(false)
	const [inputCommand, setInputCommand] = useState([])
	
	const [isInitClick, setInitClick] = useState(false)
	const [initClkCommand, setInitClkCommand] = useState('')

	const [isEasterFinished, setEasterFinish] = useState(false)
	const [isMatrix, setMatrix] = useState(false)
	const [matrixCmd, setMatrixCmd] = useState('')

	const [isClkCmdFinished, setClkCmdFinish] = useState(false)
	const [isClkCmd, setIsClkCmd] = useState(false)
	const [clickCommand, setClickCommand] = useState('')
	const [clkCmdContent, setClickCmdContent] = useState()

	useEffect(() => {
		if (inputCommand.length == 0) {
			setCleared(false)
		} else if(inputCommand[0] === ''){
			setCleared(true);
			setMatrix(false)
			setIsClkCmd(false)
		} 
		if (containerRef.current) {
			setMatrix(false)
			setIsClkCmd(false)
			setTimeout(() => {
				containerRef.current.scrollTop = containerRef.current.scrollHeight;
			}, 50)
		}
	}, [inputCommand])

	const [greetingText, isGreetingTextCompleted] = useTyped({
		text: "Hello User, tune into the grid and feel the pulse of the ever amping CyOp Protocol.",
		start: true,
		noSound: false,
		speed: 30
	})

	useEffect(() => {
		if (isGreetingTextCompleted && !commandVisible) {
			const timer = setTimeout(() => {
				setCommandVisible(true)
				play()
			}, 500)

			return () => {
				clearTimeout(timer)
			}
		}
	}, [isGreetingTextCompleted, commandVisible]) // eslint-disable-line

	useEffect(() => {
		if ((isMatrix && !isEasterFinished) || (isClkCmd && !isClkCmdFinished)) {
			const timer = setInterval(() => {
				if (containerRef.current)
					containerRef.current.scrollTop = containerRef.current.scrollHeight;
			}, 100)

			return () => {
				clearInterval(timer)
			}
		}
	}, [isMatrix, isEasterFinished, isClkCmdFinished])

	const onClickCommand  = (cmd) =>{
		setInitClkCommand(cmd);
		setInitClick(true);
  }

	return (
		<div className="co-left-panel disable-select" ref={containerRef}>
			{!isCleared &&
				<>
					<div>
						<span>{greetingText}</span>
						{!isGreetingTextCompleted &&
							<span className="typed-cursor danger">|</span>
						}
					</div>
					{commandVisible &&
						<>
							<span className="text-desc">
								<p></p>════════════════════════════<p></p>
							</span>
							<span>Commands:<br /></span>
							<div className="text-desc">
								<span className='command-click' onClick={() => onClickCommand('intro')}>intro</span><br />
								<span className='command-click' onClick={() => onClickCommand('protocol')}>protocol</span><br />
								<span className='command-click' onClick={() => onClickCommand('rewards')}>rewards</span><br />
								<span className='command-click' onClick={() => onClickCommand('calculation')}>calculation</span><br />
								<span className='command-click' onClick={() => onClickCommand('modules')}>modules</span><br />
								<span className='command-click' onClick={() => onClickCommand('metagrid')}>metagrid</span><br />
								<span className='command-click' onClick={() => onClickCommand('tokenomics')}>tokenomics</span><br />
								<span className='command-click' onClick={() => onClickCommand('roadmap')}>roadmap</span><br />
								<span className='command-click' onClick={() => onClickCommand('contact')}>contact</span><br />
								<span className='command-click' onClick={() => onClickCommand('links')}>links</span><br />
								<span className='command-click' onClick={() => onClickCommand('syndicate')}>syndicate</span><br />
								<span className='command-click' onClick={() => onClickCommand('commands')}>commands</span><br />
								<span className='command-click' onClick={() => onClickCommand('clear')}>clear</span><p></p>
								════════════════════════════<br /><br />
							</div>
						</>
					}
				</>
			}
			{commandVisible &&
				<>
					<div id="command-text-field" >{inputCommand}</div>
					{isMatrix &&
						<EasterEgg
							inputCommand={inputCommand}
							setInputCommand={setInputCommand}
							setMatrix={setMatrix}
							matrixCmd={matrixCmd}
							setEasterFinish={setEasterFinish}
						/>
					}
					{isClkCmd &&
						<ClickCommand
							inputCommand={inputCommand}
							setInputCommand={setInputCommand}
							setIsClkCmd={setIsClkCmd}
							clickCommand={clickCommand}
							setClkCmdFinish={setClkCmdFinish}
							clkCmdContent={clkCmdContent}
							setInitClick={setInitClick}
						/>
					}
					{((!isClkCmd && !isMatrix) || ((isMatrix && isEasterFinished) || (isClkCmd && isClkCmdFinished))) &&
						<CommandInputing
							inputCommand={inputCommand}
							setInputCommand={setInputCommand}
							setMatrix={setMatrix}
							setMatrixCmd={setMatrixCmd}
							setEasterFinish={setEasterFinish}
							setIsClkCmd={setIsClkCmd}
							setClickCommand={setClickCommand}
							setClickCmdContent={setClickCmdContent}
							setClkCmdFinish={setClkCmdFinish}
							isInitClick={isInitClick}
							initClkCommand={initClkCommand}
						/>
					}
				</>
			}
		</div>
	)
}

export default DatabasePage
