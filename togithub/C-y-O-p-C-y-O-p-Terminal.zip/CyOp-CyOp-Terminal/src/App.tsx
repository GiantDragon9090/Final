import MainRouter from 'router';
import { ToastContainer } from 'react-toastify';
import { Web3Provider } from './shared/context/Web3';
import { ContractsProvider } from './shared/context/Contracts';
import './assets/scss/index.scss';
import 'react-toastify/dist/ReactToastify.css';
import "animate.css/animate.min.css";

function App() {
  return (
    <div className="co-mainwrap">
      <Web3Provider>
        <ContractsProvider>
          <MainRouter />
        </ContractsProvider>
      </Web3Provider>
      <ToastContainer
        theme="dark"
        position="top-right"
        autoClose={5000}
        hideProgressBar={true}
        newestOnTop={true}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
    </div>
  );
}

export default App;
