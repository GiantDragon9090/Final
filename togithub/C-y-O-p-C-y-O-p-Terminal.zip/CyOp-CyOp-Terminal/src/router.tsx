import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import AppLayout from './layouts';
// import useWeb3 from './shared/hooks/useWeb3';
// import addresses from 'shared/addresses';
// import LoadingPage from 'pages/protocol/loading';
import WakeUpPage from 'pages/wakeup';
import TourPageOne from 'pages/tour/tour_one';
import TourPageTwo from 'pages/tour/tour_two';
import TourPageThree from 'pages/tour/tour_three';
import LandingPage from 'pages/landingpage';

function MainRouter() {
  // const { loading, connected, chainId } = useWeb3();

  return (
    <Router>
      <Routes>
        {/*{loading && (
          <>
            <Route path="/*" element={<LoadingPage />} />
            <Route path="/" element={<LoadingPage />} />
          </>
        )} */}
        {/* {!loading &&
          (!connected ||
            (chainId !== addresses.networkID &&
              chainId !== addresses.arbitrumNetworkID)) && (
            <Route path="/*" element={<AppLayout />} />
          )} */}
        <Route path="/tour_one" element={<TourPageOne />} />
        <Route path="/tour_two" element={<TourPageTwo />} />
        <Route path="/tour_three" element={<TourPageThree />} />
        <Route path="/" element={<LandingPage />} />
        <Route path="/wakeup" element={<WakeUpPage />} />
        <Route path="/*" element={<AppLayout />} />
      </Routes>
    </Router>
  );
}

export default MainRouter;
