import { useCallback, useEffect, useState, FC } from 'react';
import { ethers } from 'ethers';
import { JsonRpcSigner } from '@ethersproject/providers/lib/json-rpc-provider';
import { Bridge } from 'arb-ts';
import Web3Modal, { IProviderOptions } from 'web3modal';
import Context from './Context';
import addresses from 'shared/addresses';

const Provider: FC = ({ children }) => {
  const [loading, setLoading] = useState(true);
  const [web3Modal, setWeb3Modal] = useState<Web3Modal>();
  const [installed, setInstalled] = useState(false);
  const [connected, setConnected] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [walletAddress, setWalletAddress] = useState<string>();
  const [walletBalance, setWalletBalance] = useState<string>();
  const [chainId, setChainId] = useState<string>('');
  const [wallet, setWallet] = useState<ethers.providers.JsonRpcSigner>();
  const [arbBridge, setArbBridge] = useState<any>(null);

  const [currentProvider, setCurrentProvider] = useState(undefined);

  const handleConnect = async () => {
    setConnecting(true);
    let provider = null;
    try {
      provider = await web3Modal?.connect();
    } catch (e) {}

    if (provider) {
      const newWeb3 = new ethers.providers.Web3Provider(provider, 'any');
      const accounts = await newWeb3.listAccounts();
      const balance = await newWeb3.getBalance(accounts[0]);

      setWalletBalance(ethers.utils.formatEther(balance));
      setWalletAddress(accounts[0]);
      setWallet(newWeb3.getSigner());
      setConnected(true);

      setChainId((newWeb3.provider as any).chainId);
      setCurrentProvider(provider);
      setLoading(false);

      if (window.localStorage)
        window.localStorage.setItem('wallet_connect', 'true');

      provider.on('accountsChanged', (newAccounts: string[]) => {
        if (Array.isArray(newAccounts) && newAccounts.length) {
          setWalletAddress(newAccounts[0]);
        } else if (newAccounts?.length === 0) {
          handleDisconnect();
        }
      });

      provider.on('chainChanged', (chainId: string) => {
        setChainId(chainId);
      });
      if (
        chainId !== addresses.networkID &&
        chainId !== addresses.arbitrumNetworkID
      ) {
        switchNetwork(addresses.arbitrumNetworkID);
      }
    } else {
      await handleDisconnect();
    }

    setConnecting(false);
  };

  const switchNetwork = async (newChainId: string) => {
    if (currentProvider) {
      try {
        await window.ethereum.request({
          method: 'wallet_switchEthereumChain',
          params: [{ chainId: newChainId }],
        });
      } catch (switchError: any) {
        // This error code indicates that the chain has not been added to MetaMask.
        if (switchError?.code === 4902) {
          try {
            await window.ethereum.request({
              method: 'wallet_addEthereumChain',
              params: [
                newChainId === addresses.networkID
                  ? {
                      chainId: newChainId,
                      chainName: addresses.networkName,
                      rpcUrls: [addresses.rpcURL],
                    }
                  : {
                      chainId: newChainId,
                      chainName: addresses.arbitrumNetworkName,
                      rpcUrls: [addresses.arbitrumRpcURL],
                    },
              ],
            });
          } catch (addError) {
            // handle "add" error
            console.log('addError:', addError);
          }
        }
        // handle other "switch" errors
      }
    }
  };

  const handleDisconnect = async () => {
    setConnected(false);
    setWalletAddress(undefined);
    setWallet(undefined);
    if (web3Modal) {
      web3Modal.clearCachedProvider();
    }
    if (window.localStorage)
      window.localStorage.setItem('wallet_connect', 'false');
  };

  const protocolBalance = async () => {
    if (!currentProvider) {
      return null;
    }
    try {
      const newWeb3 = new ethers.providers.Web3Provider(currentProvider, 'any');
      const balance = await newWeb3.getBalance(addresses.Protocol);
      return balance;
     
    } catch (err) {
      console.log('protocol Balance:', protocolBalance);
      return null;
    }
  };

  const readProtocolBalance = async () => {
    try {
      const newWeb3 = new ethers.providers.JsonRpcProvider(addresses.rpcURL);
      const balance = await newWeb3.getBalance(addresses.Protocol);
      return balance;
    } catch (err) {
      console.log('protocol Balance:', protocolBalance);
      return null;
    }
  };

  const getSetWalletBalance = async () => {
    if (wallet) {
      let balance: any = await wallet.getBalance();
      balance = ethers.utils.formatEther(balance);
      setWalletBalance(balance);
      return balance;
    }
  };
  const checkTransaction = async (hash: string) => {
    if (currentProvider) {
      const newWeb3 = new ethers.providers.Web3Provider(currentProvider, 'any');
      return await newWeb3.perform('getTransactionReceipt', {
        transactionHash: hash,
      });
    }
    return null;
  };

  const waitForTransaction = (hash: string, timeOut = 1000) => {
    return new Promise((resolve, reject) => {
      if (hash === null || hash === undefined) {
        reject();
        return;
      }
      const interval = setInterval(async () => {
        const result = await checkTransaction(hash);
        if (result) {
          if (result.status === '0x1' || result.status === 1) {
            resolve(true);
          } else {
            reject(false);
          }

          clearInterval(interval);
        }
      }, timeOut);
    });
  };

  const initWeb3Modal = async () => {
    try {
      if (!web3Modal) {
        const providerOptions: IProviderOptions = {
          metamask: {
            package: null,
          },
        };

        const newWeb3Modal = new Web3Modal({
          network: 'mainnet',
          cacheProvider: true,
          providerOptions,
          theme: 'light',
        });

        setWeb3Modal(newWeb3Modal);
      }
    } catch (e) {
      console.log(e);
    }
  };

  const getL1Signer = useCallback(() => {
    if (chainId !== addresses.networkID) {
      const ethProvider = new ethers.providers.JsonRpcProvider(
        addresses.rpcURL
      );
      return ethProvider.getSigner(walletAddress!);
    }
    return wallet as JsonRpcSigner;
  }, [chainId, walletAddress, wallet]);

  const getL2Signer = useCallback(() => {
    if (chainId === addresses.arbitrumNetworkID) {
      return wallet as JsonRpcSigner;
    }

    const arbProvider = new ethers.providers.JsonRpcProvider(
      addresses.arbitrumRpcURL
    );

    return arbProvider.getSigner(walletAddress!);
  }, [chainId, walletAddress, wallet]);

  useEffect(() => {
    (async function () {
      if (chainId) {
        const bridge = await Bridge.init(getL1Signer(), getL2Signer());
        setArbBridge(bridge);
      }
    })();
  }, [chainId, getL1Signer, getL2Signer]);

  useEffect(() => {
    if (web3Modal === undefined) return;
    if (typeof window.ethereum !== 'undefined') {
      setInstalled(true);
      if (connected) {
        handleConnect();
      } else {
        setLoading(false);
      }
    } else {
      setInstalled(false);
      setLoading(false);
    }
  }, [web3Modal]); // eslint-disable-line

  useEffect(() => {
    if (window.localStorage)
      setConnected(localStorage.getItem('wallet_connect') === 'true');
    initWeb3Modal();
  }, []); // eslint-disable-line

  return (
    <Context.Provider
      value={{
        handleConnect,
        handleDisconnect,
        switchNetwork,
        protocolBalance,
        readProtocolBalance,
        loading,
        installed,
        connected,
        connecting,
        walletAddress,
        walletBalance,
        wallet,
        chainId,
        checkTransaction,
        waitForTransaction,
        arbBridge,
        getSetWalletBalance,
      }}
    >
      {children}
    </Context.Provider>
  );
};

export default Provider;
