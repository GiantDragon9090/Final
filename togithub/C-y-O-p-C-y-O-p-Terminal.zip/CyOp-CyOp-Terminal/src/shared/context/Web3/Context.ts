import { createContext } from 'react';
import { ethers } from 'ethers';

interface IWeb3Context {
  handleConnect: () => void;
  handleDisconnect: () => void;
  switchNetwork: (chainId: string) => void;
  protocolBalance?: () => any;
  readProtocolBalance?: () => any;
  loading: boolean;
  installed: boolean;
  connected: boolean;
  connecting: boolean;
  walletAddress?: string;
  walletBalance?: string;
  wallet?: ethers.providers.JsonRpcSigner;
  chainId?: string;
  checkTransaction?: (hash: string) => any;
  waitForTransaction?: (hash: string, timeout: number) => Promise<unknown>;
  arbBridge?: any;
  getSetWalletBalance?: () => Promise<any>;
}

const Context = createContext<IWeb3Context>({
  handleConnect: () => {},
  handleDisconnect: () => {},
  switchNetwork: (chainId: string) => {},
  loading: true,
  installed: false,
  connected: false,
  connecting: false,
});
export default Context;
