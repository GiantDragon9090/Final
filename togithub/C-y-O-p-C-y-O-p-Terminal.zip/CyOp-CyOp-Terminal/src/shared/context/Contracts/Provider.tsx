import { useEffect, useState, FC } from 'react';
import { Contract, BigNumber, providers, utils } from 'ethers';
import { JsonRpcSigner } from '@ethersproject/providers';
import Context from './Context';
import abis from '../../abis';
import useWeb3 from '../../hooks/useWeb3';
import addresses from '../../addresses';

const VaultReadContract = new Contract(
  addresses.Vault,
  abis.Vault,
  new providers.JsonRpcProvider(addresses.rpcURL)
);
const BridgeReadContract = new Contract(
  addresses.arbitrumBridge,
  abis.Bridge,
  new providers.JsonRpcProvider(addresses.arbitrumRpcURL)
);
const CyOpL2ReadContract = new Contract(
  addresses.arbitrumCyOp,
  abis.CyOp,
  new providers.JsonRpcProvider(addresses.arbitrumRpcURL)
);
const arbDAOReadContract = new Contract(
  addresses.arbitrumDAO,
  abis.DAO,
  new providers.JsonRpcProvider(addresses.arbitrumRpcURL)
);

const Provider: FC = ({ children }) => {
  const { wallet, walletAddress, chainId } = useWeb3();
  const [CyOp, setCyOp] = useState(new Contract(addresses.CyOp, abis.CyOp));
  const [DAO, setDAO] = useState(new Contract(addresses.DAO, abis.DAO));
  const [DAOL2, setDAOL2] = useState(
    new Contract(addresses.arbitrumDAO, abis.DAO)
  );
  const [Vault, setVault] = useState(new Contract(addresses.Vault, abis.Vault));
  const [CyOpL2, setCyOpL2] = useState(
    new Contract(addresses.arbitrumCyOp, abis.CyOp)
  );
  const [BridgeL2, setBridgeL2] = useState(
    new Contract(addresses.arbitrumBridge, abis.Bridge)
  );

  useEffect(() => {
    if (!!wallet) {
      if (!CyOp.signer) {
        setCyOp(CyOp.connect(wallet));
      }
      if (!CyOpL2.signer) {
        setCyOpL2(CyOpL2.connect(wallet));
      }
      if (!DAO.signer) {
        setDAO(DAO.connect(wallet));
      }
      if (!DAOL2.signer) {
        setDAOL2(DAOL2.connect(wallet));
      }
      if (!Vault.signer) {
        setVault(Vault.connect(wallet));
      }
      if (!BridgeL2.signer) {
        setBridgeL2(BridgeL2.connect(wallet));
      }
    }
  }, [wallet, CyOp, DAO, DAOL2, Vault, CyOpL2, BridgeL2]);

  const createProposal = async (
    project: string,
    pair: string,
    slippage: BigNumber,
    description: string,
    name: string,
    amount: string,
    layer: string = 'L2'
  ) => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !useDAO.signer || !wallet) return null;
    if (chainId !== networkID) return null;

    try {
      // const DAOWithSigner = DAO.connect(wallet as JsonRpcSigner)
      await useDAO.createProposal(project, pair, slippage, description, name, amount);
      return true;
    } catch (err) {
      console.log('createProposal error:', err);
      return null;
    }
  };

  const particpiate = async (
    project: string,
    vote: BigNumber,
    layer: string = 'L2'
  ) => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !useDAO.signer || !wallet) return null;
    if (chainId !== networkID) return null;

    try {
      return useDAO.particpiate(project, vote);
    } catch (err) {
      console.log('particpiate error:', err);
      return null;
    }
  };

  const getAllProposals = async (layer: string = 'L2') => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !useDAO.signer) return null;
    if (chainId !== networkID) return null;

    try {
      const result = await useDAO.getAllProposals();
      return result;
    } catch (err) {
      console.log('getAllProposals error:', err);
      return null;
    }
  };

  const getVoteCountForAllProposals = async (
    round: BigNumber,
    layer: string = 'L2'
  ) => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !useDAO.signer) return null;
    if (chainId !== networkID) return null;

    try {
      const result = await useDAO.getVoteCountForAllProposals(round);
      return result;
    } catch (err) {
      console.log('getVoteCountForAllProposals', err);
      return null;
    }
  };

  const proposalInfo = async (proposal: string, layer: string = 'L2') => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !useDAO.signer) return null;
    if (chainId !== networkID) return null;

    try {
      const result = await useDAO.proposalInfo(proposal);
      return result;
    } catch (err) {
      console.log('proposalInfo error:', err);
      return null;
    }
  };

  const proposalList = async (proposalId: BigNumber, layer: string = 'L2') => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !useDAO.signer) return null;
    if (chainId !== networkID) return null;

    try {
      const proposal = await useDAO.proposalList(proposalId);
      return proposal;
    } catch (err) {
      console.log('proposalList error:', err);
      return null;
    }
  };

  const getWinningProposal = async (round: BigNumber, layer: string = 'L2') => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;

    if (!walletAddress || !useDAO.signer) return null;
    if (chainId !== addresses.networkID) return null;

    try {
      const result = await useDAO.getWinningProposal(round);
      return {
        project: result._project as string,
        maxVote: result._maxVote as BigNumber,
      };
    } catch (err) {
      console.log('getWinningProposal error:', err);
      return null;
    }
  };

  const stake = async (amount: BigNumber, layer: string = 'L2') => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !useDAO.signer || !wallet) return null;
    if (chainId !== networkID) return null;

    try {
      const DAOWithSigner = useDAO.connect(wallet as JsonRpcSigner);
      return DAOWithSigner.stake(amount);
    } catch (err) {
      console.log('stake error:', err);
      return null;
    }
  };

  const approve = async (
    spender: string,
    amount: BigNumber,
    layer: string = 'L2'
  ) => {
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;
    const CyOpType = layer === 'L2' ? CyOpL2 : CyOp;

    if (!walletAddress || !CyOpType.signer || !wallet) return null;
    if (chainId !== networkID) return null;

    try {
      const CyOpWithSigner = CyOpType.connect(wallet as JsonRpcSigner);
      return await CyOpWithSigner.approve(spender, amount);
    } catch (err) {
      console.log('approve error:', err);
      return null;
    }
  };

  const allowance = async (
    owner: string,
    spender: string,
    layer: string = 'L2'
  ) => {
    const CyOpType = layer === 'L2' ? CyOpL2 : CyOp;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !CyOpType.signer) return null;
    if (chainId !== networkID) return null;

    try {
      const amount = await CyOpType.allowance(owner, spender);
      return amount;
    } catch (err) {
      console.log('allowance error:', err);
      return null;
    }
  };

  const unstake = async (amount: BigNumber, layer: string = 'L2') => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !useDAO.signer || !wallet) return null;
    if (chainId !== networkID) return null;

    try {
      const DAOWithSigner = useDAO.connect(wallet as JsonRpcSigner);
      return DAOWithSigner.unstake(amount);
    } catch (err) {
      console.log('unstake error:', err);
      return err;
    }
  };

  const claimRewards = async (round: BigNumber, layer: string = 'L2') => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !useDAO.signer || !wallet) return null;
    if (chainId !== networkID) return null;

    try {
      const DAOWithSigner = useDAO.connect(wallet as JsonRpcSigner);
      const wholeNumber = await DAOWithSigner.claimRewards(round);
      return wholeNumber;
    } catch (err) {
      console.log('claimRewards error:', err);
      return null;
    }
  };

  const userClaimAmount = async (
    account: string,
    round: BigNumber,
    layer: string = 'L2'
  ) => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !useDAO.signer) return null;
    if (chainId !== networkID) return null;

    try {
      const claimAmount = await useDAO.userClaimAmount(account, round);
      return claimAmount;
    } catch (err) {
      console.log('userClaimAmount error:', err);
      return null;
    }
  };

  const isUserEligibleToClaim = async (
    account: string,
    round: BigNumber,
    layer: string = 'L2'
  ) => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !useDAO.signer) return null;
    if (chainId !== networkID) return null;

    try {
      const isEligible = await useDAO.isUserEligibleToClaim(account, round);
      return isEligible;
    } catch (err) {
      console.log('isUserEligibleToClaim error:', err);
      return null;
    }
  };

  const getUserVotingShare = async (
    account: string,
    round: BigNumber,
    layer: string = 'L2'
  ) => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !useDAO.signer) return null;
    if (chainId !== networkID) return null;

    try {
      const userVotingShare = await useDAO.getUserVotingShare(account, round);
      return userVotingShare;
    } catch (err) {
      console.log('getUserVotingShare error:', err);
      return null;
    }
  };

  const getProposalWon = async (round: BigNumber, layer: string = 'L2') => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !useDAO.signer) return null;
    if (chainId !== networkID) return null;

    try {
      const project = await useDAO.getProposalWon(round);
      return project;
    } catch (err) {
      console.log('getProposalWon error:', err);
      return null;
    }
  };

  const isUserVoted = async (
    account: string,
    round: BigNumber,
    layer: string = 'L2'
  ) => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !useDAO.signer) return null;
    if (chainId !== networkID) return null;

    try {
      const isVoted = await useDAO.isUserVoted(account, round);
      return isVoted;
    } catch (err) {
      console.log('isUserVoted error:', err);
      return null;
    }
  };

  const userVoteCount = async (
    account: string,
    round: BigNumber,
    layer: string = 'L2'
  ) => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !useDAO.signer) return null;
    if (chainId !== networkID) return null;

    try {
      const voteCount = await useDAO.userVoteCount(account, round);
      return voteCount;
    } catch (err) {
      console.log('userVoteCount error:', err);
      return null;
    }
  };

  const totalUserVoted = async (round: BigNumber, layer: string = 'L2') => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !useDAO.signer) return null;
    if (chainId !== networkID) return null;

    try {
      const voteUserCount = await useDAO.totalUserVoted(round);
      return voteUserCount;
    } catch (err) {
      console.log('totalUserVoted error:', err);
      return null;
    }
  };

  const getProposalVoteCount = async (
    project: string,
    round: BigNumber,
    layer: string = 'L2'
  ) => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !useDAO.signer) return null;
    if (chainId !== networkID) return null;

    try {
      const proposalVoteCount = await useDAO.getProposalVoteCount(
        project,
        round
      );
      return proposalVoteCount;
    } catch (err) {
      console.log('getProposalVoteCount error:', err);
      return null;
    }
  };

  const stakeAmount = async (account: string, layer: string = 'L2') => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !useDAO.signer) return null;
    if (chainId !== networkID) return null;

    try {
      const amount = await useDAO.stakeAmount(account);
      return amount;
    } catch (err) {
      console.log('stakeAmount error:', err);
      return null;
    }
  };

  const balanceOf = async (layer: string = 'L2') => {
    const CyOpType = layer === 'L2' ? CyOpL2 : CyOp;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !CyOpType.signer) return null;
    if (chainId !== networkID) return null;

    try {
      const balance = await CyOpType.balanceOf(walletAddress);
      return balance as BigNumber;
    } catch (err) {
      console.log('balanceOf error:', err);
      return null;
    }
  };

  const totalSupply = async (layer: string = 'L2') => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !useDAO.signer) return null;
    if (chainId !== networkID) return null;

    try {
      const supply = await useDAO.totalSupply();
      return supply as BigNumber;
    } catch (err) {
      console.log('totalSupply error:', err);
      return null;
    }
  };

  const erc20TotalSupply = async (layer: string = 'L2') => {
    const CyOpType = layer === 'L2' ? CyOpL2 : CyOp;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !CyOpType.signer) return null;
    if (chainId !== networkID) return null;

    try {
      const supply = await CyOpType.totalSupply();
      return supply as BigNumber;
    } catch (err) {
      console.log('erc20TotalSupply error:', err);
      return null;
    }
  };

  const userCount = async (layer: string = 'L2') => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !useDAO.signer) return null;
    if (chainId !== networkID) return null;

    try {
      const count = await useDAO.userCount();
      return count as BigNumber;
    } catch (err) {
      console.log('userCount error:', err);
      return null;
    }
  };

  const proposalCount = async (layer: string = 'L2') => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !useDAO.signer) return null;
    if (chainId !== networkID) return null;

    try {
      const count = await useDAO.proposalCount();
      return count as BigNumber;
    } catch (err) {
      console.log('proposalCount error:', err);
      return null;
    }
  };

  const round = async (layer: string = 'L2') => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !useDAO.signer) return null;
    if (chainId !== networkID) return null;

    try {
      const _round = await useDAO.round();
      return _round as BigNumber;
    } catch (err) {
      console.log('round error:', err);
      return null;
    }
  };

  const voteStartTime = async (layer: string = 'L2') => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !useDAO.signer) return null;
    if (chainId !== networkID) return null;

    try {
      const time = await useDAO.voteStartTime();
      return time as BigNumber;
    } catch (err) {
      // console.log('voteStartTime error:', err);
      return null;
    }
  };

  const readVoteStartTime = async () => {
    try {
      const time = await arbDAOReadContract.voteStartTime();
      return time as BigNumber;
    } catch (err) {
      console.log('voteStartTime error:', err);
      return null;
    }
  };

  const resultTime = async (layer: string = 'L2') => {
    const useDAO = layer === 'L2' ? DAOL2 : DAO;
    const networkID =
      layer === 'L2' ? addresses.arbitrumNetworkID : addresses.networkID;

    if (!walletAddress || !useDAO.signer) return null;
    if (chainId !== networkID) return null;

    try {
      const time = await useDAO.resultTime();
      return time as BigNumber;
    } catch (err) {
      console.log('resultTime error:', err);
      return null;
    }
  };

  const readResultTime = async (layer: string = 'L2') => {
    try {
      const time = await arbDAOReadContract.resultTime();
      return time as BigNumber;
    } catch (err) {
      console.log('resultTime error:', err);
      return null;
    }
  };

  // vault methods
  const vaultDeposit = async (amount: BigNumber) => {
    if (!walletAddress || !Vault.signer || !wallet) return null;
    if (chainId !== addresses.networkID) return null;

    try {
      const VaultWithSigner = Vault.connect(wallet as JsonRpcSigner);
      return await VaultWithSigner.deposit(amount);
    } catch (err) {
      console.log('approve error:', err);
      return null;
    }
  };

  const vaultWithdraw = async (
    amount: BigNumber,
    deadline: BigNumber,
    v: number,
    r: string,
    s: string,
    layer: string = 'L2'
  ) => {
    if (!walletAddress || !Vault.signer || !wallet) return null;
    if (chainId !== addresses.networkID) return null;

    try {
      const VaultWithSigner = Vault.connect(wallet as JsonRpcSigner);
      return VaultWithSigner.withdraw(amount, deadline, v, r, s);
    } catch (err) {
      console.log('approve error:', err);
      return null;
    }
  };

  const vaultUserInfo = async (user: string) => {
    try {
      return await VaultReadContract.userInfo(user);
    } catch (err) {
      console.log('Error:', err);
      return null;
    }
  };

  const vaultNonces = async (user: string) => {
    try {
      return await VaultReadContract.nonces(user);
    } catch (err) {
      console.log('Error:', err);
      return null;
    }
  };

  const vaultTrustedSigner = async (user: string) => {
    try {
      return await VaultReadContract.trustedSigner(user);
    } catch (err) {
      console.log('Error:', err);
      return null;
    }
  };

  // const approveL2 = async (spender: string, amount: BigNumber) => {
  //   if (!walletAddress || !CyOpL2.signer || !wallet) return null;
  //   if (chainId !== addresses.arbitrumNetworkID) return null;

  //   try {
  //     const CyOpWithSigner = CyOpL2.connect(wallet as JsonRpcSigner);
  //     return await CyOpWithSigner.approve(spender, amount);
  //   } catch (err) {
  //     console.log("approve error:", err);
  //     return null;
  //   }
  // };

  // const allowanceL2 = async (owner: string, spender: string) => {
  //   if (!walletAddress || !CyOpL2.signer) return null;
  //   if (chainId !== addresses.arbitrumNetworkID) return null;

  //   try {
  //     const amount = await CyOpL2.allowance(owner, spender);
  //     return amount;
  //   } catch (err) {
  //     console.log("allowance error:", err);
  //     return null;
  //   }
  // };

  const balanceOfL2 = async () => {
    try {
      const balance = await CyOpL2ReadContract.balanceOf(walletAddress);
      return balance as BigNumber;
    } catch (err) {
      console.log('balanceOf error:', err);
      return null;
    }
  };

  const bridgeNoncesL2 = async (user: string) => {
    try {
      return await BridgeReadContract.nonces(user);
    } catch (err) {
      console.log('Error:', err);
      return null;
    }
  };

  const bridgeMoveBackL2 = async (amount: BigNumber) => {
    if (!walletAddress || !BridgeL2.signer || !wallet) return null;
    if (chainId !== addresses.arbitrumNetworkID) return null;
    try {
      const BridgeL2WithSigner = BridgeL2.connect(wallet as JsonRpcSigner);
      return await BridgeL2WithSigner.moveBack(amount);
    } catch (err) {
      console.log('approve error:', err);
      return null;
    }
  };

  const bridgeClaimL2 = async (
    claimAmount: BigNumber,
    deadline: BigNumber,
    v: number,
    r: string,
    s: string
  ) => {
    if (!walletAddress || !BridgeL2.signer || !wallet) return null;
    if (chainId !== addresses.arbitrumNetworkID) return null;
    try {
      const BridgeL2WithSigner = BridgeL2.connect(wallet as JsonRpcSigner);
      return BridgeL2WithSigner.claim(claimAmount, deadline, v, r, s);
    } catch (err) {
      console.log('Bridge claim error:', err);
      return null;
    }
  };

  const bridgeUserInfoL2 = async (user: string) => {
    try {
      return await BridgeReadContract.userInfo(user);
    } catch (err) {
      console.log('approve error:', err);
      return null;
    }
  };

  const bridgeTrustedSigner = async (user: string) => {
    try {
      return await BridgeReadContract.trustedSigner(user);
    } catch (err) {
      console.log('approve error:', err);
      return null;
    }
  };

  const balanceOfErc20 = async (
    contractAddress: string,
    walletAddress: string,
    layer: string = 'L2'
  ) => {
    const rpcURL = layer === 'L2' ? addresses.arbitrumRpcURL : addresses.rpcURL;
    const erc20ReadContract = new Contract(
      contractAddress,
      abis.IERC20,
      new providers.JsonRpcProvider(rpcURL)
    );
    const balance = await erc20ReadContract.balanceOf(walletAddress);
    const decimal = await erc20ReadContract.decimals();
    return utils.formatUnits(balance.toString(), decimal);
  };

  return (
    <Context.Provider
      value={{
        createProposal,
        particpiate,
        getAllProposals,
        getVoteCountForAllProposals,
        proposalInfo,
        proposalList,
        getWinningProposal,
        stake,
        approve,
        allowance,
        unstake,
        claimRewards,
        userClaimAmount,
        getUserVotingShare,
        isUserEligibleToClaim,
        getProposalWon,
        isUserVoted,
        userVoteCount,
        totalUserVoted,
        getProposalVoteCount,
        stakeAmount,
        balanceOf,
        totalSupply,
        erc20TotalSupply,
        userCount,
        proposalCount,
        round,
        voteStartTime,
        resultTime,
        vaultNonces,
        vaultDeposit,
        vaultWithdraw,
        vaultUserInfo,
        vaultTrustedSigner,
        balanceOfL2,
        bridgeNoncesL2,
        bridgeMoveBackL2,
        bridgeClaimL2,
        bridgeUserInfoL2,
        bridgeTrustedSigner,
        balanceOfErc20,
        readVoteStartTime,
        readResultTime,
      }}
    >
      {children}
    </Context.Provider>
  );
};

export default Provider;
