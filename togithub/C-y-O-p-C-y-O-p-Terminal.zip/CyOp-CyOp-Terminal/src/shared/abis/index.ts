import IERC20 from "./IERC20.json";
import DAO from "./DAO.json";
import Bridge from "./Bridge.json";
import Vault from "./Vault.json";

const abis = {
  CyOp: IERC20,
  IERC20: IERC20,
  DAO: DAO,
  Bridge: Bridge,
  Vault: Vault,
};

export default abis;
