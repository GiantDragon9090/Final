const addresses = {
  CyOp: process.env.REACT_APP_CYOP_ADDRESS!,
  DAO: process.env.REACT_APP_DAO_ADDRESS!,
  Protocol: process.env.REACT_APP_PROTOCOL_ADDRESS!,
  Vault: process.env.REACT_APP_VAULT_ADDRESS!,
  networkID: process.env.REACT_APP_NETWORK_ID!,
  networkName: process.env.REACT_APP_NETWORK_NAME!,
  rpcURL: process.env.REACT_APP_NETWORK_RPC_URL!,
  arbitrumDAO: process.env.REACT_APP_ARBITRUM_DAO_ADDRESS!,
  arbitrumNetworkID: process.env.REACT_APP_ARBITRUM_NETWORK_ID!,
  arbitrumNetworkName: process.env.REACT_APP_ARBITRUM_NETWORK_NAME!,
  arbitrumRpcURL: process.env.REACT_APP_ARBITRUM_RPC_URL!,
  arbitrumCyOp: process.env.REACT_APP_ARBITRUM_CYOP_ADDRESS!,
  arbitrumBridge: process.env.REACT_APP_ARBITRUM_BRIDGE_ADDRESS!,
  // exchange token
  USDT: process.env.REACT_APP_USDT_ADDRESS!,
  USDC: process.env.REACT_APP_USDC_ADDRESS!,
  WETH: process.env.REACT_APP_WETH_ADDRESS!,
  CULT: process.env.REACT_APP_CULT_ADDRESS!,
};

export default addresses;
