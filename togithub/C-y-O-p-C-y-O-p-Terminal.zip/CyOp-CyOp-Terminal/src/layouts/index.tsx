import { useState, useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import StatusPanel from './status-panel';
import CommandPanel from 'components/command-panel';
import NavPanel from './nav-panel';
import ActiveEvent from 'pages/protocol/active-event';
import PreviousEvent from 'pages/protocol/previous-event';
import VoidPage from 'pages/protocol/void-page';
import StakingPage from 'pages/protocol/staking-page';
import WalletPage from 'pages/protocol/wallet-page';
import EasterEgg from 'pages/protocol/easter-egg';
import Footer from 'components/footer-panel';
import DatabasePage from '../pages/database';
import Modules from '../pages/modules';
import Metagrid from '../pages/metagrid';
import SystemStatusPanel from './system-status-panel';
import ExchangePage from '../pages/exchange';

export const AppLayout = () => {
  const location = useLocation();
  const [cmd, setCmd] = useState('');
  const [isCmdVisible, setCmdVisible] = useState(false);
  const [isProtocol, setProtocol] = useState(false);

  const onCompleteCmd = () => {
    setCmdVisible(true);
  };

  useEffect(() => {
    setCmdVisible(false);
    if (location.pathname === '/protocol/active-event') {
      setCmd('searching:\\active event>file_loaded');
    } else if (location.pathname === '/protocol/previous-event') {
      setCmd('searching:\\previous event>file_loaded');
    } else if (location.pathname === '/protocol/void') {
      setCmd('searching:\\void>sucked in');
    } else if (location.pathname === '/protocol/staking') {
      setCmd('searching:\\staking>control_loaded');
    } else if (location.pathname === '/protocol/wallet') {
      setCmd('searching:\\wallet>control_loaded');
    } else if (location.pathname === '/protocol/easter-egg') {
      setCmd('triggered:\\easter egg>file_found');
    } else if (location.pathname === '/database') {
      setCmd('booting:\\terminal>database_loaded');
    } else if (location.pathname === '/modules') {
      setCmd('searching:\\modules>plugged in');
    } else if (location.pathname === '/metagrid') {
      setCmd('searching:\\metagrid>simulation_loaded');
    } else if (location.pathname === '/exchange') {
      setCmd('searching:\\exchange>control_loaded');
    }
  }, [location]);

  const handleNavigate = (link: string) => {
    setCmdVisible(false);
  };

  const setProtocolPage = (selected: boolean) => {
    setProtocol(selected);
  };
  
  return (
    <div className="co-main d-flex flex-column">
      <div className="co-main-container d-flex h-100 overflow-hidden">
        <div className="co-left-panel d-flex flex-column">
          <div className="d-flex flex-column flex-1 overflow-hidden">
			      {isCmdVisible && (
              <Routes>
                <Route path={`/database`} element={<DatabasePage />} />
                <Route
                  path={`/protocol/active-event`}
                  element={<ActiveEvent />}
                />
                <Route
                  path={`/protocol/previous-event`}
                  element={<PreviousEvent />}
                />
                <Route path={`/protocol/void`} element={<VoidPage />} />
                <Route path={`/protocol/staking`} element={<StakingPage />} />
                <Route path={`/protocol/wallet`} element={<WalletPage />} />
                <Route path={`/protocol/easter-egg`} element={<EasterEgg />} />

                <Route path={`/modules`} element={<Modules />} />
                <Route path={`/metagrid`} element={<Metagrid />} />
                <Route path={`/exchange`} element={<ExchangePage />} />
              </Routes>
            )}
          </div>
          <CommandPanel cmd={cmd} onComplete={onCompleteCmd} />
        </div>

        <div className="co-right-panel">
          {isProtocol && <StatusPanel isStart={isCmdVisible} />}
          {!isProtocol && <SystemStatusPanel />}
          <NavPanel onNavigate={handleNavigate} setProtocolPage={setProtocolPage} />
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default AppLayout;
