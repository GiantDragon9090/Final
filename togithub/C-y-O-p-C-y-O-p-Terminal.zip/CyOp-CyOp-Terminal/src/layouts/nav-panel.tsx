import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import ConnectWallet from 'pages/protocol/connect-wallet';
import useWeb3 from 'shared/hooks/useWeb3';
import addresses from 'shared/addresses';

interface IPageRoute {
  link: string;
  label: string;
  path: string;
  children?: IPageRoute[];
}

const PAGES: IPageRoute[] = [
  {
    link: '/database',
    label: 'Database',
    path: '/database',
  },
  {
    link: '',
    label: 'Protocol',
    path: '/',
    children: [
      {
        link: '/protocol/active-event',
        label: 'Active event',
        path: '/active event',
      },
      {
        link: '/protocol/previous-event',
        label: 'Previous event',
        path: '/previous event',
      },
      {
        link: '/protocol/void',
        label: 'Void',
        path: '/void',
      },
      {
        link: '/protocol/staking',
        label: 'Staking',
        path: '/staking',
      },
      {
        link: '/protocol/wallet',
        label: 'Wallet',
        path: '/wallet',
      },
    ],
  },
  {
    link: '/modules',
    label: 'Modules',
    path: '/modules',
  },
  {
    link: '/metagrid',
    label: 'Metagrid',
    path: '/metagrid',
  },
  {
    link: '/exchange',
    label: 'Exchange',
    path: '/exchange',
  },
];

interface INavPanel {
  onNavigate?: (url: string) => void;
  setProtocolPage?: (selected: boolean) => void;
}

export const NavPanel = ({ onNavigate, setProtocolPage }: INavPanel) => {
  const { connected, chainId } = useWeb3();

  const location = useLocation();
  const navigate = useNavigate();
  const [currentPage, setCurrentPage] = useState<IPageRoute>();
  const [protocolSelected, setProtocolSelected] = useState(false);
  const [protocolSubPage, setProtocolSubPage] = useState(false);
  const [isConnecting, setConnecting] = useState(false);
  const [redirectLink, setRedirectLink] = useState('');

  useEffect(() => {
    const updateCurrentPage = () => {
      PAGES.forEach((page) => {
        if (page.link === location.pathname) {
          setCurrentPage(page);
          setProtocolSubPage(false);
          setProtocolSelected(false);
          if (setProtocolPage) setProtocolPage(false);
        }
        if (page.children) {
          page.children.forEach((subPage) => {
            if (subPage.link === location.pathname) {
              setCurrentPage(subPage);
              setProtocolSubPage(true);
              setProtocolSelected(true);
              if (setProtocolPage) setProtocolPage(true);
            }
          });
        }
      });
    };
    updateCurrentPage();
  }, [location, setProtocolPage]);

  const onClickNavLink = (link: string, index?: number) => {
    if (location.pathname === link) return;
    if (index === 1) {
      setProtocolSelected(!protocolSelected);
      return;
    }
    if (onNavigate) {
      onNavigate(link);
    }
    navigate(link);
  };

  const onClickNavSub = (link: string) => {
    if (
      !connected ||
      (chainId !== addresses.networkID &&
        chainId !== addresses.arbitrumNetworkID)
    ) {
      setRedirectLink(link);
      setConnecting(true);
    } else {
      onClickNavLink(link);
    }
  };

  return (
    <div className="co-nav-panel">
      <div className="co-nav-status px-2">
        {`Browser - ${currentPage?.path}`}
      </div>
      <div className="co-nav-list flex-1">
        {isConnecting && (
          <ConnectWallet
            redirectLink={redirectLink}
            setRedirectLink={setRedirectLink}
          />
        )}
        {!isConnecting &&
          PAGES.map((page, index) => (
            <React.Fragment key={`navlink-${index}-${page.link}`}>
              <div
                className={`co-nav-link px-2 ${
                  index === 1
                    ? protocolSubPage
                      ? 'current'
                      : ''
                    : currentPage?.link === page.link
                    ? 'current'
                    : ''
                }`}
                onClick={() => onClickNavLink(page.link, index)}
              >
                {page.label}
              </div>
              {protocolSelected &&
                index === 1 &&
                page.children?.map((page, index) => (
                  <div
                    className={`co-nav-link px-2 mx-3 ${
                      currentPage?.link === page.link ? 'current' : ''
                    }`}
                    onClick={() => onClickNavSub(page.link)}
                    key={`navlink-${index}-${page.link}`}
                  >
                    {page.label}
                  </div>
                ))}
            </React.Fragment>
          ))}
      </div>
    </div>
  );
};

export default NavPanel;
