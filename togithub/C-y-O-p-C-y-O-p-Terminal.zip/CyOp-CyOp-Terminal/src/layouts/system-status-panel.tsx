import { useState, useEffect } from 'react'
import YouTube from 'react-youtube';

interface videoResponse {
	id: string
}

export const SystemStatusPanel = () => {

	const [isLoading, setIsLoading] = useState(false) // eslint-disable-line
	const [item, setItem] = useState<videoResponse>(Object)

	const possibleVideos = [
		{ id: 'e6jff1pK3Eg' },
		{ id: 'onZmKwlsquM' },
		{ id: 'DSKsGotoiSQ' },
		{ id: 'YyEkGg-I6p0' }
	]

	useEffect(() => {
		let cur_item =
			possibleVideos[Math.floor(Math.random() * possibleVideos.length)]

		setItem(cur_item)
	}, []) // eslint-disable-line

	return (
		<div className="co-status-panel" >
			<div className="section-system-status">
				<div className="protocol-progress-label px-2">
					System Status
				</div>
			</div>

			{isLoading &&
				<></>
			}
			{!isLoading &&
				<YouTube
					videoId={item.id ? item.id : ''}
					opts={{
						height: '300',
						width: '520',
						playerVars: {
							autoplay: 0,
							controls: 0
						}
					}}
				/>
			}
		</div >
	)
}

export default SystemStatusPanel