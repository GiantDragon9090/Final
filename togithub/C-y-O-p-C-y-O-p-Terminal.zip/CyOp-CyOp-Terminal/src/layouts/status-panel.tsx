import { useState, useEffect } from 'react';
import { useWeb3 } from 'shared/hooks';
import useContracts from 'shared/hooks/useContracts';
import { formatUnits, str2number } from 'helpers/utils';
import ProgressBarStatus from 'components/progressbar-status';
// import { date2str, time2str } from 'helpers/utils';
import ProgressBarProtocol from 'components/progressbar-protocol';
import { BigNumber } from 'ethers';
import addresses from 'shared/addresses';

interface IStatusPanel {
  isStart?: boolean;
}
const detailUpdateInterval = 600000;
export const StatusPanel = ({ isStart = true }: IStatusPanel) => {
  const [initatedDate, setInitiatedDate] = useState<Date>(new Date()); // eslint-disable-line

  const [protocolFund, setProtocolFund] = useState<number>();
  const [marketBuy, setMarketBuy] = useState<number>();
  const [luckyStaker, setLuckyStaker] = useState<number>();
  const [liquidity, setLiquidity] = useState<number>();

  const [protocolProgress, setProtocolProgress] = useState<number>();

  const { readProtocolBalance, chainId } = useWeb3();

  const { readVoteStartTime, readResultTime } = useContracts();

  useEffect(() => {
    if (isStart) {
      getDetails();
      const timer = setInterval(getDetails, detailUpdateInterval);

      setProtocolProgress(0);

      return () => {
        clearInterval(timer);
      };
    }
  }, [isStart]); // eslint-disable-line

  const getDetails = async () => {
    if (
      !readProtocolBalance ||
      !readVoteStartTime ||
      !readResultTime ||
      (chainId !== addresses.networkID &&
        chainId !== addresses.arbitrumNetworkID)
    ) {
      return;
    }
    try {
      const balance: BigNumber = await readProtocolBalance();
      let amount = '';
      if (balance) {
        amount = formatUnits(balance, 18, false);
      } else {
        amount = '0';
      }
      let totalFund = str2number(amount);
      setProtocolFund(Math.floor(totalFund));
      setMarketBuy(Math.floor(totalFund * 0.8));
      setLuckyStaker(Math.floor(totalFund * 0.1));
      setLiquidity(Math.floor(totalFund * 0.1));

      // get vote progress
      let startTime = await readVoteStartTime();
      if (startTime) {
        let _startTime = startTime.toNumber();
        if (_startTime > 0) {
          // console.log('startTime: ', startTime.toString());
          let duration = await readResultTime();
          // console.log('Duration', duration);
          if (duration) {
            let _duration = duration.toNumber();
            // console.log('duration: ', duration.toString());

            let now = Date.now() / 1000;
            // console.log('now: ', now);

            let elapsed = now - _startTime;

            let progress = 0;
            if (_duration > 0 && elapsed > 0) {
              progress = elapsed / _duration;
            }
            progress = Math.min(progress, 1);

            let progressPercent = progress * 100;
            console.log('progress: ', progressPercent + '%');

            setProtocolProgress(progressPercent);
          }
        }
      }
    } catch (e) {
      console.log(e);
    }
  };

  return (
    <div className="co-status-panel">
      <div className="section-progress">
        <div className="d-flex justify-content-between">
          <div className="d-flex">
            <div className="co-progress-label">Protocol fund</div>
            <ProgressBarStatus
              total={protocolFund}
              value={protocolFund}
              unit="eth"
              visible={false}
            />
          </div>

          <div className="ms-2 flex-0" style={{ lineHeight: '20px' }}>
            <div>Initiated</div>
            <div className="text-desc">
              2022-06-16
              {/*               {date2str(initatedDate)} <br />
              {time2str(initatedDate)}
 */}{' '}
            </div>
          </div>
        </div>

        <div className="d-flex">
          <div className="co-progress-label">Market buy</div>
          <ProgressBarStatus
            total={protocolFund}
            value={marketBuy}
            unit="eth"
          />
        </div>

        <div className="d-flex">
          <div className="co-progress-label">Lucky user</div>
          <ProgressBarStatus
            total={protocolFund}
            value={luckyStaker}
            unit="eth"
          />
        </div>

        <div className="d-flex">
          <div className="co-progress-label">CyOp liquidity</div>
          <ProgressBarStatus
            total={protocolFund}
            value={liquidity}
            unit="eth"
          />
        </div>
      </div>

      <div className="section-protocol-progress">
        <div className="protocol-progress-label px-2">Protocol progress</div>
        <ProgressBarProtocol progress={protocolProgress} />
      </div>
    </div>
  );
};

export default StatusPanel;
