
export const TEXT_ANIMATION_SPEED = 3;