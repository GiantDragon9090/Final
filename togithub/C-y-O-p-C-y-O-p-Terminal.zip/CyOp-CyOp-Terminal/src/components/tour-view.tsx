import { useNavigate } from "react-router-dom";
import TourArrow from "./tour-arrow";
import styled from "styled-components";

export const WindowMode = styled.div`
  position: absolute;
  overflow-y: scroll;
  height: calc(100vh - 80px);
  @media (max-width: 576px) {
    width: 80vw !important;
    margin-top: 80px !important;
    margin-left: 11vw !important;
  }
  @media (max-width: 991px) {
    width: 450px;
    height: calc(100vh - 50px);
    margin-top: 50px;
    margin-left: calc(50% - 225px);
  }
  @media (min-width: 992px) {
    width: 470px;
    margin-top: 80px;
    margin-left: calc(50vw - 235px);
  }
`;
export const VideoMode = styled.div`
  @media (max-width: 576px) {
    width: 80vw !important;
    height: 44vw !important;
    max-height: 44vw !important;
  }
  @media (max-width: 991px) {
    width: 450px;
    height: 253px;
    max-height: 253px;
  }
  @media (min-width: 992px) {
    width: 465px;
    height: 264px;
    max-height: 264px;
  }
`;

export const TourView = () => {
  const navigate = useNavigate()

  return (
    <div className="co-tour-landing" onClick={ () => navigate("/tour_one") }>
      <TourArrow label={"take a tour"} />
    </div>
  )
}

export default TourView