import React, { ForwardRefRenderFunction, forwardRef, ReactNode, CSSProperties } from 'react';
import { useAudio } from "react-awesome-audio";

const sndAction = require('assets/audio/action.mp3').default

export interface ButtonProps {
    className?: string,
    onClick?: () => void,
    onChange?: (v : any) => void,
    disabled?: boolean,
    style?: CSSProperties
    children?: ReactNode | undefined,
}

const Button : ForwardRefRenderFunction<HTMLDivElement, ButtonProps> = ({
    className='',
    disabled = false, 
    onClick,
    style,
    children
}, ref) => {
    
    const { play } = useAudio({
        src: sndAction,
    });

    return (
        <div 
            ref={ref}
            className={`co-button ${className} ${disabled ? " disabled" : ""}`} 
            onClick={(e) => {
                if( disabled ) return;
                play()
                if( onClick ) {
                    setTimeout(() => {
                        onClick()
                    }, 300)
                }
            }}
            style={style}
        >
            {children}
        </div>
    );
}

export default forwardRef(Button);
