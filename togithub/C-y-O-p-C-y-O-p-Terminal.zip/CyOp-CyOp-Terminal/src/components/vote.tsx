import { useState, useEffect } from 'react';
import { BigNumber, utils } from 'ethers';
import { toast } from 'react-toastify';
import { formatUnits, parseCommified, toFixedNoRounding } from 'helpers/utils';
import Button from 'components/base/button';
import useContracts from 'shared/hooks/useContracts';
import useWeb3 from 'shared/hooks/useWeb3';
import Loading from './loading';

interface IVote {
  totalVote: number;
  address: string;
  onUpdate?: () => void;
}

export const Vote = ({ totalVote, address, onUpdate }: IVote) => {
  const [isVoting, setVoting] = useState<boolean>(false);
  const [voteProcessing, setVoteProcessing] = useState<boolean>(false);
  const [currentVote, setCurrentVote] = useState('');
  const [balanceLoading, setBalanceLoading] = useState(false);
  const [balance, setBalance] = useState<BigNumber>(BigNumber.from(0));
  const [userVotedBalance, setUserVotedBalance] = useState<BigNumber>(
    BigNumber.from(0)
  );
  const { particpiate, stakeAmount, round, userVoteCount } = useContracts();
  const { wallet, walletAddress } = useWeb3();

  useEffect(() => {
    (async () => {
      if (round && walletAddress && userVoteCount) {
        const activeRound = await round();
        if (activeRound !== null) {
          const voteCount = await userVoteCount(walletAddress, activeRound);
          if (voteCount !== null) {
            setUserVotedBalance(voteCount);
          }
        }
      }
    })();
  }, [round, userVoteCount, walletAddress]);

  useEffect(() => {
    (async () => {
      if (isVoting && walletAddress && !!stakeAmount && !!wallet) {
        setBalanceLoading(true);
        const stakedAmount = await stakeAmount(walletAddress);
        if (stakedAmount !== null) {
          const newBalance = stakedAmount.sub(userVotedBalance);
          setBalance(newBalance);
          setBalanceLoading(false);
        }
      }
    })();
  }, [isVoting, stakeAmount, userVotedBalance, wallet, walletAddress]);

  const onClickVote = () => {
    setVoting(true);
  };

  const onClickSaveVote = async () => {
    if (voteProcessing) return;
    if (balance.lte(0)) {
      return toast.error('You have 0 vote balance');
    }
    if (particpiate && Number(currentVote) > 0) {
      try {
        setVoteProcessing(true);
        const tx = await particpiate(
          address,
          utils.parseUnits(currentVote.toString(), 9)
        );
        // wait for transaction
        await tx.wait();
        toast.success('Voted successfully');
        setUserVotedBalance(userVotedBalance.add(BigNumber.from(currentVote)));
        setCurrentVote('');
        setVoteProcessing(false);
        setVoting(false);
        if (onUpdate) {
          onUpdate();
        }
      } catch (e: any) {
        console.log(e);
        toast.error(`Something went wrong. ${e?.data?.message ? e?.data?.message : ""}`);
        setVoteProcessing(false);
        setVoting(false);
      }
    }
  };

  const onClickCancelVote = () => {
    setVoting(false);
    setCurrentVote('');
  };

  const displayBalance = formatUnits(balance, 9);

  return (
    <>
      {isVoting ? (
        <div className="voting-box">
          <div className="co-button w-100 button-label" style={{ marginTop: "-1px"}}>vote</div>
          <div className="d-flex justify-content-between pt-2">
            <span className="text-desc ps-2">input</span>
            <div>
              <span className="pe-2 pt-1" style={{ fontSize: '12px' }}>
                {balanceLoading && <Loading />}
                {!balanceLoading && (
                  <>[{toFixedNoRounding(parseCommified(displayBalance))}]</>
                )}
              </span>
              <span
                className="pe-2 pt-1 text-danger"
                style={{ fontSize: '12px' }}
                onClick={() => {
                  setCurrentVote(toFixedNoRounding(parseCommified(displayBalance)).toString());
                }}
              >
                max{' '}
              </span>
            </div>
          </div>
          <div className="py-2">
            <input
              type="number"
              min={0}
              className="text-desc stake-txt-input ps-2"
              placeholder="0.0"
              value={currentVote}
              onChange={(event) => setCurrentVote(event.target.value)}
            />

            {/* <div className="ms-1 text-end" style={{ width: `${labelWidth}px` }}>
              {commaValue(userVotedBalance)}/{commaValue(balance)}
            </div> */}

            <div className="pt-3">
              <Button className="ms-2" onClick={onClickSaveVote}>
                {voteProcessing && (
                  <i
                    className="fa fa-repeat fa-spin"
                    aria-hidden="true"
                    style={{ fontSize: '15px' }}
                  ></i>
                )}{' '}
                lock in
              </Button>
              <Button className="ms-1" onClick={onClickCancelVote}>
                cancel
              </Button>
            </div>
          </div>
        </div>
      ) : (
        <Button className="button-label button-vote" onClick={onClickVote}>vote</Button>
      )}
    </>
  );
};

export default Vote;
