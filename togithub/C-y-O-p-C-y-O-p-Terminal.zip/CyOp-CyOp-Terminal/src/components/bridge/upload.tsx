import { useState, useEffect } from 'react';
import { ethers, BigNumber } from 'ethers';
import { toast } from 'react-toastify';
import { useWeb3, useContracts } from 'shared/hooks';
import addresses from 'shared/addresses';
import { toFixedNoRounding, formatUnits, parseCommified } from 'helpers/utils';

interface VaultUserData {
  deposited: BigNumber;
  withdrawn: BigNumber;
}

interface BridgeUserData {
  burned: BigNumber;
  claimed: BigNumber;
}

const detailUpdateInterval = 5000;

function Upload({ play }: any) {
  const {
    approve,
    allowance,
    balanceOf,
    vaultDeposit,
    vaultWithdraw,
    vaultUserInfo,
    bridgeUserInfoL2,
  } = useContracts();

  const { walletAddress, wallet, chainId, arbBridge, switchNetwork } =
    useWeb3();
  const [vaultUserInfoData, setVaultUserInfoData] = useState<VaultUserData>({
    deposited: BigNumber.from(0),
    withdrawn: BigNumber.from(0),
  });
  const [bridgeUserInfoData, setBridgeUserInfoData] = useState<BridgeUserData>({
    burned: BigNumber.from(0),
    claimed: BigNumber.from(0),
  });
  const [enableWithdraw, setEnableWithdraw] = useState(false);
  const [insufficient, setInsufficient] = useState(false);
  const [inputAmount, setInputAmount] = useState('0.0');
  const [tokenBalance, setTokenBalance] = useState('0.0');
  const [approved, setApproved] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [withdrawProcessing, setWithdrawProcessing] = useState(false);
  const [withdrawHash, setWithdrawHash] = useState(null);
  const [depositHash, setDepositHash] = useState(null);
  const [coinType, setCoinType] = useState('CyOp');

  useEffect(() => {
    try {
      (async () => {
        if (allowance && walletAddress && chainId === addresses.networkID) {
          if (coinType === 'CyOp') {
            const amount = await allowance(
              walletAddress,
              addresses.Vault,
              'L1'
            );
            if (amount !== null) {
              if (amount.gt('0')) {
                setApproved(true);
                return;
              }
            }
            setApproved(false);
          } else {
            setApproved(true);
          }
        }
      })();
    } catch (e) {
      // TODO: handle error
      console.log(e);
    }
  }, [allowance, walletAddress, coinType, chainId]);

  useEffect(() => {
    const checkValidation = () => {
      let balance = parseCommified(tokenBalance);
      let amount = parseFloat(inputAmount);

      if (amount === null) {
        return true;
      }
      if (isNaN(amount) || !amount) {
        amount = 0;
      }
      if (amount > balance) {
        setInsufficient(false);
      } else {
        setInsufficient(true);
      }
    };
    checkValidation();
  }, [tokenBalance, inputAmount]);

  useEffect(() => {
    const getDetails = async () => {
      try {
        if (
          !walletAddress ||
          !wallet ||
          !balanceOf ||
          !vaultUserInfo ||
          !bridgeUserInfoL2
        ) {
          return;
        }
        // get account CyOp balance
        if (coinType === 'eth') {
          const balance = await wallet.getBalance();
          setTokenBalance(formatUnits(balance, 18));
        } else {
          const balance = await balanceOf('L1');
          if (balance) {
            let amount = formatUnits(balance, 9);
            setTokenBalance(amount);
          }
        }
        const vaultBalance = await vaultUserInfo(walletAddress);
        if (vaultBalance) {
          setVaultUserInfoData({
            deposited: vaultBalance.deposited,
            withdrawn: vaultBalance.withdrawn,
          });
        }
        const bridgeInfo = await bridgeUserInfoL2(walletAddress);
        if (bridgeInfo) {
          setBridgeUserInfoData({
            burned: bridgeInfo.burned,
            claimed: bridgeInfo.claimed,
          });
          const withdrawAmount = bridgeInfo.burned.sub(vaultBalance.withdrawn);

          if (withdrawAmount && withdrawAmount?.gt(0)) {
            setEnableWithdraw(true);
          }
        }
      } catch (e) {
        console.log(e);
      }
    };
    getDetails();
    const timer = setInterval(getDetails, detailUpdateInterval);

    return () => {
      clearInterval(timer);
    };
  }, [
    balanceOf,
    walletAddress,
    vaultUserInfo,
    bridgeUserInfoL2,
    coinType,
    wallet,
    chainId,
  ]);

  const onClickApprove = async () => {
    play();
    // try approve
    if (approve && coinType === 'CyOp' && chainId === addresses.networkID) {
      try {
        setProcessing(true);
        const approved = await approve(
          addresses.Vault,
          ethers.constants.MaxUint256,
          'L1'
        );
        if (approved) {
          setApproved(true);
          setProcessing(false);
        }
      } catch (e) {
        setApproved(false);
      } finally {
        setProcessing(false);
      }
    }
  };

  const onClickVaultDeposit = async () => {
    play();
    setDepositHash(null);
    let amount = parseCommified(inputAmount);
    if (isNaN(amount) || !amount) {
      return;
    }
    if (coinType === 'CyOp') {
      let nativeAmount = ethers.utils.parseUnits(amount.toString(), 9);
      if (vaultDeposit) {
        try {
          setProcessing(true);
          const result = await vaultDeposit(nativeAmount);
          setDepositHash(result.hash);
          // wait for transaction confirmation
          await result.wait();
          toast.success('CyOp Deposit successfull. Switching to arbitrum');
          switchNetwork(addresses.arbitrumNetworkID);
        } catch (e) {
          // handle errors
          console.log(e);
          toast.error('Something went wrong!');
        } finally {
          setProcessing(false);
          setInputAmount('');
        }
      }
    } else if (coinType === 'eth') {
      let nativeAmount = ethers.utils.parseUnits(amount.toString(), 18);
      if (arbBridge) {
        try {
          setProcessing(true);
          const result = await arbBridge.depositETH(nativeAmount);
          setDepositHash(result.hash);
          await result.wait();
          toast.success('Eth Deposit successfull.');
          switchNetwork(addresses.arbitrumNetworkID);
        } catch (e) {
          toast.error('Something went wrong!');
          console.log(e);
        } finally {
          setProcessing(false);
          setInputAmount('');
        }
      }
    }
  };

  const onClickVaultWithdraw = async () => {
    play();
    setWithdrawHash(null);
    if (coinType === 'CyOp') {
      const withdrawAmount = bridgeUserInfoData.burned.sub(
        vaultUserInfoData.withdrawn
      );
      if (
        walletAddress &&
        withdrawAmount.gt(0) &&
        vaultWithdraw &&
        chainId === addresses.networkID
      ) {
        try {
          setWithdrawProcessing(true);
          const signReq = await fetch(process.env.REACT_APP_SIGN_API!, {
            method: 'POST',
            body: JSON.stringify({
              account: walletAddress,
              amount: withdrawAmount.toString(),
              chainId: chainId,
            }),
            headers: {
              'Content-Type': 'application/json',
            },
          });
          const signData = await signReq.json();
          if (
            signData &&
            signData.v &&
            signData.r &&
            signData.s &&
            signData.deadline
          ) {
            const result = await vaultWithdraw(
              withdrawAmount,
              signData.deadline,
              signData.v,
              signData.r,
              signData.s
            );
            setWithdrawHash(result.hash);
            await result.wait();
            toast.success('Withdrawl successfull.');
          } else {
            // TODO: show error for signature
            alert(`error ${signData.toString()}`);
          }
        } catch (e: any) {
          toast.error(
            `Something went wrong. ${e?.data?.message ? e?.data?.message : ''}`
          );
          console.log(e);
        } finally {
          setWithdrawProcessing(false);
        }
      }
    }
  };

  const onChange = (value: string) => {
    if (isNaN(Number(value))) return;
    // setting value
    setInputAmount(value);
  };

  const toggleCoinType = () => {
    if (coinType === 'eth') {
      setCoinType('CyOp');
    } else {
      setCoinType('eth');
    }
  };

  return (
    <>
      <div className="d-flex justify-content-between pt-2">
        <span className="text-desc ps-2">input</span>
        <div>
          {coinType === 'eth' ? (
            <span className="pe-2 pt-1" style={{ fontSize: '12px' }}>
              [{tokenBalance}]
            </span>
          ) : (
            <span className="pe-2 pt-1" style={{ fontSize: '12px' }}>
              [
              {ethers.utils.commify(
                toFixedNoRounding(parseCommified(tokenBalance), 0)
              )}
              ]
            </span>
          )}
          {coinType === 'eth' ? (
            <span className='text-danger pe-2' style={{ fontSize: '12px' }}
              onClick={() => setInputAmount(ethers.utils.commify(
                toFixedNoRounding(parseCommified(tokenBalance), 4)
              ))}
            >
              max{' '}
            </span>
          ) : (
            <span className='text-danger pe-2' style={{ fontSize: '12px' }}
              onClick={() => setInputAmount(ethers.utils.commify(
                toFixedNoRounding(parseCommified(tokenBalance), 0)
              ))}
            >
              max{' '}
            </span>
          )}
        </div>
      </div>
      <div className="d-flex justify-content-between py-2">
        <input
          className="text-desc stake-txt-input ps-2"
          placeholder="0.00"
          value={inputAmount}
          onChange={(event) => onChange(event.target.value)}
        />
        <span className="pe-2" onClick={() => toggleCoinType()}>
          {coinType}▼
        </span>
      </div>
      {processing && (
        <>
          <div className="button-label" style={{ opacity: '0.5' }}>
            <i
              className="fa fa-repeat fa-spin"
              aria-hidden="true"
              style={{ fontSize: '15px' }}
            ></i>
            &nbsp;processing
          </div>
        </>
      )}
      {!processing && !approved && (
        <div className="button-label" onClick={onClickApprove}>
          approve
        </div>
      )}
      {!processing && approved && insufficient && (
        <div className="button-label" onClick={onClickVaultDeposit}>
          send to arbitrum
        </div>
      )}
      {!processing && approved && !insufficient && (
        <div className="button-label" style={{ background: '#FF00A0' }}>
          Insufficient balance
        </div>
      )}
      {!processing && approved && insufficient && coinType === 'eth' && (
        <p>Sending eth to Arbitrum can take 10-15min until it arrives.</p>
      )}
      {depositHash && (
        <>
          <div>
            <a
              href={`${process.env.REACT_APP_ETHERSCAN_TX}${depositHash}`}
              target="_blank"
              rel="noreferrer"
              className="text-danger pt-2 ps-2"
            >
              {processing && <>Waiting for confirmation.</>}
              {!processing && <>Your last transaction.</>}
            </a>
            {processing && (
              <p className="text-danger pt-2 ps-2">
                Please do not close the site.
              </p>
            )}
          </div>
        </>
      )}
      {coinType === 'CyOp' && (
        <>
          {/*   {vaultUserInfoData.withdrawn && (
            <>
              <div className="pt-2 ps-2">Vault Deposited amount:</div>
              <div className="text-desc pt-1 ps-2">
                {vaultUserInfoData.deposited} CyOp
              </div>
            </>
          )}
          {vaultUserInfoData.withdrawn && (
            <>
              <div className="pt-2 ps-2">Vault Withdrawn amount:</div>
              <div className="text-desc pt-1 ps-2">
                {vaultUserInfoData.withdrawn} CyOp
              </div>
            </>
          )} */}
          {bridgeUserInfoData.burned.gt('0') &&
            !vaultUserInfoData.withdrawn.eq(bridgeUserInfoData.burned) && (
              <>
                <div className="pt-2 ps-2">Claimable token:</div>
                <div className="text-desc pt-1 ps-2">
                  {formatUnits(
                    bridgeUserInfoData.burned?.sub(vaultUserInfoData.withdrawn),
                    9
                  )}{' '}
                  CyOp
                </div>
              </>
            )}
          <br />
          {withdrawProcessing && (
            <div className="button-label" style={{ opacity: '0.5' }}>
              <i
                className="fa fa-repeat fa-spin"
                aria-hidden="true"
                style={{ fontSize: '15px' }}
              ></i>
              &nbsp;processing
            </div>
          )}
          {!withdrawProcessing &&
            approved &&
            enableWithdraw &&
            coinType === 'CyOp' && (
              <div className="button-label" onClick={onClickVaultWithdraw}>
                Claim
              </div>
            )}
          {withdrawHash && (
            <div>
              <a
                href={`${process.env.REACT_APP_ETHERSCAN_TX}${withdrawHash}`}
                target="_blank"
                rel="noreferrer"
                className="text-danger pt-2 ps-2"
              >
                {withdrawProcessing && <>Waiting for confirmation.</>}
                {!withdrawProcessing && <>Your last transaction.</>}
              </a>
              {withdrawProcessing && (
                <p className="text-danger pt-2 ps-2">
                  Please do not close the site.
                </p>
              )}
            </div>
          )}
        </>
      )}
    </>
  );
}

export default Upload;
