import { useState, useEffect } from 'react';
import { BigNumber, ethers } from 'ethers';
import { toast } from 'react-toastify';
import { useWeb3 } from 'shared/hooks';
import useContracts from 'shared/hooks/useContracts';
import addresses from 'shared/addresses';
import { toFixedNoRounding, parseCommified, formatUnits } from 'helpers/utils';

const detailUpdateInterval = 5000;

interface VaultUserData {
  deposited: BigNumber;
  withdrawn: BigNumber;
}

interface BridgeUserData {
  burned: BigNumber;
  claimed: BigNumber;
}

function Download({ play }: any) {
  const {
    approve,
    allowance,
    balanceOf,
    vaultUserInfo,
    bridgeUserInfoL2,
    balanceOfL2,
    bridgeMoveBackL2,
    bridgeClaimL2,
  } = useContracts();

  const { arbBridge, walletAddress, wallet, chainId, switchNetwork } =
    useWeb3();
  const [vaultUserInfoData, setVaultUserInfoData] = useState<VaultUserData>({
    deposited: BigNumber.from(0),
    withdrawn: BigNumber.from(0),
  });
  const [bridgeUserInfoData, setBridgeUserInfoData] = useState<BridgeUserData>({
    burned: BigNumber.from(0),
    claimed: BigNumber.from(0),
  });
  const [enableClaim, setEnableClaim] = useState(false);
  const [insufficient, setInsufficient] = useState(false);
  const [inputAmount, setInputAmount] = useState('');
  const [tokenBalance, setTokenBalance] = useState('0');
  const [approved, setApproved] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [claimProcessing, setClaimProcessing] = useState(false);
  const [claimHash, setClaimHash] = useState(null);
  const [moveBackHash, setMoveBackHash] = useState(null);
  const [coinType, setCoinType] = useState('CyOp');

  useEffect(() => {
    (async () => {
      if (
        allowance &&
        walletAddress &&
        chainId === addresses.arbitrumNetworkID
      ) {
        if (coinType === 'CyOp') {
          const amount = await allowance(
            walletAddress,
            addresses.arbitrumBridge
          );
          if (amount !== null) {
            if (amount.gt('0')) {
              setApproved(true);
              return;
            }
          }
          setApproved(false);
        } else {
          setApproved(true);
        }
      }
    })();
  }, [allowance, walletAddress, coinType, chainId]);

  useEffect(() => {
    const checkValidation = () => {
      let balance = parseCommified(tokenBalance);
      let amount = parseFloat(inputAmount);

      if (amount === null) {
        return true;
      }

      if (isNaN(amount) || !amount) {
        amount = 0;
      }
      if (amount > balance) {
        setInsufficient(false);
      } else {
        setInsufficient(true);
      }
    };
    checkValidation();
  }, [tokenBalance, inputAmount]);

  useEffect(() => {
    const getDetails = async () => {
      try {
        if (
          !wallet ||
          !walletAddress ||
          !balanceOfL2 ||
          !vaultUserInfo ||
          !bridgeUserInfoL2
        ) {
          return;
        }
        // get account CyOp balance
        if (coinType === 'eth') {
          const balance = await wallet.getBalance();
          setTokenBalance(formatUnits(balance, 18));
        } else {
          const balance = await balanceOfL2();
          if (balance) {
            let amount = formatUnits(balance, 9);
            setTokenBalance(amount);
          }
        }
        const vaultBalance = await vaultUserInfo(walletAddress);
        if (vaultBalance) {
          setVaultUserInfoData({
            deposited: vaultBalance.deposited,
            withdrawn: vaultBalance.withdrawn,
          });
        }
        const bridgeInfo = await bridgeUserInfoL2(walletAddress);
        if (bridgeInfo) {
          setBridgeUserInfoData({
            burned: bridgeInfo.burned,
            claimed: bridgeInfo.claimed,
          });
          const claimAmount = vaultBalance.deposited.sub(bridgeInfo.claimed);
          if (claimAmount && claimAmount?.gt(0)) {
            setEnableClaim(true);
          }
        }
      } catch (e) {
        console.log(e);
      }
    };
    getDetails();
    const timer = setInterval(getDetails, detailUpdateInterval);

    return () => {
      clearInterval(timer);
    };
  }, [
    balanceOf,
    walletAddress,
    vaultUserInfo,
    bridgeUserInfoL2,
    balanceOfL2,
    coinType,
    wallet,
  ]);

  const onClickApprove = async () => {
    play();
    if (
      approve &&
      coinType === 'CyOp' &&
      chainId === addresses.arbitrumNetworkID
    ) {
      try {
        setProcessing(true);
        const approved = await approve(
          addresses.arbitrumBridge,
          ethers.constants.MaxUint256
        );
        if (approved) {
          setApproved(true);
        }
      } catch (e) {
        setApproved(false);
      } finally {
        setProcessing(false);
      }
    }
  };

  const onClickMoveBack = async () => {
    play();
    let amount = parseCommified(inputAmount);
    if (isNaN(amount) || !amount) {
      return;
    }
    if (coinType === 'CyOp') {
      let nativeAmount = ethers.utils.parseUnits(amount.toString(), 9);
      if (bridgeMoveBackL2 && chainId === addresses.arbitrumNetworkID) {
        try {
          setProcessing(true);
          const result = await bridgeMoveBackL2(nativeAmount);
          setMoveBackHash(result.hash);
          await result.wait();
          toast.success('CyOp move back to l1 successfull. Switching network');
          switchNetwork(addresses.networkID);
        } catch (e) {
          toast.error('Something went wrong!');
          console.log(e);
        } finally {
          setProcessing(false);
          setInputAmount('');
        }
      }
    } else if (coinType === 'eth') {
      let nativeAmount = ethers.utils.parseUnits(amount.toString(), 18);
      if (arbBridge) {
        try {
          setProcessing(true);
          const result = await arbBridge.withdrawETH(nativeAmount);
          setMoveBackHash(result.hash);
          await result.wait();
          toast.success('Eth move back to l1 successfull. Switching network');
          switchNetwork(addresses.networkID);
        } catch (e) {
          toast.error('Something went wrong!');
          console.log(e);
        } finally {
          setProcessing(false);
          setInputAmount('');
        }
      }
    }
  };

  const onClickBridgeClaim = async () => {
    play();
    setClaimHash(null);
    if (coinType === 'CyOp') {
      const claimAmount = vaultUserInfoData.deposited.sub(
        bridgeUserInfoData.claimed
      );
      if (
        walletAddress &&
        claimAmount.gt(0) &&
        bridgeClaimL2 &&
        chainId === addresses.arbitrumNetworkID
      ) {
        try {
          setClaimProcessing(true);
          const signReq = await fetch(process.env.REACT_APP_SIGN_API!, {
            method: 'POST',
            body: JSON.stringify({
              account: walletAddress,
              amount: claimAmount.toString(),
              chainId: chainId,
            }),
            headers: {
              'Content-Type': 'application/json',
            },
          });
          const signData = await signReq.json();
          if (
            signData &&
            signData.v &&
            signData.r &&
            signData.s &&
            signData.deadline
          ) {
            const result = await bridgeClaimL2(
              claimAmount,
              signData.deadline,
              signData.v,
              signData.r,
              signData.s
            );
            setClaimHash(result.hash);
            await result.wait();
            toast.success('Claimed CyOp Successfull.');
          } else {
            toast.error(`error ${signData.toString()}`);
          }
        } catch (e: any) {
          toast.error(
            `Something went wrong. ${e?.data?.message ? e?.data?.message : ''}`
          );
          console.log(e);
        } finally {
          setClaimProcessing(false);
        }
      }
    }
  };

  const onAmountChange = (value: string) => {
    if (isNaN(Number(value))) return;
    setInputAmount(value);
  };

  const toggleCoinType = () => {
    if (coinType === 'eth') {
      setCoinType('CyOp');
    } else {
      setCoinType('eth');
    }
  };

  return (
    <>
      <div className="d-flex justify-content-between pt-2">
        <span className="text-desc ps-2">input</span>

        <div>
          {coinType === 'eth' ? (
            <span className="pe-2 pt-1" style={{ fontSize: '12px' }}>
              [{tokenBalance}]
            </span>
          ) : (
            <span className="pe-2 pt-1" style={{ fontSize: '12px' }}>
              [
              {ethers.utils.commify(
                toFixedNoRounding(parseCommified(tokenBalance))
              )}
              ]
            </span>
          )}
          {coinType === 'eth' ? (
            <span className='text-danger pe-2' style={{ fontSize: '12px' }}
              onClick={() => setInputAmount(ethers.utils.commify(
                toFixedNoRounding(parseCommified(tokenBalance), 4)
              ))}
            >
              max{' '}
            </span>
          ) : (
            <span className='text-danger pe-2' style={{ fontSize: '12px' }}
              onClick={() => setInputAmount(ethers.utils.commify(
                toFixedNoRounding(parseCommified(tokenBalance), 0)
              ))}
            >
              max{' '}
            </span>
          )}
        </div>
      </div>

      <div className="d-flex justify-content-between py-2">
        <input
          className="text-desc stake-txt-input ps-2"
          placeholder="0.0"
          value={inputAmount}
          onChange={(event) => onAmountChange(event.target.value)}
        />
        <span className="pe-2" onClick={() => toggleCoinType()}>
          {coinType}▼
        </span>
      </div>
      {processing && (
        <div className="button-label" style={{ opacity: '0.5' }}>
          <i
            className="fa fa-repeat fa-spin"
            aria-hidden="true"
            style={{ fontSize: '15px' }}
          ></i>
          &nbsp;processing
        </div>
      )}
      {!processing && !approved && (
        <div className="button-label" onClick={onClickApprove}>
          approve
        </div>
      )}
      {!processing && approved && insufficient && (
        <div className="button-label" onClick={onClickMoveBack}>
          send to ethereum
        </div>
      )}
      {!processing && approved && !insufficient && (
        <div className="button-label" style={{ background: '#FF00A0' }}>
          Insufficient balance
        </div>
      )}
      {moveBackHash && (
        <div>
          <a
            href={`${process.env.REACT_APP_ARBISCAN_TX}${moveBackHash}`}
            target="_blank"
            rel="noreferrer"
            className="text-danger pt-2 ps-2"
          >
            {processing && <>Waiting for confirmation.</>}
            {!processing && <>Your last transaction.</>}
          </a>
          {processing && (
            <p className="text-danger pt-2 ps-2">
              Please do not close the site.
            </p>
          )}
        </div>
      )}
      {!processing && approved && insufficient && coinType === 'eth' && (
        <p className='pt-2'>
          Sending eth from Arbitrum back to the Ethereum Mainnet will take 8
          days. Return to this page to claim your funds later.
        </p>
      )}
      {coinType === 'CyOp' && (
        <>
          {/*           {bridgeUserInfoData.claimed && (
            <>
              <div className="pt-2 ps-2">Bridge Claimed amount:</div>
              <div className="text-desc pt-1 ps-2">
                {bridgeUserInfoData.claimed} CyOp
              </div>
            </>
          )}
          {bridgeUserInfoData.burned && (
            <>
              <div className="pt-2 ps-2">Bridge Burned amount:</div>
              <div className="text-desc pt-1 ps-2">
                {bridgeUserInfoData.burned} CyOp
              </div>
            </>
          )} */}
          {vaultUserInfoData.deposited.gt(0) &&
            !bridgeUserInfoData.claimed.eq(vaultUserInfoData.deposited) && (
              <>
                {' '}
                <div className="pt-2 ps-2">Claimable token:</div>
                <div className="text-desc pt-1 ps-2">
                  {formatUnits(
                    vaultUserInfoData.deposited?.sub(
                      bridgeUserInfoData.claimed
                    ),
                    9
                  )}{' '}
                  CyOp
                </div>
              </>
            )}
          <br />
          {!claimProcessing && approved && enableClaim && (
            <div className="button-label" onClick={onClickBridgeClaim}>
              Claim
            </div>
          )}
          {claimProcessing && (
            <div className="button-label" style={{ opacity: '0.5' }}>
              <i
                className="fa fa-repeat fa-spin"
                aria-hidden="true"
                style={{ fontSize: '15px' }}
              ></i>
              &nbsp;processing
            </div>
          )}
          {claimHash && (
            <>
              <a
                href={`${process.env.REACT_APP_ARBISCAN_TX}${claimHash}`}
                target="_blank"
                rel="noreferrer"
                className="text-danger pt-2 ps-2"
              >
                {claimProcessing && <>Waiting for confirmation.</>}
                {!claimProcessing && <>Your last transaction.</>}
              </a>
              {processing && (
                <p className="text-danger pt-2 ps-2">
                  Please do not close the site.
                </p>
              )}
            </>
          )}
        </>
      )}
    </>
  );
}

export default Download;
