import { useEffect, useState } from 'react';
import { useAudio } from 'react-awesome-audio';
import addresses from 'shared/addresses';
import { useWeb3 } from 'shared/hooks';
import BridgeDownload from './bridge/download';
import BridgeUpload from './bridge/upload';

const sndAction = require('assets/audio/action.mp3').default;

export const WalletLeftPanel = () => {
  const { chainId, switchNetwork } = useWeb3();
  const { play } = useAudio({
    src: sndAction,
  });
  const [activeState, setActiveState] = useState('upload');

  const changeActiveState = (curState: string) => {
    setActiveState(curState);
    play();
    if (curState === 'upload' && chainId !== addresses.networkID) {
      switchNetwork(addresses.networkID);
    }
    if (curState === 'download' && chainId !== addresses.arbitrumNetworkID) {
      switchNetwork(addresses.arbitrumNetworkID);
    }
  };

  useEffect(() => {
    if (chainId === addresses.networkID) {
      setActiveState('upload');
    } else if (chainId === addresses.arbitrumNetworkID) {
      setActiveState('download');
    } else {
      switchNetwork(addresses.networkID);
    }
  }, [chainId, switchNetwork]);

  return (
    <div className="flex-1">
      <div style={{ borderBottom: '3px solid #05CCB2', padding: '5px' }}>
        <div
          className={`switch-label ps-2 ${
            activeState === 'upload' ? 'current' : ''
          }`}
          onClick={() => changeActiveState('upload')}
        >
          Ethereum network
        </div>
        <div
          className={`switch-label ps-2 ${
            activeState === 'download' ? 'current' : ''
          }`}
          onClick={() => changeActiveState('download')}
        >
          Arbitrum network
        </div>
      </div>
      {activeState === 'upload' && <BridgeUpload play={play} />}
      {activeState === 'download' && <BridgeDownload play={play} />}
    </div>
  );
};

export default WalletLeftPanel;
