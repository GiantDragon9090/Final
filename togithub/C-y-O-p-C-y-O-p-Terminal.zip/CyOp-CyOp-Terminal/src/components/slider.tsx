import { useState, useEffect, useRef, MouseEventHandler } from "react"

interface ISliderBar {
    value: number,
    max: number,
    min?: number,
    onUpdate?: (value: number) => void
}

const UNIT_PROG_WIDTH = 2;
const PADDING_X = 2;

export const Slider = ({ value, min = 0, max, onUpdate }: ISliderBar) => {

    const refProgress = useRef<HTMLDivElement>(null)
    const [progressWidth, setProgressWidth] = useState<number>(0)

    useEffect(() => {
        if (refProgress.current) {
            const divider = (max - min === 0) ? 1 : (max - min)
            const progress = (value - min) * 100 / divider
            const w = refProgress.current.clientWidth
            const currentW = Math.round((w * progress / 100) / UNIT_PROG_WIDTH) * UNIT_PROG_WIDTH
            setProgressWidth(currentW)

            console.log("progresswidth " + currentW)
        }
    }, [value, min, max])

    const onMouseMove: MouseEventHandler<HTMLDivElement> = (event) => {
        if (refProgress.current) {
            if (event.buttons === 1) {
                const rect = refProgress.current.getBoundingClientRect();
                const posX = event.clientX - rect.left;
                const w = refProgress.current.clientWidth - PADDING_X * 2

                if (w === 0 || max === min)
                    return;
                let percent = (posX - PADDING_X) / w
                if (percent < 0)
                    percent = 0
                else if (percent > 1)
                    percent = 1

                const newValue = Math.floor(percent * (max - min) + min)
                if (onUpdate)
                    onUpdate(newValue)
            }
        }
    }

    return (
        <div className="co-progress" ref={refProgress} onMouseDown={onMouseMove} onMouseMove={onMouseMove}>
            <div className="progress-item" style={{ width: `${progressWidth}px` }}></div>
        </div>
    )
}

export default Slider