import { useState } from "react"
import useTyped from "hooks/typed";
import ProgressBar from "components/progressbar";
import { useNavigate } from "react-router-dom";

export const LoadingPanel = () => {

    const navigate = useNavigate()
    const [showProgress, setShowProgress] = useState(false)

    const onCompleteSearchAnimation = () => {
        setShowProgress(true)
    }

    const onCompleteLoading = () => {
        navigate("/database")
    }
    const [textInitiate, initiateCompleted] = useTyped({
        text: "initiate terminal...",
        start: true,
        speed: 30,
    })

    const [textLoading] = useTyped({
        text: "loading",
        start: initiateCompleted,
        speed: 30,
        onComplete: onCompleteSearchAnimation
    })

    return (
        <>
            <div className="loading-panel-notification text-start">
                <div className="">
                    <span>{textInitiate}</span>
                    {!initiateCompleted &&
                        <span className="typed-cursor">|</span>
                    }
                </div>
            </div>
            <div className="align-items-center loading-bar">
                <div className="me-1">
                    {textLoading}
                </div>
                <div></div>
                <div style={{ width: "320px" }}>
                    {showProgress &&
                        <ProgressBar progress={100} animateInterval={20} onComplete={onCompleteLoading} />
                    }
                </div>
            </div>
        </>
    )
}

export default LoadingPanel