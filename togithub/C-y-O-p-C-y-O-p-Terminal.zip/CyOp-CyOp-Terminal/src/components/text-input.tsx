import React, { useState, useRef, useEffect, KeyboardEvent } from "react"

export const TextInputing = (props: any) => {
	const inputRef: any = useRef(null)
	const [isEditable, setIsEditable] = useState(true)

	useEffect(() => {
		if (inputRef.current) {
			inputRef.current.focus();
		}
	}, [inputRef.current]); // eslint-disable-line

	const enterKeyCheck = (e: KeyboardEvent) => {
		if (e.key === 'Enter') {

			e.preventDefault();

			// first check if the content is valid
			if (!(e.target instanceof HTMLElement)) {
				props.setRejected(true)
				return
			}

			const element = e.target as HTMLElement
			const innerText = element.innerText

			console.log(!props.validation(innerText))

			if (props.validation) {
				if (!props.validation(innerText)) {
					props.setRejected(true)
					return
				}
			}

			setIsEditable(false)
			props.setCompleted(true)
			props.setRejected(false)

			if (props.setValue) {
				props.setValue(innerText)
			}
		}
	}

	return (
		<>
			<div ref={inputRef}
				contentEditable={isEditable}
				className="co-input-field"
				onKeyDown={enterKeyCheck} >
			</div>
		</>
	)
}

export default TextInputing