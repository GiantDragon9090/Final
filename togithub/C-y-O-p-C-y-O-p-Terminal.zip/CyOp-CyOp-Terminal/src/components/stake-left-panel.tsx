import { useState, useEffect, useCallback } from 'react';
import { ethers } from 'ethers';
import { useAudio } from 'react-awesome-audio';
import { toast } from 'react-toastify';
import { useWeb3, useContracts } from 'shared/hooks';
import { toFixedNoRounding, formatUnits, parseCommified } from 'helpers/utils';
import addresses from 'shared/addresses';

const sndAction = require('assets/audio/action.mp3').default;

enum StakeStatus {
  Stake,
  Unstake,
}

const detailUpdateInterval = 5000;

export const StakeLeftPanel = () => {
  const { play } = useAudio({ 
    src: sndAction,
  });
  const [currentStakeStatus, setCurrentStakeStatus] = useState<StakeStatus>(
    StakeStatus.Stake
  );
  const [inputAmount, setInputAmount] = useState('');
  const [stakedBalance, setStakedBalance] = useState('0');
  const [userVotedBalance, setUserVotedBalance] = useState('');
  const [userClaimable, setUserClaimable] = useState(false);
  const [lifetimeRewards, setLifetimeRewards] = useState('0');
  const [tokenBalance, setTokenBalance] = useState('0');
  const [insufficient, setInsufficient] = useState(false);
  const [approved, setApproved] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [claimProcessing, setClaimProcessing] = useState(false);
  const [checkingApproval, setCheckingApproval] = useState(true);

  const {
    approve,
    allowance,
    stake,
    unstake,
    round,
    stakeAmount,
    userClaimAmount,
    isUserEligibleToClaim,
    claimRewards,
    balanceOf,
    userVoteCount,
  } = useContracts();

  const { walletAddress } = useWeb3();

  const onClickStake = async (curState: StakeStatus) => {
    play();
    setCurrentStakeStatus(curState);
  };

  const onClickEnter = async () => {
    play();
    let amount = 0;
    if (currentStakeStatus === StakeStatus.Stake) {
      amount = parseCommified(inputAmount);
    } else {
      amount = parseCommified(stakedBalance);
    }
    if (!amount || isNaN(amount) || amount === 0) {
      return;
    }
    setProcessing(true);

    let nativeAmount = ethers.utils.parseUnits(amount.toString(), 9);

    if (currentStakeStatus === StakeStatus.Stake) {
      if (stake) {
        try {
          const res = await stake(nativeAmount);
          await res.wait();
          toast.success('Stake successfull');
        } catch (e) {
          // todo handle error
          console.log(e);
          toast.error('Something went wrong. Unable to stake');
        } finally {
          setProcessing(false);
          setInputAmount('');
        }
      }
    } else {
      if (unstake) {
        try {
          const res = await unstake(nativeAmount);
          await res.wait();
          toast.success('Unstake successfull');
        } catch (e: any) {
          // todo handle error
          console.log(e);
          toast.error(`Something went wrong. ${e?.data?.message ? e?.data?.message : ""}`);
        } finally {
          setProcessing(false);
        }
      }
    }
  };

  const onClickApprove = async () => {
    setProcessing(true);
    play();
    // try approve
    if (approve) {
      try {
        const approved = await approve(
          addresses.arbitrumDAO,
          ethers.constants.MaxUint256
        );
        if (approved) {
          setApproved(true);
          setProcessing(false);
        }
      } catch (e) {
        setApproved(false);
        setProcessing(false);
      }
    }
  };

  const onClickClaim = async () => {
    play();
    if (!round || !claimRewards || !userClaimable) {
      return;
    }
    setClaimProcessing(true);
    try {
      const currentRound = await round();
      if (currentRound !== null) {
        const wholeAmount = await claimRewards(currentRound);
        console.log('Success in claimRewards:', wholeAmount);
      }
    } catch (e) {
      console.log(e);
    } finally {
      setClaimProcessing(false);
    }
  };

  const onChangeAmount = (value: string) => {
    if (isNaN(Number(value))) return;
    // setting value
    setInputAmount(value);
  };

  const getDetails = useCallback(async () => {
    if (
      !round ||
      !stakeAmount ||
      !isUserEligibleToClaim ||
      !userClaimAmount ||
      !balanceOf ||
      !userVoteCount ||
      !walletAddress
    ) {
      return;
    }
    try {
      // get staked balancestake
      const stakedBalance = await stakeAmount(walletAddress);
      if (stakedBalance !== null) {
        let amount = formatUnits(stakedBalance, 9);
        setStakedBalance(amount);
      }
      // get account CyOp balance
      const cyopBalance = await balanceOf();
      if (cyopBalance !== null) {
        let amount = formatUnits(cyopBalance, 9);
        setTokenBalance(amount);
      }
      // eligible claim and claimable amount
      let activeRound = await round();
      if (activeRound !== null) {
        // check user vote count
        const voteCount = await userVoteCount(walletAddress, activeRound);
        if (voteCount !== null) {
          setUserVotedBalance(formatUnits(voteCount, 9));
        }
        // is user eligible to claim
        const userEligibleToCliam = await isUserEligibleToClaim(
          walletAddress,
          activeRound
        );
        if (userEligibleToCliam !== null) {
          setUserClaimable(userEligibleToCliam);
        }
        // claimable amount
        const claimAmount = await userClaimAmount(walletAddress, activeRound);
        if (claimAmount !== null) {
          setLifetimeRewards(formatUnits(claimAmount, 9));
        }
      }
    } catch (e) { }
  }, [
    balanceOf,
    isUserEligibleToClaim,
    round,
    stakeAmount,
    userClaimAmount,
    userVoteCount,
    walletAddress,
  ]);

  const checkValidation = useCallback(() => {
    let balance = 0;

    if (currentStakeStatus === StakeStatus.Stake) {
      balance = parseCommified(tokenBalance);
    } else {
      return true;
    }

    let amount = parseFloat(inputAmount);

    if (amount === null) return true;

    if (!amount || isNaN(amount)) {
      amount = 0;
    }

    if (amount > balance) {
      setInsufficient(false);
    } else {
      setInsufficient(true);
    }
  }, [tokenBalance, currentStakeStatus, inputAmount]);

  useEffect(() => {
    getDetails();
    const timer = setInterval(getDetails, detailUpdateInterval);
    return () => {
      clearInterval(timer);
    };
  }, [getDetails]);

  useEffect(() => {
    (async () => {
      if (currentStakeStatus === StakeStatus.Stake) {
        setInputAmount('');
        // check approval
        if (allowance && walletAddress) {
          try {
            setCheckingApproval(true);
            const approvalAmount = await allowance(
              walletAddress,
              addresses.arbitrumDAO
            );
            if (approvalAmount !== null) {
              if (approvalAmount.gt('0')) {
                setApproved(true);
                return;
              }
            }
          } catch (e) {
            // TODO handle errors
            console.log(e);
          } finally {
            setCheckingApproval(false);
          }
        }
      } else {
        setInputAmount(stakedBalance);
      }
    })();
  }, [currentStakeStatus, allowance, stakedBalance, walletAddress]);

  useEffect(() => {
    checkValidation();
  }, [tokenBalance, stakedBalance, inputAmount, checkValidation]);

  return (
    <>
      <div>
        <div style={{ borderBottom: '3px solid #05CCB2' }}>
          <div
            className={`switch-label ps-2 ${currentStakeStatus === StakeStatus.Stake ? 'current' : ''
              }`}
            onClick={() => onClickStake(StakeStatus.Stake)}
          >
            Stake
          </div>
          <div
            className={`switch-label ps-2 ${currentStakeStatus === StakeStatus.Unstake ? 'current' : ''
              }`}
            onClick={() => onClickStake(StakeStatus.Unstake)}
          >
            Unstake
          </div>
        </div>
        {currentStakeStatus === StakeStatus.Stake && (
          <>
            <div className="d-flex justify-content-between pt-2">
              <span className="text-desc ps-2">input</span>
              <div>
                <span className="pe-2 pt-1" style={{ fontSize: '12px' }}>
                  [
                  {ethers.utils.commify(
                    toFixedNoRounding(parseCommified(tokenBalance))
                  )}
                  ]
                </span>
                <span
                  className="pe-2 pt-1 text-danger"
                  style={{ fontSize: '12px' }}
                  onClick={() => setInputAmount(ethers.utils.commify(
                    toFixedNoRounding(parseCommified(tokenBalance), 0)
                  ))}
                >
                  max{' '}
                </span>
              </div>
            </div>
            <div className="d-flex justify-content-between py-2">
              <input
                className="text-desc stake-txt-input ps-2"
                placeholder="0.0"
                value={inputAmount}
                onChange={(event) => onChangeAmount(event.target.value)}
              />
              <span className="pe-2">CyOp</span>
            </div>
          </>
        )}
        {currentStakeStatus === StakeStatus.Unstake && (
          <>
            <div className="d-flex justify-content-between pt-2">
              <span className="text-desc ps-2">input</span>
              <span className="pe-2 pt-1" style={{ fontSize: '12px' }}>
                [
                {ethers.utils.commify(
                  toFixedNoRounding(parseCommified(stakedBalance))
                )}
                ]
              </span>
            </div>
            <div className="d-flex justify-content-between py-2">
              <input
                disabled
                className="stake-txt-input ps-2"
                placeholder="0.0"
                value={inputAmount}
              />
              <span className="pe-2">CyOp</span>
            </div>
          </>
        )}

        {processing && (
          <div className="button-label" style={{ opacity: '0.5' }}>
            <i
              className="fa fa-repeat fa-spin"
              aria-hidden="true"
              style={{ fontSize: '15px' }}
            ></i>
            &nbsp;processing
          </div>
        )}
        {!processing && !approved && (
          <div className="button-label" onClick={onClickApprove}>
            {checkingApproval ? (
              <>
                <i
                  className="fa fa-repeat fa-spin"
                  aria-hidden="true"
                  style={{ fontSize: '15px' }}
                ></i>
                &nbsp;checking approval
              </>
            ) : (
              'approve'
            )}
          </div>
        )}
        {!processing && approved && insufficient && (
          <div className="button-label" onClick={onClickEnter}>
            enter
          </div>
        )}
        {!processing && approved && !insufficient && (
          <div className="button-label" style={{ background: '#FF00A0' }}>
            Insufficient balance
          </div>
        )}
        <div className="pt-2 ps-2">
          Staked balance {parseCommified(userVotedBalance) > 0 && '[Locked]'}:
        </div>
        <div className="text-desc ps-2">{stakedBalance}</div>
        {parseCommified(userVotedBalance) > 0 && (
          <>
            <div className="pt-2 ps-2">Voted balance:</div>
            <div className="text-desc ps-2">{userVotedBalance}</div>
          </>
        )}
        <div className="pt-4 ps-2">Claimable rewards:</div>
        <div className="text-desc ps-2">{lifetimeRewards} eth</div>
      </div>
      {userClaimable && !claimProcessing && Number(lifetimeRewards) > 0 && (
        <div className="mt-4 button-label" onClick={onClickClaim}>
          claim{' '}
        </div>
      )}
      {claimProcessing && (
        <div className="button-label" style={{ opacity: '0.5' }}>
          <i
            className="fa fa-repeat fa-spin"
            aria-hidden="true"
            style={{ fontSize: '15px' }}
          ></i>
          &nbsp;processing
        </div>
      )}
    </>
  );
};

export default StakeLeftPanel;
