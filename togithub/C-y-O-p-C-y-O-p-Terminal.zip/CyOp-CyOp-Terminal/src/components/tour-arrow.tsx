export const TourArrow = ({label}: any) => {
  return (
    <div className="d-flex">
      <div className="tour-arrow">
        <span className="arrow first">&gt;</span>
        <span className="arrow second">&gt;</span>
        <span className="arrow third">&gt;</span>
      </div>
      {label}
    </div>
  );
};

export default TourArrow;