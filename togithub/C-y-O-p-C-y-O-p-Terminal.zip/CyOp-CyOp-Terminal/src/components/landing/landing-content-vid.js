import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import CountingUp from "./countingup";

import landingVideo from 'assets/video/CyOpTrailer.mp4'

const LandingContentVid = (props) => {
  const videoRef = useRef();
  const navigate = useNavigate();
  const [soundOn, setSoundOn] = useState(false);
  const [tsPos, setTSPos] = useState(null);
  const [tePos, setTEPos] = useState(null);

  const onClickSound = () => {
    videoRef.current.muted = soundOn;
    setSoundOn(!soundOn);
  }

  const tsHandle = (e) => {
    setTEPos(null);
    setTSPos(e.targetTouches[0].clientY);
  }

  const tmHandle = (e) => {
    setTEPos(e.targetTouches[0].clientY);
  }

  const teHandle = (e) => {
    if (!tsPos || !tePos) return;

    if(tePos < tsPos - 50)
      props.setIsVid(false);
  }

  useEffect(() => {
    let height = window.screen.height;

    if (height < 420) {
      document.getElementsByClassName("landing-content-vid")[0].style.justifyContent = "unset";

      document.getElementsByClassName("landing-content-vid")[0].getElementsByClassName("landing-video")[0].style.position = "absolute";

      document.getElementsByClassName("landing-content-vid")[0].getElementsByClassName("landing-title-one")[0].style.paddingTop = "120px";
      document.getElementsByClassName("landing-content-vid")[0].getElementsByClassName("landing-title-one")[0].style.fontSize = "20px";
      document.getElementsByClassName("landing-content-vid")[0].getElementsByClassName("landing-title-one")[0].style.paddingBottom = "10px";

      document.getElementsByClassName("landing-content-vid")[0].getElementsByClassName("landing-title-two")[0].style.paddingBottom = "18px";
      document.getElementsByClassName("landing-content-vid")[0].getElementsByClassName("landing-title-two")[0].style.fontSize = "16px";

      document.getElementsByClassName("landing-content-vid")[0].getElementsByClassName("landing-sound")[0].style.marginTop = "-20px";

      document.getElementsByClassName("landing-content-vid")[0].getElementsByClassName("landing-sound")[0].style.fontSize = "12px";
      document.getElementsByClassName("landing-content-vid")[0].getElementsByClassName("landing-launch")[0].style.fontSize = "12px";
    }
    
    var myimage = document.getElementsByClassName("landing-content-vid")[0];
    if (myimage.addEventListener) {
      // IE9, Chrome, Safari, Opera
      myimage.addEventListener("mousewheel", MouseWheelHandler, false);
      // Firefox
      myimage.addEventListener("DOMMouseScroll", MouseWheelHandler, false);
    }
    // IE 6/7/8
    else myimage.attachEvent("onmousewheel", MouseWheelHandler);
  }, []);

  const MouseWheelHandler = (e) => {
    // cross-browser wheel delta
    var e = window.event || e; // old IE support
    var delta = Math.max(-1, Math.min(1, (e.wheelDelta || -e.detail)));

    if(delta == -1)
      setTimeout(() => {
        props.setIsVid(false);  
      }, 400);
  }

  return (
    <div className="landing-content-vid full-screen text-center d-flex flex-column align-items-center" onTouchStart={(e)=>tsHandle(e)} onTouchMove={(e)=>tmHandle(e)} onTouchEnd={(e)=>teHandle(e)}>
      <video className="landing-video" ref={videoRef} src={landingVideo} autoPlay loop muted playsInline controlsList="nodownload noplaybackrate">
      </video>

      <div className="landing-title-one fw-bold">
        <span className="text-primary">// </span>JOIN THE PUNKS TO BECOME A MASTER OF THE CRYPTOVERSE
      </div>

      <div className="landing-title-two fw-bold">
        <span className="text-primary">Void value locked </span>
        <span className="counting-num text-danger">[ ${<CountingUp />} ]</span>
      </div>

      <span className="landing-launch pointer border border-primary text-primary fw-bold" onClick={() => navigate("/wakeup")}>
        LAUNCH APP
      </span>

      <div className="landing-sound pointer" onClick={onClickSound}>
        {soundOn && "sound off"}
        {!soundOn && "sound on"}
      </div>
    </div>
  );
};

export default LandingContentVid;
