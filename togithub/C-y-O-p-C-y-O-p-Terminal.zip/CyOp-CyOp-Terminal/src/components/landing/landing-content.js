import { useState } from "react";
import LandingContentVid from "./landing-content-vid";
import LandingContentTxt from "./landing-content-txt";

const LandingContent = () => {
  const [ isVid, setIsVid ] = useState(true);

  return (
    <div className="landing-content d-flex text-center align-items-center">
      {isVid && 
        <LandingContentVid setIsVid={setIsVid}/>
      }
      {!isVid && 
        <LandingContentTxt setIsVid={setIsVid}/>
      }
    </div>
  );
};

export default LandingContent;
