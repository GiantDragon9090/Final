import { useNavigate } from "react-router-dom";
import Logo from "../../assets/images/logo.png";

const LandingLogo = () => {
  const navigate = useNavigate();

  return (
    <div className="landing-logo pointer" onClick={() => navigate("/")}>
      <img src={Logo} className="img-logo" alt="avatar" />
      <b>CyOp</b>
    </div>
  );
};

export default LandingLogo;
