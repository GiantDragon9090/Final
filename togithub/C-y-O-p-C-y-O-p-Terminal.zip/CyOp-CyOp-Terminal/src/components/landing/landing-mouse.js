import { useEffect } from "react";

const LandingMouse = () => {
  useEffect(() => {
    let width = window.screen.width;
    let height = window.screen.height;

    if (width > height) {
      if(width < 992)
        document.getElementsByClassName("mouse-ico")[0].style.display = "none";
      else
        document.getElementsByClassName("mouse-ico")[0].style.display = "block";
    }
    else {
      document.getElementsByClassName("mouse-ico")[0].style.display = "block";
    }

    if (height <= 410)
      document.getElementsByClassName("mouse-ico")[0].style.display = "none";
  }, [])

  return (
    <div className="landing-mouse">
      <div id="wheel-up" style={{display: "none"}}>
        <span class="m_scroll_up_arrows one"></span>
        <span class="m_scroll_up_arrows two"></span>
      </div>

      <div class="mouse-ico" style={{display: "none"}}>
        <div class="wheel"></div>
      </div>
      
      <div id="wheel-down">
        <span class="m_scroll_down_arrows one"></span>
        <span class="m_scroll_down_arrows two"></span>
      </div>
    </div>
  );
};

export default LandingMouse;
