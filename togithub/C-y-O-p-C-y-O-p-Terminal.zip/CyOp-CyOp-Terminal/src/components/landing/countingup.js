import { useState } from "react";
import CountUp from 'react-countup';

export const CountingUp = () => {
  const [countValue, setCountValue] = useState(1957409);

  return (
    <CountUp
      start={0}
      end={countValue}
      duration={5}
      useEasing={true}
      separator=","
      decimal=","
    >
    </CountUp>
  )
}

export default CountingUp;
