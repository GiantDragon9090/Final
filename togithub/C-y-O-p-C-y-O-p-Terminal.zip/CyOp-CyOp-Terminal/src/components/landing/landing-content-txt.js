import { useState, useEffect, useRef } from "react";
import CollapseContent from "./collapse-content";

const LandingContentTxt = (props) => {
  const [lastPos, setLastPos] = useState(0);
  const [tsPos, setTSPos] = useState(null);
  const [tePos, setTEPos] = useState(null);
  const innerRef = useRef();

  const scrollHandle = () => {
    if (innerRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = innerRef.current;

      setLastPos(scrollTop);

      let scrollPercent = scrollTop / (scrollHeight - clientHeight) * 100;
      document.getElementById("progress-bar").style.height = scrollPercent + "%";

      // progress circle hide
      if (scrollTop + clientHeight === scrollHeight || scrollTop <= 0) {
        document.getElementById("progress-circle").style.display = "none";
      } else {
        document.getElementById("progress-circle").style.display = "block";
      }

      // mouse direction change
      if (scrollTop + clientHeight === scrollHeight) {
        document.getElementById("wheel-up").style.display = "block";
        document.getElementById("wheel-down").style.display = "none";
      } else {
        document.getElementById("wheel-up").style.display = "none";
        document.getElementById("wheel-down").style.display = "block";
      }
    }
  }

  const wheelHandle = (e) => {
    let y = e.deltaY;
    if(y < 0 && lastPos == 0)
      props.setIsVid(true);
  }

  const tsHandle = (e) => {
    setTEPos(null);
    setTSPos(e.targetTouches[0].clientY);
  }

  const tmHandle = (e) => {
    setTEPos(e.targetTouches[0].clientY);
  }

  const teHandle = (e) => {
    if (!tsPos || !tePos) return;
    
    if(tePos > tsPos + 50 && lastPos <= 0)
      props.setIsVid(true);
  }

  useEffect(() => {
    let height = window.screen.height;

    if(height < 420) {
      document.getElementsByClassName("landing-content-txt")[0].style.marginTop = "110px";
      document.getElementsByClassName("landing-content-txt")[0].style.height = "calc(100vh - 220px)";
    }
  }, []);

  return (
    <div className="landing-content-txt text-left" ref={innerRef} onScroll={scrollHandle} onWheel={(e)=>wheelHandle(e)} onTouchStart={(e)=>tsHandle(e)} onTouchMove={(e)=>tmHandle(e)} onTouchEnd={(e)=>teHandle(e)}>
      <div className="landing-slideUp">
        {/* INTRO */}
        <div>
          <span className="text-title"><span className="text-primary">// </span>INTRO</span><p/>

          <span className="fw-bold text-white">Back to the roots of Crypto with the <span className="text-primary">CyOp Protocol</span>.</span><p/>

          <p>Governed by a smart community this DAO protocol triggers a massive buying frenzy on any ERC-20 token.</p>

          <p>Vote for your favorite project using the hacker-inspired blockchain terminal.</p><p/>

          <p>Every voting round generates passive income as ETH rewards for all users.</p><p/>

          <p>Get your first CyOp now to join the next Gen Yield DAO.</p>
        </div>
        <br /><br />
        

        {/* ELI5 */}
        <div>
          <span className="text-title"><span className="text-primary">// </span>ELI5</span><p/>

          <span className="fw-bold text-white">How the <span className="text-primary">protocol system</span> works.</span><p/>

          <p>Users transact CyOp and 10% is collected as ETH on every tx.</p><p/>
          <p>Protocol fund gets 7% / Marketing 3%</p><p/>

          <p>CyOp holders can submit projects to vote on.</p>
          <p>Once fund is filled, the protocol will buy the winner project with 80% of the fund.</p>
          <p>10% will go to CyOp liquidity to further strengthen overall liquidity.</p>
          <p>10% to a randomly selected lucky user.</p><p/>

          <p>The invested project tokens from the Void - the name of the fund - will later be sold against ETH and 50% shared as rewards to users and 50% flows back into the protocol fund for even more passive income in the future.</p><p/>
          <p>"All of this has happened before. All of this will happen again"</p><p/>
        </div>
        <br /><br />


        {/* TOKENOMICS */}
        <div>
          <span className="text-title"><span className="text-primary">// </span>TOKENOMICS</span><p/>

          <span className="fw-bold text-white">The native token is <span className="text-primary">$CyOp</span>. Users can stake $CyOp to participate within the Protocol DAO and earn $ETH rewards.</span><p/>

          <p>95,80B</p>
          <p style={{opacity: "0.5"}}>Total supply I all in circulation</p><p/>
          
          <p>10%</p>
          <p style={{opacity: "0.5"}}>Tax</p><p/>
          
          <p style={{wordBreak: "break-word"}}>0xddac9c604ba6bc4acec0fbb485b83f390ecf2f31</p>
          <p style={{opacity: "0.5"}}>Contract: (ERC20)</p>
        </div>
        <br /><br />
    

        {/* ROADMAP */}
        <div>
          <span className="text-title"><span className="text-primary">// </span>ROADMAP</span><p/>

          <CollapseContent
            title={"Launch project website"}
            percent={100}
            content={"Publish of product pitch prior to token launch"}
          />

          <CollapseContent
            title={"Token gen event"}
            percent={100}
            content={"On November 17th 2021, CyOp Protocol stealth launched and liquidity worth $282K got locked for 1 year"}
          />

          <CollapseContent
            title={"Listing on data aggregators"}
            percent={100}
            content={"Got listed on Coinmarketcap, Coingecko, Delta app, Coinbase et.al within 48hours"}
          />
          <CollapseContent
            title={"Initiation of CyOp I Protocol"}
            percent={100}
            content={"Protocol DAO deployed and started"}
          />
          <CollapseContent
            title={"Terminal app launch"}
            percent={100}
            content={"Cutting edge DApp aka Terminal successfully booted as the main access point for users to navigate the Protocol"}
          />
          <CollapseContent
            title={"Birth of the CyOp Syndicate"}
            percent={100}
            content={"Awakened - united - tuned into the grid. Users can join the movement and become a #CyOperator by pledging allegiance to the $CyOp Protocol"}
          />
          <CollapseContent
            title={"Burn CyOp worth a million dollar"}
            percent={100}
            content={"In the beginning Devs created a contract and a protocol. And Devs saw their creation, that it was good; Then Devs envisioned disruption and divided the light from the darkness. Devs called the light a pump, and the darkness They called a burn. But the spirit of Devs was still hovering over the chain of events. So, the creation brought forth Punks that yielded Ethereum according to their kind and from the darkness sprung a place without form, the VOID, where all burned token got sucked into the deep. Then Devs blessed and gratified all punks, because in it CyOp worth a MILLION DOLLAR from all their work which Devs had created were BURNED. And Devs saw that it was good!"}
          />
          <CollapseContent
            title={"First CEX listing"}
            percent={100}
            content={"CyOp token tradable from December 4th 2021 on Bitmart exchange, increasing liquidity"}
          />
          <CollapseContent
            title={"CyOp Protocol executed for the first time"}
            percent={100}
            content={"A massive 280 ETH buy-in successfully concluded the first investment round"}
          />
          <CollapseContent
            title={"uNFT premint"}
            percent={50}
            content={"CyOp uNFT Modules will add an additional layer of utility unheard of in crypto DAOs and enhance the way the DApp-Terminal operates"}
          />
          <CollapseContent
            title={"Landing Page"}
            percent={100}
            content={"Marketing site redesign as a transport layer for simple interaction with new visitors"}
          />
          <CollapseContent
            title={"NFT Reveal"}
            percent={50}
            content={"Character class reveal"}
          />
          <CollapseContent
            title={"Contract Updates in prep for Protocol V2.0.0"}
            percent={50}
            content={"DAO suggested changes will increase the amount of reward claimable by all Stakers"}
          />
          <CollapseContent
            title={"Protocol V2.0.0"}
            percent={50}
            content={"DEVs finalize the next big iteration depending on further DAO input"}
          />
          <CollapseContent
            title={"NFT Plugin Event"}
            percent={50}
            content={"skill reveal"}
          />
          <CollapseContent
            title={"Metagrid"}
            percent={50}
            content={"In search of the next evolutionary phase, an interface between DAO and Metaverse is to be created"}
          />
        </div>
        <br />

        <p className="text-primary">// to be continued</p>
      </div>

      <div className="progress-line d-flex flex-column align-items-center">
        <div className="progress-bar" id="progress-bar"></div>
        <div className="progress-circle border border-primary" id="progress-circle"></div>
      </div>
    </div>
  );
};

export default LandingContentTxt;
