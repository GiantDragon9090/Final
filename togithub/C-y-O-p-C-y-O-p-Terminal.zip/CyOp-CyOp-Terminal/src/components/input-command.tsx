import { useState, useRef, useEffect } from 'react';
import { useAudio } from 'react-awesome-audio';
import useDeviceDetect from '../hooks/device-detect';

const sndContent = require('assets/audio/content.mp3').default;
const sndCmd = require('assets/audio/command.mp3').default;

export const CommandInputing = ({
  inputCommand,
  setInputCommand,
  setMatrix,
  setMatrixCmd,
  setEasterFinish,

  setIsClkCmd,
  setClickCommand,
  setClickCmdContent,
  setClkCmdFinish,

  isInitClick,
  initClkCommand,
}: any) => {

  useEffect(() => {
    if(isInitClick) {
      onClickCommand(initClkCommand);
    }
  });

  const onClickCommand  = (cmd: any) =>{
    setIsClkCmd(true);
    setClkCmdFinish(false);
    setClickCommand(cmd);
    setClickCmdContent(isValidCommand(cmd));
  }

  const commandList: Array<any> = [
    {
      command: 'intro',
      loading: 'searching:\\intro>file_loaded',
      description:
      <div>
      This Is Revolution<br /><br />
  
      CyOp fully utilizes the power of the blockchain to change the world of defi.<p></p>
      Simply invest into an ever recharging crypto fund, the CyOp Protocol, constantly triggering a massive buying frenzy on any given ERC-20 token. These are called disruptions that will generate passive income and rewards in Ethereum, time and time again.<p></p>
      It is controlled by all members and never influenced by central governments. The transparent, encoded rules create the most sophisticated decentralized autonomous organization (DAO).<p></p>
      The Terminal lets you access the features of the DAO through a DApp experience. With its beautiful design and regular updates, it pays hommage to all the Punks out there, hacking the existing system to create a better world.<br /><br />
      Choose your own path and become part of one the biggest movements of the Cryptosphere.
      </div>,
    },
    {
      command: 'protocol',
      loading: 'searching:\\protocol>file_loaded',
      description: <div>
      · CyOp tokens can be used by stakers to vote for any given token on the ethereum chain to get disrupted.<p></p>
      · In this process, the CyOp tokens will get locked until the end of each respective round, resulting in a deflationary effect.<p></p>
      · Once the fund has been filled sufficiently, the CyOp Protocol will be executed and the winning token will experience a disruptive market buy order using 80% of the CyOp fund.<br /><br />
      &ensp;⁃&emsp;The invested project tokens from the Void - the name of the fund - will later be sold against ETH and 50% shared as rewards to all stakers & voters and 50% flows back into the protocol fund for even more passive income in the future.<p></p>
      &ensp;⁃&emsp;This revenue fully benefits all voters as a reward. The bigger the amount used for voting, the higher the share on a regular basis.<p></p>
      &ensp;⁃&emsp;The more often the CyOp protocol is executed, the more steadily top-up rewards can be distributed. In addition, 'accumulated staking' reduces circulating supply and has a positive price impact on $CyOp.<br /><br />
      · 10% of the fund will go to CyOp liquidity (a 5% market buy of CyOp tokens) to further strengthen overall liquidity.<p></p>
      · A 'Lucky user' will experience a matrix glitch in his favor and is awarded 10% of the disruption fund each time the CyOp protocol is executed. In order to be eligible, you must hold at least 2,000,000,000 CyOp tokens and vote in that respective round. If the disruption fund is bigger than 30 ETH, three Lucky user will be selected randomly.<br/><br/>
      <b>"All of this has happened before. All of this will happen again"</b>
      </div>,
    },
    {
      command: 'calculation',
      loading: 'searching:\\calculation>file_loaded',
      description: <div>
      With an exemplary daily trading volume of $1,000,000 and $10,000,000 over a 10-day period, the 7% tax going into the CyOp Protocol fund will stand at  $700,000.<p></p>
      If the Protocol gets executed now:<br/>
      · 80% market buy = $560,000<br/>
      · 10% CyOp Liquidity pool = $70,000<br/>
      · 10% Lucky user = $70,000
      </div>,
    },
    {
      command: 'modules',
      loading: 'searching:\\modules>file_loaded',
      description: <div>
      The CyOp protocol has been designed in a modular way. Various NFT-based extensions will allow users to connect to the Metagrid™.<p></p>
      There are different types of NFT modules. Some with a fixed function and others that can be upgraded within the Metagrid™ world.<p></p>
      They have the capabilities to influence the protocol and ultimately the real world.
      </div>,
    },
    {
      command: 'metagrid',
      loading: 'searching:\\metagrid>file_encrypted',
      description: <div>access denied</div>,
    },
    {
      command: 'tokenomics',
      loading: 'searching:\\tokenomics>file_loaded',
      description: <div>
      <b>PROJECT:</b> CyOp I Protocol<br />
      <b>TICKER:</b> CyOp<br />
      <b>CONTRACT ADDRESS:</b> <a href="https://etherscan.io/token/0xddac9c604ba6bc4acec0fbb485b83f390ecf2f31" target="_blank">0xddac9c604ba6bc4acec0fbb485b83f390ecf2f31</a><p></p>
  
      <b>TYPE:</b> Erc20<br />
      <b>LAUNCH:</b> Fair, Stealth, Antibot, 13% CyOp Lab<br />
      <b>LIQUIDITY:</b> Locked<br />
      <b>MAX SUPPLY:</b> 95,800,000,000,000<p></p>
  
      <b>TRANSACTION TAX:</b><p></p>
      - 3% Growth hacking<br />
      - 7% CyOp I Protocol
      </div>,
    },
    {
      command: 'roadmap',
      loading: 'searching:\\roadmap>file_loaded',
      description: <div>
      · Token gen event<br />
      · Listing on data aggregators<br />
      · Community growth hacking<br />
      · Initiation of CyOp I Protocol<br />
      · Terminal website interface<br />
      · NFT modules<br />
      · Metagrid<br />
      · Audits<br />
      · Marketing operations<br />
      · Exchange listings<br />
      · Partnerships<p></p>
  
      To be continued...
      </div>,
    },
    {
      command: 'team',
      loading: 'searching:\\team>file_loaded',
      description: <div>
      CyOp runs as decentralized as possible. At its core lies our protocol which is 100% community governed. That's why the lab remains anonymous. It consists of developers, marketers and visionaries with years of experience and a vast network in the crypto space.
      </div>,
    },
    {
      command: 'contact',
      loading: 'searching:\\contact>file_loaded',
      description: <div>Reach out to us for business inquiries via CyOpProtocol at protonmail dot com</div>,
    },
    {
      command: 'links',
      loading: 'searching:\\links>file_loaded',
      description: <div>
      · <a href="https://twitter.com/CyOpProtocol" target="_blank">Twitter</a><br />
      · <a href="https://t.me/CyOpProtocol" target="_blank">Telegram community</a><br />
      · <a href="https://t.me/CyOpAnnouncement" target="_blank">Telegram announcement</a><br />
      · <a href="https://coinmarketcap.com/currencies/cyop-protocol/" target="_blank">Coinmarketcap</a><br />
      · <a href="https://www.coingecko.com/en/coins/cyop-protocol" target="_blank">Coingecko</a><br />
      · <a href="https://www.dextools.io/app/ether/pair-explorer/0x1b1c28a89caac877c63d0adac173a0b55921ab65" target="_blank">Dextools</a><br />
      · <a href="https://etherscan.io/token/0xddac9c604ba6bc4acec0fbb485b83f390ecf2f31" target="_blank">Etherscan</a>
      </div>,
    },
    {
      command: ['commands', 'help'],
      loading: 'searching:\\commands>file_loaded',
      description: <div>
      <span className='command-click' onClick={() => onClickCommand('intro')}>intro</span><br />
      <span className='command-click' onClick={() => onClickCommand('protocol')}>protocol</span><br />
      <span className='command-click' onClick={() => onClickCommand('rewards')}>rewards</span><br />
      <span className='command-click' onClick={() => onClickCommand('calculation')}>calculation</span><br />
      <span className='command-click' onClick={() => onClickCommand('modules')}>modules</span><br />
      <span className='command-click' onClick={() => onClickCommand('metagrid')}>metagrid</span><br />
      <span className='command-click' onClick={() => onClickCommand('tokenomics')}>tokenomics</span><br />
      <span className='command-click' onClick={() => onClickCommand('roadmap')}>roadmap</span><br />
      <span className='command-click' onClick={() => onClickCommand('contact')}>contact</span><br />
      <span className='command-click' onClick={() => onClickCommand('links')}>links</span><br />
      <span className='command-click' onClick={() => onClickCommand('syndicate')}>syndicate</span><br />
      <span className='command-click' onClick={() => onClickCommand('commands')}>commands</span><br />
      <span className='command-click' onClick={() => onClickCommand('clear')}>clear</span><p></p>
    	</div>,
    },
    {
      command: 'rewards',
      loading: 'searching:\\rewards>file_loaded',
      description: <div>
      <b>About Rewards</b><br />
      You're eligible to receive rewards if you voted in the round from which the "awakened" and sold tokens originate. The CyOp amount used for voting will be put in relation to all other users and determine your share. Note: You will not be rewarded if you unstake before distribution.<br /><br />
      
      <b>About Lucky User</b><br />
      A 'Lucky user' will experience a matrix glitch in his favor and is awarded 10% of the disruption fund each time the CyOp protocol is executed. In order to be eligible, you must hold at least 2,000,000,000 CyOp tokens and vote in that respective round. If the disruption fund is bigger than 30 ETH, three Lucky user will be selected randomly.<br /><br />

      <b>Passive Income initiated</b><br />
      Disruptions enable a recurring payout mechanism for all stakeholders.<br /><br />

      <b>To Observe and to optimize</b><br />
      An algorithm is evaluating ongoing market behavior to find the best time for unloading tokens from the void, in order to maximize profits for all DAO participants.<br /><br />

      <b>FAQ:</b><br />
      1. It doesn’t matter who you vote for or if your vote wins, you’ll always get your rewards. When you vote, you don't lose your CyOp also.<p></p>

      2. The passive income surpasses the gains most coins give you in a recurring cycle<p></p>

      3. It’s only a tiny buy-in that will make you eligible for the massive ETH reward as the Lucky User
      </div>,
    },
    {
      command: 'syndicate',
      loading: 'searching:\\syndicate>file_loaded',
      description: <div>
      WE ARE THE CyOp SYNDICATE!<br />
      AWAKENED - UNITED - TUNED INTO THE GRID<br /><br />
  
      <b>THE CYOP PLEDGE:</b><br />
      I pledge allegiance to the CyOp Protocol and to the idea of disruption for which it stand, by tuning into the grid and advertising the DAO, rewarding the stakeholders and pushing one coin to rule them all!<br /><br />
      
      <b>THE PROTOCOL EXPECTS ALL MEMBERS OF THE SYNDICATE TO CONCENTRATE THEIR EFFORTS ON ONE OR MORE OF THE FOLLOWING:</b><p></p>
   
      - Infiltration of projects added to our DAO<br />
      - Guerilla marketing whereever possible<br />
      - Growth Hacking on Twitter et al.<br />
      - Onboarding big Influencers<br />
      - Building and sustaining hype within the official CyOp channels<br />
      - Elaboration and development of marketing strategies<p></p>
  

      <b>HOW TO START:</b><br />
      - talk about CyOp<br />
      - <a href="https://twitter.com/CyOpProtocol" target="_blank">follow @CyOpProtocol</a><br />
      - add #CyOperator to bio<br />
      - add CyOpSyndicate as profile avatar<br />
      - <a href="https://twitter.com/CyOpSyndicate" target="_blank">follow @CyOpSyndicate</a><br />
      - <a href="https://t.me/CyOpProtocol" target="_blank">join Telegram</a>
      </div>,
    },
    {
      command: 'matrix',
      loading: '',
      description: '',
    },
    {
      command: 'clear',
      loading: '',
      description: '',
    },
  ];

  const inputRef = useRef<null | HTMLInputElement>(null);
  const commandRef = useRef<null | HTMLElement>(null);

  const { isMobile, windowWidth } = useDeviceDetect();
  const [descriptionCompleted, setDescriptionCompleted] = useState(true);
  const [command, setCommand] = useState<any>('');

  const { play } = useAudio({
    src: sndContent,
  });
  const { play: playCmd } = useAudio({
    src: sndCmd,
  });

  // checking if valid command
  const isValidCommand = (value: any) => {
    if (!value || value.length < 2) return false;

    for (let cmd of commandList) {
      if (!Array.isArray(cmd['command']))
        if (cmd['command'] === value.toLowerCase()) return cmd;

      for(let sub of cmd['command'])
        if(sub === value.toLowerCase()) return cmd;
    }

    return false;
  };

  const onBlurInput = () => {
    if (inputRef.current) inputRef.current.focus();
  };

  useEffect(() => {
    if (commandRef.current) {
      commandRef.current.scrollIntoView();
    }
  }, [command]);

  useEffect(() => {
    if (commandRef.current) {
      commandRef.current.scrollIntoView();
    }

    if (!isMobile) {
      if (inputRef.current) {
        inputRef.current.addEventListener('blur', onBlurInput);
      }

      const interval = setInterval(() => {
        if (inputRef.current) {
          inputRef.current.focus();
        }
      }, 300);

      return () => {
        clearInterval(interval);
        if (inputRef.current) {
          // eslint-disable-next-line
          inputRef.current.removeEventListener('blur', onBlurInput);
        }
      };
    }
  }, [isMobile, windowWidth]);

  const handleMainClick = () => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  const handleKeyDownInput = (e: any) => {
    e = e || window.event;
    var keycode = e.keyCode || e.which;
    if (keycode === 37 || keycode === 39) {
      e.preventDefault();
    } else if (e.key === 'Enter') {
      e.preventDefault();

      // first check if the content is valid
      if (!(e.target instanceof HTMLElement)) {
        return;
      }

      let commandText = isValidCommand(command);
      
      // adding command content
      if (!commandText) {
        let tempCmd =
        inputCommand.concat(
        <div><div>CyOp:\Terminal&gt;{command}</div><p/><div>command not found</div><br /></div>);
        setInputCommand(tempCmd);
      } else if (commandText['command'] === 'clear') setInputCommand(['']);
      else if (commandText['command'] === 'matrix') {
        setMatrix(true);
        setMatrixCmd(command);
        setEasterFinish(false);
      } else {
        let tempCmd = inputCommand.concat(
          <div><div>CyOp:\Terminal&gt;{command}</div><p/><div className="text-desc">{commandText['loading']}</div><p/></div>);
        playCmd();

        setInputCommand(tempCmd);
        setDescriptionCompleted(false);

        setTimeout(() => {
          play();
          let tempCmd = inputCommand.concat(
            <div><div>CyOp:\Terminal&gt;{command}</div><p/><div className="text-desc">{commandText['loading']}</div><p/><div>{commandText['description']}</div><br /></div>);
          setInputCommand(tempCmd);
          setDescriptionCompleted(true);
        }, 300);
      }

      setCommand('');
    }
  };

  return (
    <>
      {!isInitClick &&
        <div className="d-flex f-column" onClick={handleMainClick}>
          <div className={`${descriptionCompleted ? 'd-flex' : 'd-none'}`}>
            <span>CyOp:\Terminal&gt;</span>
            <div className="w-100">
              <span className="co-command-field" ref={commandRef}>
                {command}
              </span>
            </div>
          </div>
          <input
            ref={inputRef}
            type="text"
            className="blind-input"
            value={command}
            onKeyDown={handleKeyDownInput}
            onChange={(e) => setCommand(e.target.value)}
          />
        </div>
      }
  </>
  );
};

export default CommandInputing;
