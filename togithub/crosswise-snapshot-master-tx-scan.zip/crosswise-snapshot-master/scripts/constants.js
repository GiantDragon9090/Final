exports.zeroAddress = "0x0000000000000000000000000000000000000000"

exports.attackBlockNumeber = 14465249
exports.lastAttackBlockNumeber = 14465314

exports.attackTxHash1 = "0xd02e444d0ef7ff063e3c2cecceba67eae832acf3f9cf817733af9139145f479b"  // Crss-BUSD

exports.attackTxHash2 = "0x5142704d825b32b724cb868c694d683a0d1b1835c08d2beb62638d9714fbdea1"  // Crss-BUSD

exports.attackTxHash3 = "0x5689ce511bfa5fe6c2fa1c7db1efec1463684c6241ccd35b1dc60231f361897a"  // Crss-BNB

exports.attackTxHash4 = "0xf6dac23c1ca72a826007804effbbeb073e13100370b33f18c65dad92bdb00d98"  // Crss-BNB

exports.lastFarmTxBeforeExploit = "0x9326ea1be5b614564fc3da3f17f16e581a96ac801064ba1c82e09abe23500458"

exports.firstFarmTxAfterExploit = "0xff0d50ced54f6332ee0dcc489fd881e0dbe9905d978e740aae07942363ef8114"

exports.exploiter = "0x748346113b6d61870aa0961c6d3fb38742fc5089"

exports.exploiteContract = "0x530b338261f8686e49403d1b5264e7a1e169f06b"

exports.devWallet = "0x2A479056FaC97b62806cc740B11774E6598B1649"

exports.presale1 = "0xAd3f5A4526fbEd82A865d1BaeF14153488f86487"

exports.presale2 = "0x3DC2b7E5dc5274C2d603342E73D1d0A9DE96796A"
