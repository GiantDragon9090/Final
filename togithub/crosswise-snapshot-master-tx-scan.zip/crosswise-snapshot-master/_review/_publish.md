# What we are doing to improve quality and security?
We are currently investigating the attack. We do not rule out the possibility that the attacker had informants inside us. There is still no evidence that vulnerabilities were discovered and exploited in our smart contracts. It will be revealed soon.
We are also reviewing code from the past. We are conducting microscopic investigations in three aspects: financial logic, security holes, and software architecture. A project that hasn't been attacked probably won't do this in-depth scrutiny.
New, rigorously selected developers are creating entirely new smart contracts based on lessons learned from previous attacks.


# How the timeline is looking like at the moment?
One and half a month is the estimated timeline at the moment. We want to shorten the timeline.

# What is new this time with our redefined full stack team - what makes us stand out in the engineering dept?

The skills of the developers are clearly higher than before. Previously, we selected program coders, but now we have selected developers who can handle finance, security and software at the same time.
Technological tools such as Trello and slack are being used in new ways to achieve the optimal balance between developer creativity and immediate goals.

