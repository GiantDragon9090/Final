import { useState } from "react"
import { useAudio } from "react-awesome-audio"
import Footer from "components/footer-panel"
import ShowModule from "components/showModule"

const sndAction = require('assets/audio/action.mp3').default

export const HomePage = () => {
  const [ownAmt, setOwnAmt] = useState(10)
  const [mintAmt, setMintAmt] = useState(1)

  const { play } = useAudio({
		src: sndAction,
	})

  const onClickMint = () => {
    play()
  }

  const onChangeMintAmt = (value) => {
		if (isNaN(Number(value)))
			return
		setMintAmt(value)
	}

  return (
    <div className="co-mainwrap">
    <div className="co-main d-flex flex-column">
      <div className="d-flex h-100 overflow-hidden">
        <div className="co-left-panel d-flex flex-column">

          <div className="mobile-title d-flex flex-column pb-3">
            <span className="txt-module">CyOp NFT MODULES</span>
            <span className="txt-status text-danger">LIMITED EDITION</span>
          </div>
          
          <span className="ps-2">Mint price:</span>
          <div className="ps-2 d-flex">
            <span className="text-danger">0.5&nbsp;≡&nbsp;</span>
            <span className="pt-1" style={{fontSize: "12px"}}>(up to 10 modules per wallet)</span>
          </div>
          <span className="pt-4 ps-2">Total supply:</span>
          <span className="text-danger ps-2">1,000</span>
          <span className="pt-4 ps-2">Supply remaining:</span>
          <span className="text-danger ps-2 pb-3" style={{borderBottom: "3px solid #05CCB2"}}>392</span>
          <div className="pt-2 ps-2 justify-content-between d-flex">
            <span className="text-desc">amount</span>
            
            <div className="pt-1" style={{fontSize: "12px"}}>
              <span className="pe-1">[{ownAmt}]</span>
              <span className="text-danger pointer pe-2" onClick={()=>setMintAmt(ownAmt)}>max</span>
            </div>

          </div>
          <div className="pt-2 ps-2 pb-2 justify-content-between d-flex">
            <input type="number" className="stake-txt-input" placeholder="0" value={mintAmt}
								onChange={(event) => onChangeMintAmt(event.target.value)}
            />
            <span className="pe-2">modules</span>
          </div>
          <div className="button-label" onClick={onClickMint}>
            mint
          </div>
          <span className="pt-2">Total:</span>
          <span className="text-desc pt-2 pb-2">0.5 eth</span>

          <div className="img-module img-mobile">
            <ShowModule />
          </div>
        </div>
        
        <div className="co-right-panel d-flex flex-column">
          <span className="txt-module ps-3">CyOp NFT MODULES</span>
          <span className="txt-status text-danger ps-3">LIMITED EDITION</span>
          <div className="pt-3 ps-3 d-flex">
            <span>Whitelist:</span>
            <span className="text-danger">&nbsp;(live)</span>
          </div>
          <div className="pt-3 ps-3 d-flex">
            <span>Waitlist:</span>
            <span className="text-desc">&nbsp;(soon)</span>
          </div>
          <span className="txt-time text-desc ps-3">
            24hrs : 00 mins : 0 secs until window opens
          </span>

          <div className="img-module">
            <ShowModule />
          </div>
        </div>
      </div>

      <Footer />
    </div>
  </div>
  )
}

export default HomePage