import { useEffect, useRef } from "react";
import * as BABYLON from "babylonjs";
import "babylonjs-loaders";

const createScene = (scene, renderCanvas) => {
  const camera = new BABYLON.ArcRotateCamera(
    "camera",
    Math.PI / 1.4,
    Math.PI / 1.7,
    -3,
    new BABYLON.Vector3(0, 0, 0)
  );
  camera.attachControl(renderCanvas, true);
  camera.lowerRadiusLimit = 3;
  camera.upperRadiusLimit = 3;

  var light0 = new BABYLON.HemisphericLight("hemiLight", new BABYLON.Vector3(-1, 1, 0), scene);
  var light1 = new BABYLON.HemisphericLight("hemiLight", new BABYLON.Vector3(1, 1, 0), scene);
  var light2 = new BABYLON.HemisphericLight("hemiLight", new BABYLON.Vector3(1, -1, 0), scene);
  var light3 = new BABYLON.HemisphericLight("hemiLight", new BABYLON.Vector3(0, 1, 0), scene);

  // var light = new BABYLON.PointLight("pointLight", new BABYLON.Vector3(0, 0, 3), scene);

  scene.clearColor = new BABYLON.Color4(0, 0, 0, 0);

  // scene.createDefaultEnvironment();
  // var hdrTexture = new BABYLON.HDRCubeTexture("./assets/skycloud.hdr", scene, 128, false, false, false, true);
  // scene.environmentTexture = hdrTexture;

  loadModel(scene);

  return scene;
};

const loadPromise = async (root, file, scene) => {
  return new Promise((res, rej) =>
    BABYLON.SceneLoader.LoadAssetContainer(root, file, scene, function (
      container
    ) {
      let root = new BABYLON.TransformNode();
      container.meshes.map((m) => {
        if (!m.parent) {
          m.parent = root;
        }
      });
      root.scaling = new BABYLON.Vector3(3, 3, 3);
      res(container);
    })
  );
};

const loadModel = async (scene) => {
  var asset = await loadPromise("./", "module.glb", scene);
  asset.addAllToScene();
};

const ShowModule = () => {
  const canvasRef = useRef(null);
  useEffect(() => {
    const renderCanvas = canvasRef.current;
    const engine = new BABYLON.Engine(renderCanvas);
    const scene = new BABYLON.Scene(engine);

    createScene(scene);
    scene.createDefaultLight();

    engine.runRenderLoop(() => {
      scene.render();
    });

    window.addEventListener("resize", function () {
      engine.resize();
    });
  }, [canvasRef.current]);

  return (
    <div className="co-module">
      <canvas className="renderCanvas" ref={canvasRef} />
    </div>
  );
}

export default ShowModule;
