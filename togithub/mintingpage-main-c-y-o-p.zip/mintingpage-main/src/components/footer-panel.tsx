export const Footer = () => {
	return (
		<div className="d-flex flex-row">
			<div className="co-footer-panel"></div>
			<div className="co-link-panel pointer disable-select">
					<div><a href="https://cyop.io" target={"_blank"}>go to cyop.io</a></div>
			</div>
		</div>
	)
}

export default Footer