import './assets/scss/index.scss'
import HomePage from 'pages/home-page';

function App() {
  return (
    <HomePage />
  );
}

export default App;
