"minting site landing page" 

yarn install

yarn start
